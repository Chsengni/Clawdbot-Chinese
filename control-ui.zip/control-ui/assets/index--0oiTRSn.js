(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))s(i);new MutationObserver(i=>{for(const r of i)if(r.type==="childList")for(const a of r.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&s(a)}).observe(document,{childList:!0,subtree:!0});function n(i){const r={};return i.integrity&&(r.integrity=i.integrity),i.referrerPolicy&&(r.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?r.credentials="include":i.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function s(i){if(i.ep)return;i.ep=!0;const r=n(i);fetch(i.href,r)}})();const Qt=globalThis,Es=Qt.ShadowRoot&&(Qt.ShadyCSS===void 0||Qt.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,Cs=Symbol(),Ni=new WeakMap;let Vr=class{constructor(t,n,s){if(this._$cssResult$=!0,s!==Cs)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=t,this.t=n}get styleSheet(){let t=this.o;const n=this.t;if(Es&&t===void 0){const s=n!==void 0&&n.length===1;s&&(t=Ni.get(n)),t===void 0&&((this.o=t=new CSSStyleSheet).replaceSync(this.cssText),s&&Ni.set(n,t))}return t}toString(){return this.cssText}};const Oo=e=>new Vr(typeof e=="string"?e:e+"",void 0,Cs),Do=(e,...t)=>{const n=e.length===1?e[0]:t.reduce((s,i,r)=>s+(a=>{if(a._$cssResult$===!0)return a.cssText;if(typeof a=="number")return a;throw Error("Value passed to 'css' function must be a 'css' function result: "+a+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(i)+e[r+1],e[0]);return new Vr(n,e,Cs)},Bo=(e,t)=>{if(Es)e.adoptedStyleSheets=t.map(n=>n instanceof CSSStyleSheet?n:n.styleSheet);else for(const n of t){const s=document.createElement("style"),i=Qt.litNonce;i!==void 0&&s.setAttribute("nonce",i),s.textContent=n.cssText,e.appendChild(s)}},Oi=Es?e=>e:e=>e instanceof CSSStyleSheet?(t=>{let n="";for(const s of t.cssRules)n+=s.cssText;return Oo(n)})(e):e;const{is:Fo,defineProperty:Uo,getOwnPropertyDescriptor:Ko,getOwnPropertyNames:Ho,getOwnPropertySymbols:zo,getPrototypeOf:jo}=Object,on=globalThis,Di=on.trustedTypes,qo=Di?Di.emptyScript:"",Vo=on.reactiveElementPolyfillSupport,xt=(e,t)=>e,Xt={toAttribute(e,t){switch(t){case Boolean:e=e?qo:null;break;case Object:case Array:e=e==null?e:JSON.stringify(e)}return e},fromAttribute(e,t){let n=e;switch(t){case Boolean:n=e!==null;break;case Number:n=e===null?null:Number(e);break;case Object:case Array:try{n=JSON.parse(e)}catch{n=null}}return n}},Ms=(e,t)=>!Fo(e,t),Bi={attribute:!0,type:String,converter:Xt,reflect:!1,useDefault:!1,hasChanged:Ms};Symbol.metadata??=Symbol("metadata"),on.litPropertyMetadata??=new WeakMap;let Ye=class extends HTMLElement{static addInitializer(t){this._$Ei(),(this.l??=[]).push(t)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(t,n=Bi){if(n.state&&(n.attribute=!1),this._$Ei(),this.prototype.hasOwnProperty(t)&&((n=Object.create(n)).wrapped=!0),this.elementProperties.set(t,n),!n.noAccessor){const s=Symbol(),i=this.getPropertyDescriptor(t,s,n);i!==void 0&&Uo(this.prototype,t,i)}}static getPropertyDescriptor(t,n,s){const{get:i,set:r}=Ko(this.prototype,t)??{get(){return this[n]},set(a){this[n]=a}};return{get:i,set(a){const o=i?.call(this);r?.call(this,a),this.requestUpdate(t,o,s)},configurable:!0,enumerable:!0}}static getPropertyOptions(t){return this.elementProperties.get(t)??Bi}static _$Ei(){if(this.hasOwnProperty(xt("elementProperties")))return;const t=jo(this);t.finalize(),t.l!==void 0&&(this.l=[...t.l]),this.elementProperties=new Map(t.elementProperties)}static finalize(){if(this.hasOwnProperty(xt("finalized")))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(xt("properties"))){const n=this.properties,s=[...Ho(n),...zo(n)];for(const i of s)this.createProperty(i,n[i])}const t=this[Symbol.metadata];if(t!==null){const n=litPropertyMetadata.get(t);if(n!==void 0)for(const[s,i]of n)this.elementProperties.set(s,i)}this._$Eh=new Map;for(const[n,s]of this.elementProperties){const i=this._$Eu(n,s);i!==void 0&&this._$Eh.set(i,n)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(t){const n=[];if(Array.isArray(t)){const s=new Set(t.flat(1/0).reverse());for(const i of s)n.unshift(Oi(i))}else t!==void 0&&n.push(Oi(t));return n}static _$Eu(t,n){const s=n.attribute;return s===!1?void 0:typeof s=="string"?s:typeof t=="string"?t.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){this._$ES=new Promise(t=>this.enableUpdating=t),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach(t=>t(this))}addController(t){(this._$EO??=new Set).add(t),this.renderRoot!==void 0&&this.isConnected&&t.hostConnected?.()}removeController(t){this._$EO?.delete(t)}_$E_(){const t=new Map,n=this.constructor.elementProperties;for(const s of n.keys())this.hasOwnProperty(s)&&(t.set(s,this[s]),delete this[s]);t.size>0&&(this._$Ep=t)}createRenderRoot(){const t=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return Bo(t,this.constructor.elementStyles),t}connectedCallback(){this.renderRoot??=this.createRenderRoot(),this.enableUpdating(!0),this._$EO?.forEach(t=>t.hostConnected?.())}enableUpdating(t){}disconnectedCallback(){this._$EO?.forEach(t=>t.hostDisconnected?.())}attributeChangedCallback(t,n,s){this._$AK(t,s)}_$ET(t,n){const s=this.constructor.elementProperties.get(t),i=this.constructor._$Eu(t,s);if(i!==void 0&&s.reflect===!0){const r=(s.converter?.toAttribute!==void 0?s.converter:Xt).toAttribute(n,s.type);this._$Em=t,r==null?this.removeAttribute(i):this.setAttribute(i,r),this._$Em=null}}_$AK(t,n){const s=this.constructor,i=s._$Eh.get(t);if(i!==void 0&&this._$Em!==i){const r=s.getPropertyOptions(i),a=typeof r.converter=="function"?{fromAttribute:r.converter}:r.converter?.fromAttribute!==void 0?r.converter:Xt;this._$Em=i;const o=a.fromAttribute(n,r.type);this[i]=o??this._$Ej?.get(i)??o,this._$Em=null}}requestUpdate(t,n,s,i=!1,r){if(t!==void 0){const a=this.constructor;if(i===!1&&(r=this[t]),s??=a.getPropertyOptions(t),!((s.hasChanged??Ms)(r,n)||s.useDefault&&s.reflect&&r===this._$Ej?.get(t)&&!this.hasAttribute(a._$Eu(t,s))))return;this.C(t,n,s)}this.isUpdatePending===!1&&(this._$ES=this._$EP())}C(t,n,{useDefault:s,reflect:i,wrapped:r},a){s&&!(this._$Ej??=new Map).has(t)&&(this._$Ej.set(t,a??n??this[t]),r!==!0||a!==void 0)||(this._$AL.has(t)||(this.hasUpdated||s||(n=void 0),this._$AL.set(t,n)),i===!0&&this._$Em!==t&&(this._$Eq??=new Set).add(t))}async _$EP(){this.isUpdatePending=!0;try{await this._$ES}catch(n){Promise.reject(n)}const t=this.scheduleUpdate();return t!=null&&await t,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??=this.createRenderRoot(),this._$Ep){for(const[i,r]of this._$Ep)this[i]=r;this._$Ep=void 0}const s=this.constructor.elementProperties;if(s.size>0)for(const[i,r]of s){const{wrapped:a}=r,o=this[i];a!==!0||this._$AL.has(i)||o===void 0||this.C(i,void 0,r,o)}}let t=!1;const n=this._$AL;try{t=this.shouldUpdate(n),t?(this.willUpdate(n),this._$EO?.forEach(s=>s.hostUpdate?.()),this.update(n)):this._$EM()}catch(s){throw t=!1,this._$EM(),s}t&&this._$AE(n)}willUpdate(t){}_$AE(t){this._$EO?.forEach(n=>n.hostUpdated?.()),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(t)),this.updated(t)}_$EM(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(t){return!0}update(t){this._$Eq&&=this._$Eq.forEach(n=>this._$ET(n,this[n])),this._$EM()}updated(t){}firstUpdated(t){}};Ye.elementStyles=[],Ye.shadowRootOptions={mode:"open"},Ye[xt("elementProperties")]=new Map,Ye[xt("finalized")]=new Map,Vo?.({ReactiveElement:Ye}),(on.reactiveElementVersions??=[]).push("2.1.2");const Is=globalThis,Fi=e=>e,Jt=Is.trustedTypes,Ui=Jt?Jt.createPolicy("lit-html",{createHTML:e=>e}):void 0,Wr="$lit$",Ae=`lit$${Math.random().toFixed(9).slice(2)}$`,Gr="?"+Ae,Wo=`<${Gr}>`,De=document,St=()=>De.createComment(""),_t=e=>e===null||typeof e!="object"&&typeof e!="function",Ls=Array.isArray,Go=e=>Ls(e)||typeof e?.[Symbol.iterator]=="function",Dn=`[ 	
\f\r]`,dt=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,Ki=/-->/g,Hi=/>/g,Ie=RegExp(`>|${Dn}(?:([^\\s"'>=/]+)(${Dn}*=${Dn}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`,"g"),zi=/'/g,ji=/"/g,Qr=/^(?:script|style|textarea|title)$/i,Qo=e=>(t,...n)=>({_$litType$:e,strings:t,values:n}),l=Qo(1),_e=Symbol.for("lit-noChange"),h=Symbol.for("lit-nothing"),qi=new WeakMap,Ne=De.createTreeWalker(De,129);function Zr(e,t){if(!Ls(e)||!e.hasOwnProperty("raw"))throw Error("invalid template strings array");return Ui!==void 0?Ui.createHTML(t):t}const Zo=(e,t)=>{const n=e.length-1,s=[];let i,r=t===2?"<svg>":t===3?"<math>":"",a=dt;for(let o=0;o<n;o++){const c=e[o];let p,d,u=-1,v=0;for(;v<c.length&&(a.lastIndex=v,d=a.exec(c),d!==null);)v=a.lastIndex,a===dt?d[1]==="!--"?a=Ki:d[1]!==void 0?a=Hi:d[2]!==void 0?(Qr.test(d[2])&&(i=RegExp("</"+d[2],"g")),a=Ie):d[3]!==void 0&&(a=Ie):a===Ie?d[0]===">"?(a=i??dt,u=-1):d[1]===void 0?u=-2:(u=a.lastIndex-d[2].length,p=d[1],a=d[3]===void 0?Ie:d[3]==='"'?ji:zi):a===ji||a===zi?a=Ie:a===Ki||a===Hi?a=dt:(a=Ie,i=void 0);const g=a===Ie&&e[o+1].startsWith("/>")?" ":"";r+=a===dt?c+Wo:u>=0?(s.push(p),c.slice(0,u)+Wr+c.slice(u)+Ae+g):c+Ae+(u===-2?o:g)}return[Zr(e,r+(e[n]||"<?>")+(t===2?"</svg>":t===3?"</math>":"")),s]};let ns=class Yr{constructor({strings:t,_$litType$:n},s){let i;this.parts=[];let r=0,a=0;const o=t.length-1,c=this.parts,[p,d]=Zo(t,n);if(this.el=Yr.createElement(p,s),Ne.currentNode=this.el.content,n===2||n===3){const u=this.el.content.firstChild;u.replaceWith(...u.childNodes)}for(;(i=Ne.nextNode())!==null&&c.length<o;){if(i.nodeType===1){if(i.hasAttributes())for(const u of i.getAttributeNames())if(u.endsWith(Wr)){const v=d[a++],g=i.getAttribute(u).split(Ae),y=/([.?@])?(.*)/.exec(v);c.push({type:1,index:r,name:y[2],strings:g,ctor:y[1]==="."?Xo:y[1]==="?"?Jo:y[1]==="@"?el:cn}),i.removeAttribute(u)}else u.startsWith(Ae)&&(c.push({type:6,index:r}),i.removeAttribute(u));if(Qr.test(i.tagName)){const u=i.textContent.split(Ae),v=u.length-1;if(v>0){i.textContent=Jt?Jt.emptyScript:"";for(let g=0;g<v;g++)i.append(u[g],St()),Ne.nextNode(),c.push({type:2,index:++r});i.append(u[v],St())}}}else if(i.nodeType===8)if(i.data===Gr)c.push({type:2,index:r});else{let u=-1;for(;(u=i.data.indexOf(Ae,u+1))!==-1;)c.push({type:7,index:r}),u+=Ae.length-1}r++}}static createElement(t,n){const s=De.createElement("template");return s.innerHTML=t,s}};function et(e,t,n=e,s){if(t===_e)return t;let i=s!==void 0?n._$Co?.[s]:n._$Cl;const r=_t(t)?void 0:t._$litDirective$;return i?.constructor!==r&&(i?._$AO?.(!1),r===void 0?i=void 0:(i=new r(e),i._$AT(e,n,s)),s!==void 0?(n._$Co??=[])[s]=i:n._$Cl=i),i!==void 0&&(t=et(e,i._$AS(e,t.values),i,s)),t}class Yo{constructor(t,n){this._$AV=[],this._$AN=void 0,this._$AD=t,this._$AM=n}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(t){const{el:{content:n},parts:s}=this._$AD,i=(t?.creationScope??De).importNode(n,!0);Ne.currentNode=i;let r=Ne.nextNode(),a=0,o=0,c=s[0];for(;c!==void 0;){if(a===c.index){let p;c.type===2?p=new ln(r,r.nextSibling,this,t):c.type===1?p=new c.ctor(r,c.name,c.strings,this,t):c.type===6&&(p=new tl(r,this,t)),this._$AV.push(p),c=s[++o]}a!==c?.index&&(r=Ne.nextNode(),a++)}return Ne.currentNode=De,i}p(t){let n=0;for(const s of this._$AV)s!==void 0&&(s.strings!==void 0?(s._$AI(t,s,n),n+=s.strings.length-2):s._$AI(t[n])),n++}}let ln=class Xr{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(t,n,s,i){this.type=2,this._$AH=h,this._$AN=void 0,this._$AA=t,this._$AB=n,this._$AM=s,this.options=i,this._$Cv=i?.isConnected??!0}get parentNode(){let t=this._$AA.parentNode;const n=this._$AM;return n!==void 0&&t?.nodeType===11&&(t=n.parentNode),t}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(t,n=this){t=et(this,t,n),_t(t)?t===h||t==null||t===""?(this._$AH!==h&&this._$AR(),this._$AH=h):t!==this._$AH&&t!==_e&&this._(t):t._$litType$!==void 0?this.$(t):t.nodeType!==void 0?this.T(t):Go(t)?this.k(t):this._(t)}O(t){return this._$AA.parentNode.insertBefore(t,this._$AB)}T(t){this._$AH!==t&&(this._$AR(),this._$AH=this.O(t))}_(t){this._$AH!==h&&_t(this._$AH)?this._$AA.nextSibling.data=t:this.T(De.createTextNode(t)),this._$AH=t}$(t){const{values:n,_$litType$:s}=t,i=typeof s=="number"?this._$AC(t):(s.el===void 0&&(s.el=ns.createElement(Zr(s.h,s.h[0]),this.options)),s);if(this._$AH?._$AD===i)this._$AH.p(n);else{const r=new Yo(i,this),a=r.u(this.options);r.p(n),this.T(a),this._$AH=r}}_$AC(t){let n=qi.get(t.strings);return n===void 0&&qi.set(t.strings,n=new ns(t)),n}k(t){Ls(this._$AH)||(this._$AH=[],this._$AR());const n=this._$AH;let s,i=0;for(const r of t)i===n.length?n.push(s=new Xr(this.O(St()),this.O(St()),this,this.options)):s=n[i],s._$AI(r),i++;i<n.length&&(this._$AR(s&&s._$AB.nextSibling,i),n.length=i)}_$AR(t=this._$AA.nextSibling,n){for(this._$AP?.(!1,!0,n);t!==this._$AB;){const s=Fi(t).nextSibling;Fi(t).remove(),t=s}}setConnected(t){this._$AM===void 0&&(this._$Cv=t,this._$AP?.(t))}};class cn{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(t,n,s,i,r){this.type=1,this._$AH=h,this._$AN=void 0,this.element=t,this.name=n,this._$AM=i,this.options=r,s.length>2||s[0]!==""||s[1]!==""?(this._$AH=Array(s.length-1).fill(new String),this.strings=s):this._$AH=h}_$AI(t,n=this,s,i){const r=this.strings;let a=!1;if(r===void 0)t=et(this,t,n,0),a=!_t(t)||t!==this._$AH&&t!==_e,a&&(this._$AH=t);else{const o=t;let c,p;for(t=r[0],c=0;c<r.length-1;c++)p=et(this,o[s+c],n,c),p===_e&&(p=this._$AH[c]),a||=!_t(p)||p!==this._$AH[c],p===h?t=h:t!==h&&(t+=(p??"")+r[c+1]),this._$AH[c]=p}a&&!i&&this.j(t)}j(t){t===h?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,t??"")}}let Xo=class extends cn{constructor(){super(...arguments),this.type=3}j(t){this.element[this.name]=t===h?void 0:t}},Jo=class extends cn{constructor(){super(...arguments),this.type=4}j(t){this.element.toggleAttribute(this.name,!!t&&t!==h)}},el=class extends cn{constructor(t,n,s,i,r){super(t,n,s,i,r),this.type=5}_$AI(t,n=this){if((t=et(this,t,n,0)??h)===_e)return;const s=this._$AH,i=t===h&&s!==h||t.capture!==s.capture||t.once!==s.once||t.passive!==s.passive,r=t!==h&&(s===h||i);i&&this.element.removeEventListener(this.name,this,s),r&&this.element.addEventListener(this.name,this,t),this._$AH=t}handleEvent(t){typeof this._$AH=="function"?this._$AH.call(this.options?.host??this.element,t):this._$AH.handleEvent(t)}},tl=class{constructor(t,n,s){this.element=t,this.type=6,this._$AN=void 0,this._$AM=n,this.options=s}get _$AU(){return this._$AM._$AU}_$AI(t){et(this,t)}};const nl={I:ln},sl=Is.litHtmlPolyfillSupport;sl?.(ns,ln),(Is.litHtmlVersions??=[]).push("3.3.2");const il=(e,t,n)=>{const s=n?.renderBefore??t;let i=s._$litPart$;if(i===void 0){const r=n?.renderBefore??null;s._$litPart$=i=new ln(t.insertBefore(St(),r),r,void 0,n??{})}return i._$AI(e),i};const Rs=globalThis;let Je=class extends Ye{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){const t=super.createRenderRoot();return this.renderOptions.renderBefore??=t.firstChild,t}update(t){const n=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(t),this._$Do=il(n,this.renderRoot,this.renderOptions)}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0)}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1)}render(){return _e}};Je._$litElement$=!0,Je.finalized=!0,Rs.litElementHydrateSupport?.({LitElement:Je});const rl=Rs.litElementPolyfillSupport;rl?.({LitElement:Je});(Rs.litElementVersions??=[]).push("4.2.2");const Jr=e=>(t,n)=>{n!==void 0?n.addInitializer(()=>{customElements.define(e,t)}):customElements.define(e,t)};const al={attribute:!0,type:String,converter:Xt,reflect:!1,hasChanged:Ms},ol=(e=al,t,n)=>{const{kind:s,metadata:i}=n;let r=globalThis.litPropertyMetadata.get(i);if(r===void 0&&globalThis.litPropertyMetadata.set(i,r=new Map),s==="setter"&&((e=Object.create(e)).wrapped=!0),r.set(n.name,e),s==="accessor"){const{name:a}=n;return{set(o){const c=t.get.call(this);t.set.call(this,o),this.requestUpdate(a,c,e,!0,o)},init(o){return o!==void 0&&this.C(a,void 0,e,o),o}}}if(s==="setter"){const{name:a}=n;return function(o){const c=this[a];t.call(this,o),this.requestUpdate(a,c,e,!0,o)}}throw Error("Unsupported decorator location: "+s)};function dn(e){return(t,n)=>typeof n=="object"?ol(e,t,n):((s,i,r)=>{const a=i.hasOwnProperty(r);return i.constructor.createProperty(r,s),a?Object.getOwnPropertyDescriptor(i,r):void 0})(e,t,n)}function $(e){return dn({...e,state:!0,attribute:!1})}const ll=50,cl=200,dl="Assistant";function Vi(e,t){if(typeof e!="string")return;const n=e.trim();if(n)return n.length<=t?n:n.slice(0,t)}function ss(e){const t=Vi(e?.name,ll)??dl,n=Vi(e?.avatar??void 0,cl)??null;return{agentId:typeof e?.agentId=="string"&&e.agentId.trim()?e.agentId.trim():null,name:t,avatar:n}}function ul(){return ss(typeof window>"u"?{}:{name:window.__CLAWDBOT_ASSISTANT_NAME__,avatar:window.__CLAWDBOT_ASSISTANT_AVATAR__})}const ea="clawdbot.control.settings.v1";function pl(){const t={gatewayUrl:`${location.protocol==="https:"?"wss":"ws"}://${location.host}`,token:"",sessionKey:"main",lastActiveSessionKey:"main",theme:"system",chatFocusMode:!1,chatShowThinking:!0,splitRatio:.6,navCollapsed:!1,navGroupsCollapsed:{}};try{const n=localStorage.getItem(ea);if(!n)return t;const s=JSON.parse(n);return{gatewayUrl:typeof s.gatewayUrl=="string"&&s.gatewayUrl.trim()?s.gatewayUrl.trim():t.gatewayUrl,token:typeof s.token=="string"?s.token:t.token,sessionKey:typeof s.sessionKey=="string"&&s.sessionKey.trim()?s.sessionKey.trim():t.sessionKey,lastActiveSessionKey:typeof s.lastActiveSessionKey=="string"&&s.lastActiveSessionKey.trim()?s.lastActiveSessionKey.trim():typeof s.sessionKey=="string"&&s.sessionKey.trim()||t.lastActiveSessionKey,theme:s.theme==="light"||s.theme==="dark"||s.theme==="system"?s.theme:t.theme,chatFocusMode:typeof s.chatFocusMode=="boolean"?s.chatFocusMode:t.chatFocusMode,chatShowThinking:typeof s.chatShowThinking=="boolean"?s.chatShowThinking:t.chatShowThinking,splitRatio:typeof s.splitRatio=="number"&&s.splitRatio>=.4&&s.splitRatio<=.7?s.splitRatio:t.splitRatio,navCollapsed:typeof s.navCollapsed=="boolean"?s.navCollapsed:t.navCollapsed,navGroupsCollapsed:typeof s.navGroupsCollapsed=="object"&&s.navGroupsCollapsed!==null?s.navGroupsCollapsed:t.navGroupsCollapsed}}catch{return t}}function fl(e){localStorage.setItem(ea,JSON.stringify(e))}function ta(e){const t=(e??"").trim();if(!t)return null;const n=t.split(":").filter(Boolean);if(n.length<3||n[0]!=="agent")return null;const s=n[1]?.trim(),i=n.slice(2).join(":");return!s||!i?null:{agentId:s,rest:i}}const hl=[{label:"对话",tabs:["chat"]},{label:"管理",tabs:["overview","channels","instances","sessions","cron"]},{label:"智能体",tabs:["skills","nodes"]},{label:"设置",tabs:["config","debug","logs"]}],na={overview:"/overview",channels:"/channels",instances:"/instances",sessions:"/sessions",cron:"/cron",skills:"/skills",nodes:"/nodes",chat:"/chat",config:"/config",debug:"/debug",logs:"/logs"},sa=new Map(Object.entries(na).map(([e,t])=>[t,e]));function un(e){if(!e)return"";let t=e.trim();return t.startsWith("/")||(t=`/${t}`),t==="/"?"":(t.endsWith("/")&&(t=t.slice(0,-1)),t)}function Tt(e){if(!e)return"/";let t=e.trim();return t.startsWith("/")||(t=`/${t}`),t.length>1&&t.endsWith("/")&&(t=t.slice(0,-1)),t}function Ps(e,t=""){const n=un(t),s=na[e];return n?`${n}${s}`:s}function ia(e,t=""){const n=un(t);let s=e||"/";n&&(s===n?s="/":s.startsWith(`${n}/`)&&(s=s.slice(n.length)));let i=Tt(s).toLowerCase();return i.endsWith("/index.html")&&(i="/"),i==="/"?"chat":sa.get(i)??null}function gl(e){let t=Tt(e);if(t.endsWith("/index.html")&&(t=Tt(t.slice(0,-11))),t==="/")return"";const n=t.split("/").filter(Boolean);if(n.length===0)return"";for(let s=0;s<n.length;s++){const i=`/${n.slice(s).join("/")}`.toLowerCase();if(sa.has(i)){const r=n.slice(0,s);return r.length?`/${r.join("/")}`:""}}return`/${n.join("/")}`}function vl(e){switch(e){case"chat":return"messageSquare";case"overview":return"barChart";case"channels":return"link";case"instances":return"radio";case"sessions":return"fileText";case"cron":return"loader";case"skills":return"zap";case"nodes":return"monitor";case"config":return"settings";case"debug":return"bug";case"logs":return"scrollText";default:return"folder"}}function is(e){switch(e){case"overview":return"概览";case"channels":return"渠道";case"instances":return"实例";case"sessions":return"会话";case"cron":return"定时任务";case"skills":return"技能";case"nodes":return"节点";case"chat":return"对话";case"config":return"配置";case"debug":return"调试";case"logs":return"日志";default:return"控制"}}function ml(e){switch(e){case"overview":return"网关状态、入口点及快速健康检查。";case"channels":return"管理通信渠道及其设置。";case"instances":return"已连接客户端和节点的在线状态。";case"sessions":return"查看活跃会话并调整会话默认值。";case"cron":return"安排智能体的唤醒和循环运行。";case"skills":return"管理技能可用性和 API 密钥注入。";case"nodes":return"配对设备、功能及命令暴露。";case"chat":return"直接与网关对话以进行快速干预。";case"config":return"安全编辑 ~/.clawdbot/clawdbot.json。";case"debug":return"网关快照、事件和手动 RPC 调用。";case"logs":return"实时查看网关日志文件。";default:return""}}const G={messageSquare:l`<svg viewBox="0 0 24 24"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>`,barChart:l`<svg viewBox="0 0 24 24"><line x1="12" x2="12" y1="20" y2="10"/><line x1="18" x2="18" y1="20" y2="4"/><line x1="6" x2="6" y1="20" y2="16"/></svg>`,link:l`<svg viewBox="0 0 24 24"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>`,radio:l`<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="2"/><path d="M16.24 7.76a6 6 0 0 1 0 8.49m-8.48-.01a6 6 0 0 1 0-8.49m11.31-2.82a10 10 0 0 1 0 14.14m-14.14 0a10 10 0 0 1 0-14.14"/></svg>`,fileText:l`<svg viewBox="0 0 24 24"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/><line x1="16" x2="8" y1="13" y2="13"/><line x1="16" x2="8" y1="17" y2="17"/><line x1="10" x2="8" y1="9" y2="9"/></svg>`,send:l`<svg viewBox="0 0 24 24"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>`,zap:l`<svg viewBox="0 0 24 24"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>`,monitor:l`<svg viewBox="0 0 24 24"><rect width="20" height="14" x="2" y="3" rx="2"/><line x1="8" x2="16" y1="21" y2="21"/><line x1="12" x2="12" y1="17" y2="21"/></svg>`,settings:l`<svg viewBox="0 0 24 24"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>`,bug:l`<svg viewBox="0 0 24 24"><path d="m8 2 1.88 1.88"/><path d="M14.12 3.88 16 2"/><path d="M9 7.13v-1a3.003 3.003 0 1 1 6 0v1"/><path d="M12 20c-3.3 0-6-2.7-6-6v-3a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v3c0 3.3-2.7 6-6 6"/><path d="M12 20v-9"/><path d="M6.53 9C4.6 8.8 3 7.1 3 5"/><path d="M6 13H2"/><path d="M3 21c0-2.1 1.7-3.9 3.8-4"/><path d="M20.97 5c0 2.1-1.6 3.8-3.5 4"/><path d="M22 13h-4"/><path d="M17.2 17c2.1.1 3.8 1.9 3.8 4"/></svg>`,scrollText:l`<svg viewBox="0 0 24 24"><path d="M8 21h12a2 2 0 0 0 2-2v-2H10v2a2 2 0 1 1-4 0V5a2 2 0 1 0-4 0v3h4"/><path d="M19 17V5a2 2 0 0 0-2-2H4"/><path d="M15 8h-5"/><path d="M15 12h-5"/></svg>`,folder:l`<svg viewBox="0 0 24 24"><path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/></svg>`,menu:l`<svg viewBox="0 0 24 24"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg>`,x:l`<svg viewBox="0 0 24 24"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>`,check:l`<svg viewBox="0 0 24 24"><path d="M20 6 9 17l-5-5"/></svg>`,copy:l`<svg viewBox="0 0 24 24"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>`,search:l`<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>`,brain:l`<svg viewBox="0 0 24 24"><path d="M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z"/><path d="M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z"/><path d="M15 13a4.5 4.5 0 0 1-3-4 4.5 4.5 0 0 1-3 4"/><path d="M17.599 6.5a3 3 0 0 0 .399-1.375"/><path d="M6.003 5.125A3 3 0 0 0 6.401 6.5"/><path d="M3.477 10.896a4 4 0 0 1 .585-.396"/><path d="M19.938 10.5a4 4 0 0 1 .585.396"/><path d="M6 18a4 4 0 0 1-1.967-.516"/><path d="M19.967 17.484A4 4 0 0 1 18 18"/></svg>`,book:l`<svg viewBox="0 0 24 24"><path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"/></svg>`,loader:l`<svg viewBox="0 0 24 24"><path d="M12 2v4"/><path d="m16.2 7.8 2.9-2.9"/><path d="M18 12h4"/><path d="m16.2 16.2 2.9 2.9"/><path d="M12 18v4"/><path d="m4.9 19.1 2.9-2.9"/><path d="M2 12h4"/><path d="m4.9 4.9 2.9 2.9"/></svg>`,wrench:l`<svg viewBox="0 0 24 24"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>`,fileCode:l`<svg viewBox="0 0 24 24"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/><path d="m10 13-2 2 2 2"/><path d="m14 17 2-2-2-2"/></svg>`,edit:l`<svg viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>`,penLine:l`<svg viewBox="0 0 24 24"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>`,paperclip:l`<svg viewBox="0 0 24 24"><path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l8.57-8.57A4 4 0 1 1 18 8.84l-8.59 8.57a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>`,globe:l`<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/></svg>`,image:l`<svg viewBox="0 0 24 24"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg>`,smartphone:l`<svg viewBox="0 0 24 24"><rect width="14" height="20" x="5" y="2" rx="2" ry="2"/><path d="M12 18h.01"/></svg>`,plug:l`<svg viewBox="0 0 24 24"><path d="M12 22v-5"/><path d="M9 8V2"/><path d="M15 8V2"/><path d="M18 8v5a4 4 0 0 1-4 4h-4a4 4 0 0 1-4-4V8Z"/></svg>`,circle:l`<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/></svg>`,puzzle:l`<svg viewBox="0 0 24 24"><path d="M19.439 7.85c-.049.322.059.648.289.878l1.568 1.568c.47.47.706 1.087.706 1.704s-.235 1.233-.706 1.704l-1.611 1.611a.98.98 0 0 1-.837.276c-.47-.07-.802-.48-.968-.925a2.501 2.501 0 1 0-3.214 3.214c.446.166.855.497.925.968a.979.979 0 0 1-.276.837l-1.61 1.61a2.404 2.404 0 0 1-1.705.707 2.402 2.402 0 0 1-1.704-.706l-1.568-1.568a1.026 1.026 0 0 0-.877-.29c-.493.074-.84.504-1.02.968a2.5 2.5 0 1 1-3.237-3.237c.464-.18.894-.527.967-1.02a1.026 1.026 0 0 0-.289-.877l-1.568-1.568A2.402 2.402 0 0 1 1.998 12c0-.617.236-1.234.706-1.704L4.23 8.77c.24-.24.581-.353.917-.303.515.076.874.54 1.02 1.02a2.5 2.5 0 1 0 3.237-3.237c-.48-.146-.944-.505-1.02-1.02a.98.98 0 0 1 .303-.917l1.526-1.526A2.402 2.402 0 0 1 11.998 2c.617 0 1.234.236 1.704.706l1.568 1.568c.23.23.556.338.877.29.493-.074.84-.504 1.02-.968a2.5 2.5 0 1 1 3.236 3.236c-.464.18-.894.527-.967 1.02Z"/></svg>`},yl=/<\s*\/?\s*(?:think(?:ing)?|thought|antthinking|final)\b/i,Ht=/<\s*\/?\s*final\b[^>]*>/gi,Wi=/<\s*(\/?)\s*(?:think(?:ing)?|thought|antthinking)\b[^>]*>/gi;function bl(e,t){return e.trimStart()}function $l(e,t){if(!e||!yl.test(e))return e;let n=e;Ht.test(n)?(Ht.lastIndex=0,n=n.replace(Ht,"")):Ht.lastIndex=0,Wi.lastIndex=0;let s="",i=0,r=!1;for(const a of n.matchAll(Wi)){const o=a.index??0,c=a[1]==="/";r?c&&(r=!1):(s+=n.slice(i,o),c||(r=!0)),i=o+a[0].length}return s+=n.slice(i),bl(s)}function Et(e){return!e&&e!==0?"无":new Date(e).toLocaleString()}function D(e){if(!e&&e!==0)return"无";const t=Date.now()-e;if(t<0)return"刚刚";const n=Math.round(t/1e3);if(n<60)return`${n} 秒前`;const s=Math.round(n/60);if(s<60)return`${s} 分钟前`;const i=Math.round(s/60);return i<48?`${i} 小时前`:`${Math.round(i/24)} 天前`}function ra(e){if(!e&&e!==0)return"无";if(e<1e3)return`${e} 毫秒`;const t=Math.round(e/1e3);if(t<60)return`${t} 秒`;const n=Math.round(t/60);if(n<60)return`${n} 分钟`;const s=Math.round(n/60);return s<48?`${s} 小时`:`${Math.round(s/24)} 天`}function rs(e){return!e||e.length===0?"无":e.filter(t=>!!(t&&t.trim())).join(", ")}function as(e,t=120){return e.length<=t?e:`${e.slice(0,Math.max(0,t-1))}…`}function aa(e,t){return e.length<=t?{text:e,truncated:!1,total:e.length}:{text:e.slice(0,Math.max(0,t)),truncated:!0,total:e.length}}function en(e,t){const n=Number(e);return Number.isFinite(n)?n:t}function Bn(e){return $l(e)}const wl=/^\[([^\]]+)\]\s*/,xl=["WebChat","WhatsApp","Telegram","Signal","Slack","Discord","iMessage","Teams","Matrix","Zalo","Zalo Personal","BlueBubbles"],Fn=new WeakMap,Un=new WeakMap;function Al(e){return/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}Z\b/.test(e)||/\d{4}-\d{2}-\d{2} \d{2}:\d{2}\b/.test(e)?!0:xl.some(t=>e.startsWith(`${t} `))}function Kn(e){const t=e.match(wl);if(!t)return e;const n=t[1]??"";return Al(n)?e.slice(t[0].length):e}function os(e){const t=e,n=typeof t.role=="string"?t.role:"",s=t.content;if(typeof s=="string")return n==="assistant"?Bn(s):Kn(s);if(Array.isArray(s)){const i=s.map(r=>{const a=r;return a.type==="text"&&typeof a.text=="string"?a.text:null}).filter(r=>typeof r=="string");if(i.length>0){const r=i.join(`
`);return n==="assistant"?Bn(r):Kn(r)}}return typeof t.text=="string"?n==="assistant"?Bn(t.text):Kn(t.text):null}function oa(e){if(!e||typeof e!="object")return os(e);const t=e;if(Fn.has(t))return Fn.get(t)??null;const n=os(e);return Fn.set(t,n),n}function Gi(e){const n=e.content,s=[];if(Array.isArray(n))for(const o of n){const c=o;if(c.type==="thinking"&&typeof c.thinking=="string"){const p=c.thinking.trim();p&&s.push(p)}}if(s.length>0)return s.join(`
`);const i=Sl(e);if(!i)return null;const a=[...i.matchAll(/<\s*think(?:ing)?\s*>([\s\S]*?)<\s*\/\s*think(?:ing)?\s*>/gi)].map(o=>(o[1]??"").trim()).filter(Boolean);return a.length>0?a.join(`
`):null}function kl(e){if(!e||typeof e!="object")return Gi(e);const t=e;if(Un.has(t))return Un.get(t)??null;const n=Gi(e);return Un.set(t,n),n}function Sl(e){const t=e,n=t.content;if(typeof n=="string")return n;if(Array.isArray(n)){const s=n.map(i=>{const r=i;return r.type==="text"&&typeof r.text=="string"?r.text:null}).filter(i=>typeof i=="string");if(s.length>0)return s.join(`
`)}return typeof t.text=="string"?t.text:null}function _l(e){const t=e.trim();if(!t)return"";const n=t.split(/\r?\n/).map(s=>s.trim()).filter(Boolean).map(s=>`_${s}_`);return n.length?["_Reasoning:_",...n].join(`
`):""}function Qi(e){e[6]=e[6]&15|64,e[8]=e[8]&63|128;let t="";for(let n=0;n<e.length;n++)t+=e[n].toString(16).padStart(2,"0");return`${t.slice(0,8)}-${t.slice(8,12)}-${t.slice(12,16)}-${t.slice(16,20)}-${t.slice(20)}`}function Tl(){const e=new Uint8Array(16),t=Date.now();for(let n=0;n<e.length;n++)e[n]=Math.floor(Math.random()*256);return e[0]^=t&255,e[1]^=t>>>8&255,e[2]^=t>>>16&255,e[3]^=t>>>24&255,e}function Ns(e=globalThis.crypto){if(e&&typeof e.randomUUID=="function")return e.randomUUID();if(e&&typeof e.getRandomValues=="function"){const t=new Uint8Array(16);return e.getRandomValues(t),Qi(t)}return Qi(Tl())}async function tt(e){if(!(!e.client||!e.connected)){e.chatLoading=!0,e.lastError=null;try{const t=await e.client.request("chat.history",{sessionKey:e.sessionKey,limit:200});e.chatMessages=Array.isArray(t.messages)?t.messages:[],e.chatThinkingLevel=t.thinkingLevel??null}catch(t){e.lastError=String(t)}finally{e.chatLoading=!1}}}function El(e){const t=/^data:([^;]+);base64,(.+)$/.exec(e);return t?{mimeType:t[1],content:t[2]}:null}async function Cl(e,t,n){if(!e.client||!e.connected)return!1;const s=t.trim(),i=n&&n.length>0;if(!s&&!i)return!1;const r=Date.now(),a=[];if(s&&a.push({type:"text",text:s}),i)for(const p of n)a.push({type:"image",source:{type:"base64",media_type:p.mimeType,data:p.dataUrl}});e.chatMessages=[...e.chatMessages,{role:"user",content:a,timestamp:r}],e.chatSending=!0,e.lastError=null;const o=Ns();e.chatRunId=o,e.chatStream="",e.chatStreamStartedAt=r;const c=i?n.map(p=>{const d=El(p.dataUrl);return d?{type:"image",mimeType:d.mimeType,content:d.content}:null}).filter(p=>p!==null):void 0;try{return await e.client.request("chat.send",{sessionKey:e.sessionKey,message:s,deliver:!1,idempotencyKey:o,attachments:c}),!0}catch(p){const d=String(p);return e.chatRunId=null,e.chatStream=null,e.chatStreamStartedAt=null,e.lastError=d,e.chatMessages=[...e.chatMessages,{role:"assistant",content:[{type:"text",text:"Error: "+d}],timestamp:Date.now()}],!1}finally{e.chatSending=!1}}async function Ml(e){if(!e.client||!e.connected)return!1;const t=e.chatRunId;try{return await e.client.request("chat.abort",t?{sessionKey:e.sessionKey,runId:t}:{sessionKey:e.sessionKey}),!0}catch(n){return e.lastError=String(n),!1}}function Il(e,t){if(!t||t.sessionKey!==e.sessionKey)return null;if(t.runId&&e.chatRunId&&t.runId!==e.chatRunId)return t.state==="final"?"final":null;if(t.state==="delta"){const n=os(t.message);if(typeof n=="string"){const s=e.chatStream??"";(!s||n.length>=s.length)&&(e.chatStream=n)}}else t.state==="final"||t.state==="aborted"?(e.chatStream=null,e.chatRunId=null,e.chatStreamStartedAt=null):t.state==="error"&&(e.chatStream=null,e.chatRunId=null,e.chatStreamStartedAt=null,e.lastError=t.errorMessage??"chat error");return t.state}async function at(e){if(!(!e.client||!e.connected)&&!e.sessionsLoading){e.sessionsLoading=!0,e.sessionsError=null;try{const t={includeGlobal:e.sessionsIncludeGlobal,includeUnknown:e.sessionsIncludeUnknown},n=en(e.sessionsFilterActive,0),s=en(e.sessionsFilterLimit,0);n>0&&(t.activeMinutes=n),s>0&&(t.limit=s);const i=await e.client.request("sessions.list",t);i&&(e.sessionsResult=i)}catch(t){e.sessionsError=String(t)}finally{e.sessionsLoading=!1}}}async function Ll(e,t,n){if(!e.client||!e.connected)return;const s={key:t};"label"in n&&(s.label=n.label),"thinkingLevel"in n&&(s.thinkingLevel=n.thinkingLevel),"verboseLevel"in n&&(s.verboseLevel=n.verboseLevel),"reasoningLevel"in n&&(s.reasoningLevel=n.reasoningLevel);try{await e.client.request("sessions.patch",s),await at(e)}catch(i){e.sessionsError=String(i)}}async function Rl(e,t){if(!(!e.client||!e.connected||e.sessionsLoading||!window.confirm(`Delete session "${t}"?

Deletes the session entry and archives its transcript.`))){e.sessionsLoading=!0,e.sessionsError=null;try{await e.client.request("sessions.delete",{key:t,deleteTranscript:!0}),await at(e)}catch(s){e.sessionsError=String(s)}finally{e.sessionsLoading=!1}}}const Zi=50,Pl=80,Nl=12e4;function Ol(e){if(!e||typeof e!="object")return null;const t=e;if(typeof t.text=="string")return t.text;const n=t.content;if(!Array.isArray(n))return null;const s=n.map(i=>{if(!i||typeof i!="object")return null;const r=i;return r.type==="text"&&typeof r.text=="string"?r.text:null}).filter(i=>!!i);return s.length===0?null:s.join(`
`)}function Yi(e){if(e==null)return null;if(typeof e=="number"||typeof e=="boolean")return String(e);const t=Ol(e);let n;if(typeof e=="string")n=e;else if(t)n=t;else try{n=JSON.stringify(e,null,2)}catch{n=String(e)}const s=aa(n,Nl);return s.truncated?`${s.text}

… truncated (${s.total} chars, showing first ${s.text.length}).`:s.text}function Dl(e){const t=[];return t.push({type:"toolcall",name:e.name,arguments:e.args??{}}),e.output&&t.push({type:"toolresult",name:e.name,text:e.output}),{role:"assistant",toolCallId:e.toolCallId,runId:e.runId,content:t,timestamp:e.startedAt}}function Bl(e){if(e.toolStreamOrder.length<=Zi)return;const t=e.toolStreamOrder.length-Zi,n=e.toolStreamOrder.splice(0,t);for(const s of n)e.toolStreamById.delete(s)}function Fl(e){e.chatToolMessages=e.toolStreamOrder.map(t=>e.toolStreamById.get(t)?.message).filter(t=>!!t)}function ls(e){e.toolStreamSyncTimer!=null&&(clearTimeout(e.toolStreamSyncTimer),e.toolStreamSyncTimer=null),Fl(e)}function Ul(e,t=!1){if(t){ls(e);return}e.toolStreamSyncTimer==null&&(e.toolStreamSyncTimer=window.setTimeout(()=>ls(e),Pl))}function Os(e){e.toolStreamById.clear(),e.toolStreamOrder=[],e.chatToolMessages=[],ls(e)}const Kl=5e3;function Hl(e,t){const n=t.data??{},s=typeof n.phase=="string"?n.phase:"";e.compactionClearTimer!=null&&(window.clearTimeout(e.compactionClearTimer),e.compactionClearTimer=null),s==="start"?e.compactionStatus={active:!0,startedAt:Date.now(),completedAt:null}:s==="end"&&(e.compactionStatus={active:!1,startedAt:e.compactionStatus?.startedAt??null,completedAt:Date.now()},e.compactionClearTimer=window.setTimeout(()=>{e.compactionStatus=null,e.compactionClearTimer=null},Kl))}function zl(e,t){if(!t)return;if(t.stream==="compaction"){Hl(e,t);return}if(t.stream!=="tool")return;const n=typeof t.sessionKey=="string"?t.sessionKey:void 0;if(n&&n!==e.sessionKey||!n&&e.chatRunId&&t.runId!==e.chatRunId||e.chatRunId&&t.runId!==e.chatRunId||!e.chatRunId)return;const s=t.data??{},i=typeof s.toolCallId=="string"?s.toolCallId:"";if(!i)return;const r=typeof s.name=="string"?s.name:"tool",a=typeof s.phase=="string"?s.phase:"",o=a==="start"?s.args:void 0,c=a==="update"?Yi(s.partialResult):a==="result"?Yi(s.result):void 0,p=Date.now();let d=e.toolStreamById.get(i);d?(d.name=r,o!==void 0&&(d.args=o),c!==void 0&&(d.output=c),d.updatedAt=p):(d={toolCallId:i,runId:t.runId,sessionKey:n,name:r,args:o,output:c,startedAt:typeof t.ts=="number"?t.ts:p,updatedAt:p,message:{}},e.toolStreamById.set(i,d),e.toolStreamOrder.push(i)),d.message=Dl(d),Bl(e),Ul(e,a==="result")}function pn(e,t=!1){e.chatScrollFrame&&cancelAnimationFrame(e.chatScrollFrame),e.chatScrollTimeout!=null&&(clearTimeout(e.chatScrollTimeout),e.chatScrollTimeout=null);const n=()=>{const s=e.querySelector(".chat-thread");if(s){const i=getComputedStyle(s).overflowY;if(i==="auto"||i==="scroll"||s.scrollHeight-s.clientHeight>1)return s}return document.scrollingElement??document.documentElement};e.updateComplete.then(()=>{e.chatScrollFrame=requestAnimationFrame(()=>{e.chatScrollFrame=null;const s=n();if(!s)return;const i=s.scrollHeight-s.scrollTop-s.clientHeight;if(!(t||e.chatUserNearBottom||i<200))return;t&&(e.chatHasAutoScrolled=!0),s.scrollTop=s.scrollHeight,e.chatUserNearBottom=!0;const a=t?150:120;e.chatScrollTimeout=window.setTimeout(()=>{e.chatScrollTimeout=null;const o=n();if(!o)return;const c=o.scrollHeight-o.scrollTop-o.clientHeight;(t||e.chatUserNearBottom||c<200)&&(o.scrollTop=o.scrollHeight,e.chatUserNearBottom=!0)},a)})})}function la(e,t=!1){e.logsScrollFrame&&cancelAnimationFrame(e.logsScrollFrame),e.updateComplete.then(()=>{e.logsScrollFrame=requestAnimationFrame(()=>{e.logsScrollFrame=null;const n=e.querySelector(".log-stream");if(!n)return;const s=n.scrollHeight-n.scrollTop-n.clientHeight;(t||s<80)&&(n.scrollTop=n.scrollHeight)})})}function jl(e,t){const n=t.currentTarget;if(!n)return;const s=n.scrollHeight-n.scrollTop-n.clientHeight;e.chatUserNearBottom=s<200}function ql(e,t){const n=t.currentTarget;if(!n)return;const s=n.scrollHeight-n.scrollTop-n.clientHeight;e.logsAtBottom=s<80}function Vl(e){e.chatHasAutoScrolled=!1,e.chatUserNearBottom=!0}function Wl(e,t){if(e.length===0)return;const n=new Blob([`${e.join(`
`)}
`],{type:"text/plain"}),s=URL.createObjectURL(n),i=document.createElement("a"),r=new Date().toISOString().slice(0,19).replace(/[:T]/g,"-");i.href=s,i.download=`clawdbot-logs-${t}-${r}.log`,i.click(),URL.revokeObjectURL(s)}function Gl(e){if(typeof ResizeObserver>"u")return;const t=e.querySelector(".topbar");if(!t)return;const n=()=>{const{height:s}=t.getBoundingClientRect();e.style.setProperty("--topbar-height",`${s}px`)};n(),e.topbarObserver=new ResizeObserver(()=>n()),e.topbarObserver.observe(t)}function Be(e){return typeof structuredClone=="function"?structuredClone(e):JSON.parse(JSON.stringify(e))}function nt(e){return`${JSON.stringify(e,null,2).trimEnd()}
`}function ca(e,t,n){if(t.length===0)return;let s=e;for(let r=0;r<t.length-1;r+=1){const a=t[r],o=t[r+1];if(typeof a=="number"){if(!Array.isArray(s))return;s[a]==null&&(s[a]=typeof o=="number"?[]:{}),s=s[a]}else{if(typeof s!="object"||s==null)return;const c=s;c[a]==null&&(c[a]=typeof o=="number"?[]:{}),s=c[a]}}const i=t[t.length-1];if(typeof i=="number"){Array.isArray(s)&&(s[i]=n);return}typeof s=="object"&&s!=null&&(s[i]=n)}function da(e,t){if(t.length===0)return;let n=e;for(let i=0;i<t.length-1;i+=1){const r=t[i];if(typeof r=="number"){if(!Array.isArray(n))return;n=n[r]}else{if(typeof n!="object"||n==null)return;n=n[r]}if(n==null)return}const s=t[t.length-1];if(typeof s=="number"){Array.isArray(n)&&n.splice(s,1);return}typeof n=="object"&&n!=null&&delete n[s]}async function be(e){if(!(!e.client||!e.connected)){e.configLoading=!0,e.lastError=null;try{const t=await e.client.request("config.get",{});Zl(e,t)}catch(t){e.lastError=String(t)}finally{e.configLoading=!1}}}async function ua(e){if(!(!e.client||!e.connected)&&!e.configSchemaLoading){e.configSchemaLoading=!0;try{const t=await e.client.request("config.schema",{});Ql(e,t)}catch(t){e.lastError=String(t)}finally{e.configSchemaLoading=!1}}}function Ql(e,t){e.configSchema=t.schema??null,e.configUiHints=t.uiHints??{},e.configSchemaVersion=t.version??null}function Zl(e,t){e.configSnapshot=t;const n=typeof t.raw=="string"?t.raw:t.config&&typeof t.config=="object"?nt(t.config):e.configRaw;!e.configFormDirty||e.configFormMode==="raw"?e.configRaw=n:e.configForm?e.configRaw=nt(e.configForm):e.configRaw=n,e.configValid=typeof t.valid=="boolean"?t.valid:null,e.configIssues=Array.isArray(t.issues)?t.issues:[],e.configFormDirty||(e.configForm=Be(t.config??{}),e.configFormOriginal=Be(t.config??{}),e.configRawOriginal=n)}async function cs(e){if(!(!e.client||!e.connected)){e.configSaving=!0,e.lastError=null;try{const t=e.configFormMode==="form"&&e.configForm?nt(e.configForm):e.configRaw,n=e.configSnapshot?.hash;if(!n){e.lastError="Config hash missing; reload and retry.";return}await e.client.request("config.set",{raw:t,baseHash:n}),e.configFormDirty=!1,await be(e)}catch(t){e.lastError=String(t)}finally{e.configSaving=!1}}}async function Yl(e){if(!(!e.client||!e.connected)){e.configApplying=!0,e.lastError=null;try{const t=e.configFormMode==="form"&&e.configForm?nt(e.configForm):e.configRaw,n=e.configSnapshot?.hash;if(!n){e.lastError="Config hash missing; reload and retry.";return}await e.client.request("config.apply",{raw:t,baseHash:n,sessionKey:e.applySessionKey}),e.configFormDirty=!1,await be(e)}catch(t){e.lastError=String(t)}finally{e.configApplying=!1}}}async function Xl(e){if(!(!e.client||!e.connected)){e.updateRunning=!0,e.lastError=null;try{await e.client.request("update.run",{sessionKey:e.applySessionKey})}catch(t){e.lastError=String(t)}finally{e.updateRunning=!1}}}function bt(e,t,n){const s=Be(e.configForm??e.configSnapshot?.config??{});ca(s,t,n),e.configForm=s,e.configFormDirty=!0,e.configFormMode==="form"&&(e.configRaw=nt(s))}function Xi(e,t){const n=Be(e.configForm??e.configSnapshot?.config??{});da(n,t),e.configForm=n,e.configFormDirty=!0,e.configFormMode==="form"&&(e.configRaw=nt(n))}async function Jl(e,t){if(!e.client||!e.connected||!e.configForm)return;const n=e.configForm.models;if(!n||!n.providers)return;const s=n.providers[t];if(s){e.configSaving=!0,e.lastError=null;try{const i=await e.client.request("models.discover",{provider:t,apiKey:s.apiKey,baseUrl:s.baseUrl});if(i&&Array.isArray(i.models)&&i.models.length>0){const r=s.models??[],a=i.models;return bt(e,["models","providers",t,"models"],a),{success:!0,count:a.length}}else return e.lastError="No models found or error during discovery.",{success:!1,error:e.lastError}}catch(i){return e.lastError=String(i),{success:!1,error:e.lastError}}finally{e.configSaving=!1}}}async function Mt(e){if(!(!e.client||!e.connected))try{const t=await e.client.request("cron.status",{});e.cronStatus=t}catch(t){e.cronError=String(t)}}async function fn(e){if(!(!e.client||!e.connected)&&!e.cronLoading){e.cronLoading=!0,e.cronError=null;try{const t=await e.client.request("cron.list",{includeDisabled:!0});e.cronJobs=Array.isArray(t.jobs)?t.jobs:[]}catch(t){e.cronError=String(t)}finally{e.cronLoading=!1}}}function ec(e){if(e.scheduleKind==="at"){const n=Date.parse(e.scheduleAt);if(!Number.isFinite(n))throw new Error("Invalid run time.");return{kind:"at",atMs:n}}if(e.scheduleKind==="every"){const n=en(e.everyAmount,0);if(n<=0)throw new Error("Invalid interval amount.");const s=e.everyUnit;return{kind:"every",everyMs:n*(s==="minutes"?6e4:s==="hours"?36e5:864e5)}}const t=e.cronExpr.trim();if(!t)throw new Error("Cron expression required.");return{kind:"cron",expr:t,tz:e.cronTz.trim()||void 0}}function tc(e){if(e.payloadKind==="systemEvent"){const i=e.payloadText.trim();if(!i)throw new Error("System event text required.");return{kind:"systemEvent",text:i}}const t=e.payloadText.trim();if(!t)throw new Error("Agent message required.");const n={kind:"agentTurn",message:t};e.deliver&&(n.deliver=!0),e.channel&&(n.channel=e.channel),e.to.trim()&&(n.to=e.to.trim());const s=en(e.timeoutSeconds,0);return s>0&&(n.timeoutSeconds=s),n}async function nc(e){if(!(!e.client||!e.connected||e.cronBusy)){e.cronBusy=!0,e.cronError=null;try{const t=ec(e.cronForm),n=tc(e.cronForm),s=e.cronForm.agentId.trim(),i={name:e.cronForm.name.trim(),description:e.cronForm.description.trim()||void 0,agentId:s||void 0,enabled:e.cronForm.enabled,schedule:t,sessionTarget:e.cronForm.sessionTarget,wakeMode:e.cronForm.wakeMode,payload:n,isolation:e.cronForm.postToMainPrefix.trim()&&e.cronForm.sessionTarget==="isolated"?{postToMainPrefix:e.cronForm.postToMainPrefix.trim()}:void 0};if(!i.name)throw new Error("Name required.");await e.client.request("cron.add",i),e.cronForm={...e.cronForm,name:"",description:"",payloadText:""},await fn(e),await Mt(e)}catch(t){e.cronError=String(t)}finally{e.cronBusy=!1}}}async function sc(e,t,n){if(!(!e.client||!e.connected||e.cronBusy)){e.cronBusy=!0,e.cronError=null;try{await e.client.request("cron.update",{id:t.id,patch:{enabled:n}}),await fn(e),await Mt(e)}catch(s){e.cronError=String(s)}finally{e.cronBusy=!1}}}async function ic(e,t){if(!(!e.client||!e.connected||e.cronBusy)){e.cronBusy=!0,e.cronError=null;try{await e.client.request("cron.run",{id:t.id,mode:"force"}),await pa(e,t.id)}catch(n){e.cronError=String(n)}finally{e.cronBusy=!1}}}async function rc(e,t){if(!(!e.client||!e.connected||e.cronBusy)){e.cronBusy=!0,e.cronError=null;try{await e.client.request("cron.remove",{id:t.id}),e.cronRunsJobId===t.id&&(e.cronRunsJobId=null,e.cronRuns=[]),await fn(e),await Mt(e)}catch(n){e.cronError=String(n)}finally{e.cronBusy=!1}}}async function pa(e,t){if(!(!e.client||!e.connected))try{const n=await e.client.request("cron.runs",{id:t,limit:50});e.cronRunsJobId=t,e.cronRuns=Array.isArray(n.entries)?n.entries:[]}catch(n){e.cronError=String(n)}}async function le(e,t){if(!(!e.client||!e.connected)&&!e.channelsLoading){e.channelsLoading=!0,e.channelsError=null;try{const n=await e.client.request("channels.status",{probe:t,timeoutMs:8e3});e.channelsSnapshot=n,e.channelsLastSuccess=Date.now()}catch(n){e.channelsError=String(n)}finally{e.channelsLoading=!1}}}async function ac(e,t){if(!(!e.client||!e.connected||e.whatsappBusy)){e.whatsappBusy=!0;try{const n=await e.client.request("web.login.start",{force:t,timeoutMs:3e4});e.whatsappLoginMessage=n.message??null,e.whatsappLoginQrDataUrl=n.qrDataUrl??null,e.whatsappLoginConnected=null}catch(n){e.whatsappLoginMessage=String(n),e.whatsappLoginQrDataUrl=null,e.whatsappLoginConnected=null}finally{e.whatsappBusy=!1}}}async function oc(e){if(!(!e.client||!e.connected||e.whatsappBusy)){e.whatsappBusy=!0;try{const t=await e.client.request("web.login.wait",{timeoutMs:12e4});e.whatsappLoginMessage=t.message??null,e.whatsappLoginConnected=t.connected??null,t.connected&&(e.whatsappLoginQrDataUrl=null)}catch(t){e.whatsappLoginMessage=String(t),e.whatsappLoginConnected=null}finally{e.whatsappBusy=!1}}}async function lc(e){if(!(!e.client||!e.connected||e.whatsappBusy)){e.whatsappBusy=!0;try{await e.client.request("channels.logout",{channel:"whatsapp"}),e.whatsappLoginMessage="Logged out.",e.whatsappLoginQrDataUrl=null,e.whatsappLoginConnected=null}catch(t){e.whatsappLoginMessage=String(t)}finally{e.whatsappBusy=!1}}}async function hn(e){if(!(!e.client||!e.connected)&&!e.debugLoading){e.debugLoading=!0;try{const[t,n,s,i]=await Promise.all([e.client.request("status",{}),e.client.request("health",{}),e.client.request("models.list",{}),e.client.request("last-heartbeat",{})]);e.debugStatus=t,e.debugHealth=n;const r=s;e.debugModels=Array.isArray(r?.models)?r?.models:[],e.debugHeartbeat=i}catch(t){e.debugCallError=String(t)}finally{e.debugLoading=!1}}}async function cc(e){if(!(!e.client||!e.connected)){e.debugCallError=null,e.debugCallResult=null;try{const t=e.debugCallParams.trim()?JSON.parse(e.debugCallParams):{},n=await e.client.request(e.debugCallMethod.trim(),t);e.debugCallResult=JSON.stringify(n,null,2)}catch(t){e.debugCallError=String(t)}}}const dc=2e3,uc=new Set(["trace","debug","info","warn","error","fatal"]);function pc(e){if(typeof e!="string")return null;const t=e.trim();if(!t.startsWith("{")||!t.endsWith("}"))return null;try{const n=JSON.parse(t);return!n||typeof n!="object"?null:n}catch{return null}}function fc(e){if(typeof e!="string")return null;const t=e.toLowerCase();return uc.has(t)?t:null}function hc(e){if(!e.trim())return{raw:e,message:e};try{const t=JSON.parse(e),n=t&&typeof t._meta=="object"&&t._meta!==null?t._meta:null,s=typeof t.time=="string"?t.time:typeof n?.date=="string"?n?.date:null,i=fc(n?.logLevelName??n?.level),r=typeof t[0]=="string"?t[0]:typeof n?.name=="string"?n?.name:null,a=pc(r);let o=null;a&&(typeof a.subsystem=="string"?o=a.subsystem:typeof a.module=="string"&&(o=a.module)),!o&&r&&r.length<120&&(o=r);let c=null;return typeof t[1]=="string"?c=t[1]:!a&&typeof t[0]=="string"?c=t[0]:typeof t.message=="string"&&(c=t.message),{raw:e,time:s,level:i,subsystem:o,message:c??e,meta:n??void 0}}catch{return{raw:e,message:e}}}async function Ds(e,t){if(!(!e.client||!e.connected)&&!(e.logsLoading&&!t?.quiet)){t?.quiet||(e.logsLoading=!0),e.logsError=null;try{const s=await e.client.request("logs.tail",{cursor:t?.reset?void 0:e.logsCursor??void 0,limit:e.logsLimit,maxBytes:e.logsMaxBytes}),r=(Array.isArray(s.lines)?s.lines.filter(o=>typeof o=="string"):[]).map(hc),a=!!(t?.reset||s.reset||e.logsCursor==null);e.logsEntries=a?r:[...e.logsEntries,...r].slice(-dc),typeof s.cursor=="number"&&(e.logsCursor=s.cursor),typeof s.file=="string"&&(e.logsFile=s.file),e.logsTruncated=!!s.truncated,e.logsLastFetchAt=Date.now()}catch(n){e.logsError=String(n)}finally{t?.quiet||(e.logsLoading=!1)}}}const fa={p:0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffedn,n:0x1000000000000000000000000000000014def9dea2f79cd65812631a5cf5d3edn,h:8n,a:0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffecn,d:0x52036cee2b6ffe738cc740797779e89800700a4d4141d8ab75eb4dca135978a3n,Gx:0x216936d3cd6e53fec0a4e231fdd6dc5c692cc7609525a7b2c9562d608f25d51an,Gy:0x6666666666666666666666666666666666666666666666666666666666666658n},{p:W,n:Zt,Gx:Ji,Gy:er,a:Hn,d:zn,h:gc}=fa,Fe=32,Bs=64,vc=(...e)=>{"captureStackTrace"in Error&&typeof Error.captureStackTrace=="function"&&Error.captureStackTrace(...e)},z=(e="")=>{const t=new Error(e);throw vc(t,z),t},mc=e=>typeof e=="bigint",yc=e=>typeof e=="string",bc=e=>e instanceof Uint8Array||ArrayBuffer.isView(e)&&e.constructor.name==="Uint8Array",Te=(e,t,n="")=>{const s=bc(e),i=e?.length,r=t!==void 0;if(!s||r&&i!==t){const a=n&&`"${n}" `,o=r?` of length ${t}`:"",c=s?`length=${i}`:`type=${typeof e}`;z(a+"expected Uint8Array"+o+", got "+c)}return e},gn=e=>new Uint8Array(e),ha=e=>Uint8Array.from(e),ga=(e,t)=>e.toString(16).padStart(t,"0"),va=e=>Array.from(Te(e)).map(t=>ga(t,2)).join(""),me={_0:48,_9:57,A:65,F:70,a:97,f:102},tr=e=>{if(e>=me._0&&e<=me._9)return e-me._0;if(e>=me.A&&e<=me.F)return e-(me.A-10);if(e>=me.a&&e<=me.f)return e-(me.a-10)},ma=e=>{const t="hex invalid";if(!yc(e))return z(t);const n=e.length,s=n/2;if(n%2)return z(t);const i=gn(s);for(let r=0,a=0;r<s;r++,a+=2){const o=tr(e.charCodeAt(a)),c=tr(e.charCodeAt(a+1));if(o===void 0||c===void 0)return z(t);i[r]=o*16+c}return i},ya=()=>globalThis?.crypto,$c=()=>ya()?.subtle??z("crypto.subtle must be defined, consider polyfill"),Ct=(...e)=>{const t=gn(e.reduce((s,i)=>s+Te(i).length,0));let n=0;return e.forEach(s=>{t.set(s,n),n+=s.length}),t},wc=(e=Fe)=>ya().getRandomValues(gn(e)),tn=BigInt,Pe=(e,t,n,s="bad number: out of range")=>mc(e)&&t<=e&&e<n?e:z(s),S=(e,t=W)=>{const n=e%t;return n>=0n?n:t+n},ba=e=>S(e,Zt),xc=(e,t)=>{(e===0n||t<=0n)&&z("no inverse n="+e+" mod="+t);let n=S(e,t),s=t,i=0n,r=1n;for(;n!==0n;){const a=s/n,o=s%n,c=i-r*a;s=n,n=o,i=r,r=c}return s===1n?S(i,t):z("no inverse")},Ac=e=>{const t=Aa[e];return typeof t!="function"&&z("hashes."+e+" not set"),t},jn=e=>e instanceof ne?e:z("Point expected"),ds=2n**256n;class ne{static BASE;static ZERO;X;Y;Z;T;constructor(t,n,s,i){const r=ds;this.X=Pe(t,0n,r),this.Y=Pe(n,0n,r),this.Z=Pe(s,1n,r),this.T=Pe(i,0n,r),Object.freeze(this)}static CURVE(){return fa}static fromAffine(t){return new ne(t.x,t.y,1n,S(t.x*t.y))}static fromBytes(t,n=!1){const s=zn,i=ha(Te(t,Fe)),r=t[31];i[31]=r&-129;const a=wa(i);Pe(a,0n,n?ds:W);const c=S(a*a),p=S(c-1n),d=S(s*c+1n);let{isValid:u,value:v}=Sc(p,d);u||z("bad point: y not sqrt");const g=(v&1n)===1n,y=(r&128)!==0;return!n&&v===0n&&y&&z("bad point: x==0, isLastByteOdd"),y!==g&&(v=S(-v)),new ne(v,a,1n,S(v*a))}static fromHex(t,n){return ne.fromBytes(ma(t),n)}get x(){return this.toAffine().x}get y(){return this.toAffine().y}assertValidity(){const t=Hn,n=zn,s=this;if(s.is0())return z("bad point: ZERO");const{X:i,Y:r,Z:a,T:o}=s,c=S(i*i),p=S(r*r),d=S(a*a),u=S(d*d),v=S(c*t),g=S(d*S(v+p)),y=S(u+S(n*S(c*p)));if(g!==y)return z("bad point: equation left != right (1)");const w=S(i*r),A=S(a*o);return w!==A?z("bad point: equation left != right (2)"):this}equals(t){const{X:n,Y:s,Z:i}=this,{X:r,Y:a,Z:o}=jn(t),c=S(n*o),p=S(r*i),d=S(s*o),u=S(a*i);return c===p&&d===u}is0(){return this.equals(Xe)}negate(){return new ne(S(-this.X),this.Y,this.Z,S(-this.T))}double(){const{X:t,Y:n,Z:s}=this,i=Hn,r=S(t*t),a=S(n*n),o=S(2n*S(s*s)),c=S(i*r),p=t+n,d=S(S(p*p)-r-a),u=c+a,v=u-o,g=c-a,y=S(d*v),w=S(u*g),A=S(d*g),E=S(v*u);return new ne(y,w,E,A)}add(t){const{X:n,Y:s,Z:i,T:r}=this,{X:a,Y:o,Z:c,T:p}=jn(t),d=Hn,u=zn,v=S(n*a),g=S(s*o),y=S(r*u*p),w=S(i*c),A=S((n+s)*(a+o)-v-g),E=S(w-y),C=S(w+y),O=S(g-d*v),I=S(A*E),L=S(C*O),k=S(A*O),N=S(E*C);return new ne(I,L,N,k)}subtract(t){return this.add(jn(t).negate())}multiply(t,n=!0){if(!n&&(t===0n||this.is0()))return Xe;if(Pe(t,1n,Zt),t===1n)return this;if(this.equals(Ue))return Oc(t).p;let s=Xe,i=Ue;for(let r=this;t>0n;r=r.double(),t>>=1n)t&1n?s=s.add(r):n&&(i=i.add(r));return s}multiplyUnsafe(t){return this.multiply(t,!1)}toAffine(){const{X:t,Y:n,Z:s}=this;if(this.equals(Xe))return{x:0n,y:1n};const i=xc(s,W);S(s*i)!==1n&&z("invalid inverse");const r=S(t*i),a=S(n*i);return{x:r,y:a}}toBytes(){const{x:t,y:n}=this.assertValidity().toAffine(),s=$a(n);return s[31]|=t&1n?128:0,s}toHex(){return va(this.toBytes())}clearCofactor(){return this.multiply(tn(gc),!1)}isSmallOrder(){return this.clearCofactor().is0()}isTorsionFree(){let t=this.multiply(Zt/2n,!1).double();return Zt%2n&&(t=t.add(this)),t.is0()}}const Ue=new ne(Ji,er,1n,S(Ji*er)),Xe=new ne(0n,1n,1n,0n);ne.BASE=Ue;ne.ZERO=Xe;const $a=e=>ma(ga(Pe(e,0n,ds),Bs)).reverse(),wa=e=>tn("0x"+va(ha(Te(e)).reverse())),ue=(e,t)=>{let n=e;for(;t-- >0n;)n*=n,n%=W;return n},kc=e=>{const n=e*e%W*e%W,s=ue(n,2n)*n%W,i=ue(s,1n)*e%W,r=ue(i,5n)*i%W,a=ue(r,10n)*r%W,o=ue(a,20n)*a%W,c=ue(o,40n)*o%W,p=ue(c,80n)*c%W,d=ue(p,80n)*c%W,u=ue(d,10n)*r%W;return{pow_p_5_8:ue(u,2n)*e%W,b2:n}},nr=0x2b8324804fc1df0b2b4d00993dfbd7a72f431806ad2fe478c4ee1b274a0ea0b0n,Sc=(e,t)=>{const n=S(t*t*t),s=S(n*n*t),i=kc(e*s).pow_p_5_8;let r=S(e*n*i);const a=S(t*r*r),o=r,c=S(r*nr),p=a===e,d=a===S(-e),u=a===S(-e*nr);return p&&(r=o),(d||u)&&(r=c),(S(r)&1n)===1n&&(r=S(-r)),{isValid:p||d,value:r}},us=e=>ba(wa(e)),Fs=(...e)=>Aa.sha512Async(Ct(...e)),_c=(...e)=>Ac("sha512")(Ct(...e)),xa=e=>{const t=e.slice(0,Fe);t[0]&=248,t[31]&=127,t[31]|=64;const n=e.slice(Fe,Bs),s=us(t),i=Ue.multiply(s),r=i.toBytes();return{head:t,prefix:n,scalar:s,point:i,pointBytes:r}},Us=e=>Fs(Te(e,Fe)).then(xa),Tc=e=>xa(_c(Te(e,Fe))),Ec=e=>Us(e).then(t=>t.pointBytes),Cc=e=>Fs(e.hashable).then(e.finish),Mc=(e,t,n)=>{const{pointBytes:s,scalar:i}=e,r=us(t),a=Ue.multiply(r).toBytes();return{hashable:Ct(a,s,n),finish:p=>{const d=ba(r+us(p)*i);return Te(Ct(a,$a(d)),Bs)}}},Ic=async(e,t)=>{const n=Te(e),s=await Us(t),i=await Fs(s.prefix,n);return Cc(Mc(s,i,n))},Aa={sha512Async:async e=>{const t=$c(),n=Ct(e);return gn(await t.digest("SHA-512",n.buffer))},sha512:void 0},Lc=(e=wc(Fe))=>e,Rc={getExtendedPublicKeyAsync:Us,getExtendedPublicKey:Tc,randomSecretKey:Lc},nn=8,Pc=256,ka=Math.ceil(Pc/nn)+1,ps=2**(nn-1),Nc=()=>{const e=[];let t=Ue,n=t;for(let s=0;s<ka;s++){n=t,e.push(n);for(let i=1;i<ps;i++)n=n.add(t),e.push(n);t=n.double()}return e};let sr;const ir=(e,t)=>{const n=t.negate();return e?n:t},Oc=e=>{const t=sr||(sr=Nc());let n=Xe,s=Ue;const i=2**nn,r=i,a=tn(i-1),o=tn(nn);for(let c=0;c<ka;c++){let p=Number(e&a);e>>=o,p>ps&&(p-=r,e+=1n);const d=c*ps,u=d,v=d+Math.abs(p)-1,g=c%2!==0,y=p<0;p===0?s=s.add(ir(g,t[u])):n=n.add(ir(y,t[v]))}return e!==0n&&z("invalid wnaf"),{p:n,f:s}},qn="clawdbot-device-identity-v1";function fs(e){let t="";for(const n of e)t+=String.fromCharCode(n);return btoa(t).replaceAll("+","-").replaceAll("/","_").replace(/=+$/g,"")}function Sa(e){const t=e.replaceAll("-","+").replaceAll("_","/"),n=t+"=".repeat((4-t.length%4)%4),s=atob(n),i=new Uint8Array(s.length);for(let r=0;r<s.length;r+=1)i[r]=s.charCodeAt(r);return i}function Dc(e){return Array.from(e).map(t=>t.toString(16).padStart(2,"0")).join("")}async function _a(e){const t=await crypto.subtle.digest("SHA-256",e);return Dc(new Uint8Array(t))}async function Bc(){const e=Rc.randomSecretKey(),t=await Ec(e);return{deviceId:await _a(t),publicKey:fs(t),privateKey:fs(e)}}async function Ks(){try{const n=localStorage.getItem(qn);if(n){const s=JSON.parse(n);if(s?.version===1&&typeof s.deviceId=="string"&&typeof s.publicKey=="string"&&typeof s.privateKey=="string"){const i=await _a(Sa(s.publicKey));if(i!==s.deviceId){const r={...s,deviceId:i};return localStorage.setItem(qn,JSON.stringify(r)),{deviceId:i,publicKey:s.publicKey,privateKey:s.privateKey}}return{deviceId:s.deviceId,publicKey:s.publicKey,privateKey:s.privateKey}}}}catch{}const e=await Bc(),t={version:1,deviceId:e.deviceId,publicKey:e.publicKey,privateKey:e.privateKey,createdAtMs:Date.now()};return localStorage.setItem(qn,JSON.stringify(t)),e}async function Fc(e,t){const n=Sa(e),s=new TextEncoder().encode(t),i=await Ic(s,n);return fs(i)}const Ta="clawdbot.device.auth.v1";function Hs(e){return e.trim()}function Uc(e){if(!Array.isArray(e))return[];const t=new Set;for(const n of e){const s=n.trim();s&&t.add(s)}return[...t].sort()}function zs(){try{const e=window.localStorage.getItem(Ta);if(!e)return null;const t=JSON.parse(e);return!t||t.version!==1||!t.deviceId||typeof t.deviceId!="string"||!t.tokens||typeof t.tokens!="object"?null:t}catch{return null}}function Ea(e){try{window.localStorage.setItem(Ta,JSON.stringify(e))}catch{}}function Kc(e){const t=zs();if(!t||t.deviceId!==e.deviceId)return null;const n=Hs(e.role),s=t.tokens[n];return!s||typeof s.token!="string"?null:s}function Ca(e){const t=Hs(e.role),n={version:1,deviceId:e.deviceId,tokens:{}},s=zs();s&&s.deviceId===e.deviceId&&(n.tokens={...s.tokens});const i={token:e.token,role:t,scopes:Uc(e.scopes),updatedAtMs:Date.now()};return n.tokens[t]=i,Ea(n),i}function Ma(e){const t=zs();if(!t||t.deviceId!==e.deviceId)return;const n=Hs(e.role);if(!t.tokens[n])return;const s={...t,tokens:{...t.tokens}};delete s.tokens[n],Ea(s)}async function Ee(e,t){if(!(!e.client||!e.connected)&&!e.devicesLoading){e.devicesLoading=!0,t?.quiet||(e.devicesError=null);try{const n=await e.client.request("device.pair.list",{});e.devicesList={pending:Array.isArray(n?.pending)?n.pending:[],paired:Array.isArray(n?.paired)?n.paired:[]}}catch(n){t?.quiet||(e.devicesError=String(n))}finally{e.devicesLoading=!1}}}async function Hc(e,t){if(!(!e.client||!e.connected))try{await e.client.request("device.pair.approve",{requestId:t}),await Ee(e)}catch(n){e.devicesError=String(n)}}async function zc(e,t){if(!(!e.client||!e.connected||!window.confirm("Reject this device pairing request?")))try{await e.client.request("device.pair.reject",{requestId:t}),await Ee(e)}catch(s){e.devicesError=String(s)}}async function jc(e,t){if(!(!e.client||!e.connected))try{const n=await e.client.request("device.token.rotate",t);if(n?.token){const s=await Ks(),i=n.role??t.role;(n.deviceId===s.deviceId||t.deviceId===s.deviceId)&&Ca({deviceId:s.deviceId,role:i,token:n.token,scopes:n.scopes??t.scopes??[]}),window.prompt("New device token (copy and store securely):",n.token)}await Ee(e)}catch(n){e.devicesError=String(n)}}async function qc(e,t){if(!(!e.client||!e.connected||!window.confirm(`Revoke token for ${t.deviceId} (${t.role})?`)))try{await e.client.request("device.token.revoke",t);const s=await Ks();t.deviceId===s.deviceId&&Ma({deviceId:s.deviceId,role:t.role}),await Ee(e)}catch(s){e.devicesError=String(s)}}async function vn(e,t){if(!(!e.client||!e.connected)&&!e.nodesLoading){e.nodesLoading=!0,t?.quiet||(e.lastError=null);try{const n=await e.client.request("node.list",{});e.nodes=Array.isArray(n.nodes)?n.nodes:[]}catch(n){t?.quiet||(e.lastError=String(n))}finally{e.nodesLoading=!1}}}function Vc(e){if(!e||e.kind==="gateway")return{method:"exec.approvals.get",params:{}};const t=e.nodeId.trim();return t?{method:"exec.approvals.node.get",params:{nodeId:t}}:null}function Wc(e,t){if(!e||e.kind==="gateway")return{method:"exec.approvals.set",params:t};const n=e.nodeId.trim();return n?{method:"exec.approvals.node.set",params:{...t,nodeId:n}}:null}async function js(e,t){if(!(!e.client||!e.connected)&&!e.execApprovalsLoading){e.execApprovalsLoading=!0,e.lastError=null;try{const n=Vc(t);if(!n){e.lastError="Select a node before loading exec approvals.";return}const s=await e.client.request(n.method,n.params);Gc(e,s)}catch(n){e.lastError=String(n)}finally{e.execApprovalsLoading=!1}}}function Gc(e,t){e.execApprovalsSnapshot=t,e.execApprovalsDirty||(e.execApprovalsForm=Be(t.file??{}))}async function Qc(e,t){if(!(!e.client||!e.connected)){e.execApprovalsSaving=!0,e.lastError=null;try{const n=e.execApprovalsSnapshot?.hash;if(!n){e.lastError="Exec approvals hash missing; reload and retry.";return}const s=e.execApprovalsForm??e.execApprovalsSnapshot?.file??{},i=Wc(t,{file:s,baseHash:n});if(!i){e.lastError="Select a node before saving exec approvals.";return}await e.client.request(i.method,i.params),e.execApprovalsDirty=!1,await js(e,t)}catch(n){e.lastError=String(n)}finally{e.execApprovalsSaving=!1}}}function Zc(e,t,n){const s=Be(e.execApprovalsForm??e.execApprovalsSnapshot?.file??{});ca(s,t,n),e.execApprovalsForm=s,e.execApprovalsDirty=!0}function Yc(e,t){const n=Be(e.execApprovalsForm??e.execApprovalsSnapshot?.file??{});da(n,t),e.execApprovalsForm=n,e.execApprovalsDirty=!0}async function qs(e){if(!(!e.client||!e.connected)&&!e.presenceLoading){e.presenceLoading=!0,e.presenceError=null,e.presenceStatus=null;try{const t=await e.client.request("system-presence",{});Array.isArray(t)?(e.presenceEntries=t,e.presenceStatus=t.length===0?"No instances yet.":null):(e.presenceEntries=[],e.presenceStatus="No presence payload.")}catch(t){e.presenceError=String(t)}finally{e.presenceLoading=!1}}}function st(e,t,n){if(!t.trim())return;const s={...e.skillMessages};n?s[t]=n:delete s[t],e.skillMessages=s}function mn(e){return e instanceof Error?e.message:String(e)}async function It(e,t){if(t?.clearMessages&&Object.keys(e.skillMessages).length>0&&(e.skillMessages={}),!(!e.client||!e.connected)&&!e.skillsLoading){e.skillsLoading=!0,e.skillsError=null;try{const n=await e.client.request("skills.status",{});n&&(e.skillsReport=n)}catch(n){e.skillsError=mn(n)}finally{e.skillsLoading=!1}}}function Xc(e,t,n){e.skillEdits={...e.skillEdits,[t]:n}}async function Jc(e,t,n){if(!(!e.client||!e.connected)){e.skillsBusyKey=t,e.skillsError=null;try{await e.client.request("skills.update",{skillKey:t,enabled:n}),await It(e),st(e,t,{kind:"success",message:n?"Skill enabled":"Skill disabled"})}catch(s){const i=mn(s);e.skillsError=i,st(e,t,{kind:"error",message:i})}finally{e.skillsBusyKey=null}}}async function ed(e,t){if(!(!e.client||!e.connected)){e.skillsBusyKey=t,e.skillsError=null;try{const n=e.skillEdits[t]??"";await e.client.request("skills.update",{skillKey:t,apiKey:n}),await It(e),st(e,t,{kind:"success",message:"API key saved"})}catch(n){const s=mn(n);e.skillsError=s,st(e,t,{kind:"error",message:s})}finally{e.skillsBusyKey=null}}}async function td(e,t,n,s){if(!(!e.client||!e.connected)){e.skillsBusyKey=t,e.skillsError=null;try{const i=await e.client.request("skills.install",{name:n,installId:s,timeoutMs:12e4});await It(e),st(e,t,{kind:"success",message:i?.message??"Installed"})}catch(i){const r=mn(i);e.skillsError=r,st(e,t,{kind:"error",message:r})}finally{e.skillsBusyKey=null}}}function nd(){return typeof window>"u"||typeof window.matchMedia!="function"||window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}function Vs(e){return e==="system"?nd():e}const zt=e=>Number.isNaN(e)?.5:e<=0?0:e>=1?1:e,sd=()=>typeof window>"u"||typeof window.matchMedia!="function"?!1:window.matchMedia("(prefers-reduced-motion: reduce)").matches??!1,jt=e=>{e.classList.remove("theme-transition"),e.style.removeProperty("--theme-switch-x"),e.style.removeProperty("--theme-switch-y")},id=({nextTheme:e,applyTheme:t,context:n,currentTheme:s})=>{if(s===e)return;const i=globalThis.document??null;if(!i){t();return}const r=i.documentElement,a=i,o=sd();if(!!a.startViewTransition&&!o){let p=.5,d=.5;if(n?.pointerClientX!==void 0&&n?.pointerClientY!==void 0&&typeof window<"u")p=zt(n.pointerClientX/window.innerWidth),d=zt(n.pointerClientY/window.innerHeight);else if(n?.element){const u=n.element.getBoundingClientRect();u.width>0&&u.height>0&&typeof window<"u"&&(p=zt((u.left+u.width/2)/window.innerWidth),d=zt((u.top+u.height/2)/window.innerHeight))}r.style.setProperty("--theme-switch-x",`${p*100}%`),r.style.setProperty("--theme-switch-y",`${d*100}%`),r.classList.add("theme-transition");try{const u=a.startViewTransition?.(()=>{t()});u?.finished?u.finished.finally(()=>jt(r)):jt(r)}catch{jt(r),t()}return}t(),jt(r)};function rd(e){e.nodesPollInterval==null&&(e.nodesPollInterval=window.setInterval(()=>{vn(e,{quiet:!0})},5e3))}function ad(e){e.nodesPollInterval!=null&&(clearInterval(e.nodesPollInterval),e.nodesPollInterval=null)}function Ws(e){e.logsPollInterval==null&&(e.logsPollInterval=window.setInterval(()=>{e.tab==="logs"&&Ds(e,{quiet:!0})},2e3))}function Gs(e){e.logsPollInterval!=null&&(clearInterval(e.logsPollInterval),e.logsPollInterval=null)}function Qs(e){e.debugPollInterval==null&&(e.debugPollInterval=window.setInterval(()=>{e.tab==="debug"&&hn(e)},3e3))}function Zs(e){e.debugPollInterval!=null&&(clearInterval(e.debugPollInterval),e.debugPollInterval=null)}function ke(e,t){const n={...t,lastActiveSessionKey:t.lastActiveSessionKey?.trim()||t.sessionKey.trim()||"main"};e.settings=n,fl(n),t.theme!==e.theme&&(e.theme=t.theme,yn(e,Vs(t.theme))),e.applySessionKey=e.settings.lastActiveSessionKey}function Ia(e,t){const n=t.trim();n&&e.settings.lastActiveSessionKey!==n&&ke(e,{...e.settings,lastActiveSessionKey:n})}function od(e){if(!window.location.search)return;const t=new URLSearchParams(window.location.search),n=t.get("token"),s=t.get("password"),i=t.get("session"),r=t.get("gatewayUrl");let a=!1;if(n!=null){const c=n.trim();c&&c!==e.settings.token&&ke(e,{...e.settings,token:c}),t.delete("token"),a=!0}if(s!=null){const c=s.trim();c&&(e.password=c),t.delete("password"),a=!0}if(i!=null){const c=i.trim();c&&(e.sessionKey=c,ke(e,{...e.settings,sessionKey:c,lastActiveSessionKey:c}))}if(r!=null){const c=r.trim();c&&c!==e.settings.gatewayUrl&&ke(e,{...e.settings,gatewayUrl:c}),t.delete("gatewayUrl"),a=!0}if(!a)return;const o=new URL(window.location.href);o.search=t.toString(),window.history.replaceState({},"",o.toString())}function ld(e,t){e.tab!==t&&(e.tab=t),t==="chat"&&(e.chatHasAutoScrolled=!1),t==="logs"?Ws(e):Gs(e),t==="debug"?Qs(e):Zs(e),Ys(e),Ra(e,t,!1)}function cd(e,t,n){id({nextTheme:t,applyTheme:()=>{e.theme=t,ke(e,{...e.settings,theme:t}),yn(e,Vs(t))},context:n,currentTheme:e.theme})}async function Ys(e){e.tab==="overview"&&await Pa(e),e.tab==="channels"&&await md(e),e.tab==="instances"&&await qs(e),e.tab==="sessions"&&await at(e),e.tab==="cron"&&await Xs(e),e.tab==="skills"&&await It(e),e.tab==="nodes"&&(await vn(e),await Ee(e),await be(e),await js(e)),e.tab==="chat"&&(await xd(e),pn(e,!e.chatHasAutoScrolled)),e.tab==="config"&&(await ua(e),await be(e)),e.tab==="debug"&&(await hn(e),e.eventLog=e.eventLogBuffer),e.tab==="logs"&&(e.logsAtBottom=!0,await Ds(e,{reset:!0}),la(e,!0))}function dd(){if(typeof window>"u")return"";const e=window.__CLAWDBOT_CONTROL_UI_BASE_PATH__;return typeof e=="string"&&e.trim()?un(e):gl(window.location.pathname)}function ud(e){e.theme=e.settings.theme??"system",yn(e,Vs(e.theme))}function yn(e,t){if(e.themeResolved=t,typeof document>"u")return;const n=document.documentElement;n.dataset.theme=t,n.style.colorScheme=t}function pd(e){if(typeof window>"u"||typeof window.matchMedia!="function")return;if(e.themeMedia=window.matchMedia("(prefers-color-scheme: dark)"),e.themeMediaHandler=n=>{e.theme==="system"&&yn(e,n.matches?"dark":"light")},typeof e.themeMedia.addEventListener=="function"){e.themeMedia.addEventListener("change",e.themeMediaHandler);return}e.themeMedia.addListener(e.themeMediaHandler)}function fd(e){if(!e.themeMedia||!e.themeMediaHandler)return;if(typeof e.themeMedia.removeEventListener=="function"){e.themeMedia.removeEventListener("change",e.themeMediaHandler);return}e.themeMedia.removeListener(e.themeMediaHandler),e.themeMedia=null,e.themeMediaHandler=null}function hd(e,t){if(typeof window>"u")return;const n=ia(window.location.pathname,e.basePath)??"chat";La(e,n),Ra(e,n,t)}function gd(e){if(typeof window>"u")return;const t=ia(window.location.pathname,e.basePath);if(!t)return;const s=new URL(window.location.href).searchParams.get("session")?.trim();s&&(e.sessionKey=s,ke(e,{...e.settings,sessionKey:s,lastActiveSessionKey:s})),La(e,t)}function La(e,t){e.tab!==t&&(e.tab=t),t==="chat"&&(e.chatHasAutoScrolled=!1),t==="logs"?Ws(e):Gs(e),t==="debug"?Qs(e):Zs(e),e.connected&&Ys(e)}function Ra(e,t,n){if(typeof window>"u")return;const s=Tt(Ps(t,e.basePath)),i=Tt(window.location.pathname),r=new URL(window.location.href);t==="chat"&&e.sessionKey?r.searchParams.set("session",e.sessionKey):r.searchParams.delete("session"),i!==s&&(r.pathname=s),n?window.history.replaceState({},"",r.toString()):window.history.pushState({},"",r.toString())}function vd(e,t,n){if(typeof window>"u")return;const s=new URL(window.location.href);s.searchParams.set("session",t),window.history.replaceState({},"",s.toString())}async function Pa(e){await Promise.all([le(e,!1),qs(e),at(e),Mt(e),hn(e)])}async function md(e){await Promise.all([le(e,!0),ua(e),be(e)])}async function Xs(e){await Promise.all([le(e,!1),Mt(e),fn(e)])}function Na(e){return e.chatSending||!!e.chatRunId}function yd(e){const t=e.trim();if(!t)return!1;const n=t.toLowerCase();return n==="/stop"?!0:n==="stop"||n==="esc"||n==="abort"||n==="wait"||n==="exit"}async function Oa(e){e.connected&&(e.chatMessage="",await Ml(e))}function bd(e,t,n){const s=t.trim(),i=!!(n&&n.length>0);!s&&!i||(e.chatQueue=[...e.chatQueue,{id:Ns(),text:s,createdAt:Date.now(),attachments:i?n?.map(r=>({...r})):void 0}])}async function Da(e,t,n){Os(e);const s=await Cl(e,t,n?.attachments);return!s&&n?.previousDraft!=null&&(e.chatMessage=n.previousDraft),!s&&n?.previousAttachments&&(e.chatAttachments=n.previousAttachments),s&&Ia(e,e.sessionKey),s&&n?.restoreDraft&&n.previousDraft?.trim()&&(e.chatMessage=n.previousDraft),s&&n?.restoreAttachments&&n.previousAttachments?.length&&(e.chatAttachments=n.previousAttachments),pn(e),s&&!e.chatRunId&&Ba(e),s}async function Ba(e){if(!e.connected||Na(e))return;const[t,...n]=e.chatQueue;if(!t)return;e.chatQueue=n,await Da(e,t.text,{attachments:t.attachments})||(e.chatQueue=[t,...e.chatQueue])}function $d(e,t){e.chatQueue=e.chatQueue.filter(n=>n.id!==t)}async function wd(e,t,n){if(!e.connected)return;const s=e.chatMessage,i=(t??e.chatMessage).trim(),r=e.chatAttachments??[],a=t==null?r:[],o=a.length>0;if(!(!i&&!o)){if(yd(i)){await Oa(e);return}if(t==null&&(e.chatMessage="",e.chatAttachments=[]),Na(e)){bd(e,i,a);return}await Da(e,i,{previousDraft:t==null?s:void 0,restoreDraft:!!(t&&n?.restoreDraft),attachments:o?a:void 0,previousAttachments:t==null?r:void 0,restoreAttachments:!!(t&&n?.restoreDraft)})}}async function xd(e){await Promise.all([tt(e),at(e),hs(e)]),pn(e,!0)}const Ad=Ba;function kd(e){const t=ta(e.sessionKey);return t?.agentId?t.agentId:e.hello?.snapshot?.sessionDefaults?.defaultAgentId?.trim()||"main"}function Sd(e,t){const n=un(e),s=encodeURIComponent(t);return n?`${n}/avatar/${s}?meta=1`:`/avatar/${s}?meta=1`}async function hs(e){if(!e.connected){e.chatAvatarUrl=null;return}const t=kd(e);if(!t){e.chatAvatarUrl=null;return}e.chatAvatarUrl=null;const n=Sd(e.basePath,t);try{const s=await fetch(n,{method:"GET"});if(!s.ok){e.chatAvatarUrl=null;return}const i=await s.json(),r=typeof i.avatarUrl=="string"?i.avatarUrl.trim():"";e.chatAvatarUrl=r||null}catch{e.chatAvatarUrl=null}}const Fa={CHILD:2},Ua=e=>(...t)=>({_$litDirective$:e,values:t});let Ka=class{constructor(t){}get _$AU(){return this._$AM._$AU}_$AT(t,n,s){this._$Ct=t,this._$AM=n,this._$Ci=s}_$AS(t,n){return this.update(t,n)}update(t,n){return this.render(...n)}};const{I:_d}=nl,rr=e=>e,ar=()=>document.createComment(""),ut=(e,t,n)=>{const s=e._$AA.parentNode,i=t===void 0?e._$AB:t._$AA;if(n===void 0){const r=s.insertBefore(ar(),i),a=s.insertBefore(ar(),i);n=new _d(r,a,e,e.options)}else{const r=n._$AB.nextSibling,a=n._$AM,o=a!==e;if(o){let c;n._$AQ?.(e),n._$AM=e,n._$AP!==void 0&&(c=e._$AU)!==a._$AU&&n._$AP(c)}if(r!==i||o){let c=n._$AA;for(;c!==r;){const p=rr(c).nextSibling;rr(s).insertBefore(c,i),c=p}}}return n},Le=(e,t,n=e)=>(e._$AI(t,n),e),Td={},Ed=(e,t=Td)=>e._$AH=t,Cd=e=>e._$AH,Vn=e=>{e._$AR(),e._$AA.remove()};const or=(e,t,n)=>{const s=new Map;for(let i=t;i<=n;i++)s.set(e[i],i);return s},Ha=Ua(class extends Ka{constructor(e){if(super(e),e.type!==Fa.CHILD)throw Error("repeat() can only be used in text expressions")}dt(e,t,n){let s;n===void 0?n=t:t!==void 0&&(s=t);const i=[],r=[];let a=0;for(const o of e)i[a]=s?s(o,a):a,r[a]=n(o,a),a++;return{values:r,keys:i}}render(e,t,n){return this.dt(e,t,n).values}update(e,[t,n,s]){const i=Cd(e),{values:r,keys:a}=this.dt(t,n,s);if(!Array.isArray(i))return this.ut=a,r;const o=this.ut??=[],c=[];let p,d,u=0,v=i.length-1,g=0,y=r.length-1;for(;u<=v&&g<=y;)if(i[u]===null)u++;else if(i[v]===null)v--;else if(o[u]===a[g])c[g]=Le(i[u],r[g]),u++,g++;else if(o[v]===a[y])c[y]=Le(i[v],r[y]),v--,y--;else if(o[u]===a[y])c[y]=Le(i[u],r[y]),ut(e,c[y+1],i[u]),u++,y--;else if(o[v]===a[g])c[g]=Le(i[v],r[g]),ut(e,i[u],i[v]),v--,g++;else if(p===void 0&&(p=or(a,g,y),d=or(o,u,v)),p.has(o[u]))if(p.has(o[v])){const w=d.get(a[g]),A=w!==void 0?i[w]:null;if(A===null){const E=ut(e,i[u]);Le(E,r[g]),c[g]=E}else c[g]=Le(A,r[g]),ut(e,i[u],A),i[w]=null;g++}else Vn(i[v]),v--;else Vn(i[u]),u++;for(;g<=y;){const w=ut(e,c[y+1]);Le(w,r[g]),c[g++]=w}for(;u<=v;){const w=i[u++];w!==null&&Vn(w)}return this.ut=a,Ed(e,c),_e}});function za(e){const t=e;let n=typeof t.role=="string"?t.role:"unknown";const s=typeof t.toolCallId=="string"||typeof t.tool_call_id=="string",i=t.content,r=Array.isArray(i)?i:null,a=Array.isArray(r)&&r.some(u=>{const g=String(u.type??"").toLowerCase();return g==="toolresult"||g==="tool_result"}),o=typeof t.toolName=="string"||typeof t.tool_name=="string";(s||a||o)&&(n="toolResult");let c=[];typeof t.content=="string"?c=[{type:"text",text:t.content}]:Array.isArray(t.content)?c=t.content.map(u=>({type:u.type||"text",text:u.text,name:u.name,args:u.args||u.arguments})):typeof t.text=="string"&&(c=[{type:"text",text:t.text}]);const p=typeof t.timestamp=="number"?t.timestamp:Date.now(),d=typeof t.id=="string"?t.id:void 0;return{role:n,content:c,timestamp:p,id:d}}function Js(e){const t=e.toLowerCase();return e==="user"||e==="User"?e:e==="assistant"?"assistant":e==="system"?"system":t==="toolresult"||t==="tool_result"||t==="tool"||t==="function"?"tool":e}function ja(e){const t=e,n=typeof t.role=="string"?t.role.toLowerCase():"";return n==="toolresult"||n==="tool_result"}class gs extends Ka{constructor(t){if(super(t),this.it=h,t.type!==Fa.CHILD)throw Error(this.constructor.directiveName+"() can only be used in child bindings")}render(t){if(t===h||t==null)return this._t=void 0,this.it=t;if(t===_e)return t;if(typeof t!="string")throw Error(this.constructor.directiveName+"() called with a non-string value");if(t===this.it)return this._t;this.it=t;const n=[t];return n.raw=n,this._t={_$litType$:this.constructor.resultType,strings:n,values:[]}}}gs.directiveName="unsafeHTML",gs.resultType=1;const vs=Ua(gs);const{entries:qa,setPrototypeOf:lr,isFrozen:Md,getPrototypeOf:Id,getOwnPropertyDescriptor:Ld}=Object;let{freeze:X,seal:ie,create:ms}=Object,{apply:ys,construct:bs}=typeof Reflect<"u"&&Reflect;X||(X=function(t){return t});ie||(ie=function(t){return t});ys||(ys=function(t,n){for(var s=arguments.length,i=new Array(s>2?s-2:0),r=2;r<s;r++)i[r-2]=arguments[r];return t.apply(n,i)});bs||(bs=function(t){for(var n=arguments.length,s=new Array(n>1?n-1:0),i=1;i<n;i++)s[i-1]=arguments[i];return new t(...s)});const qt=J(Array.prototype.forEach),Rd=J(Array.prototype.lastIndexOf),cr=J(Array.prototype.pop),pt=J(Array.prototype.push),Pd=J(Array.prototype.splice),Yt=J(String.prototype.toLowerCase),Wn=J(String.prototype.toString),Gn=J(String.prototype.match),ft=J(String.prototype.replace),Nd=J(String.prototype.indexOf),Od=J(String.prototype.trim),re=J(Object.prototype.hasOwnProperty),Z=J(RegExp.prototype.test),ht=Dd(TypeError);function J(e){return function(t){t instanceof RegExp&&(t.lastIndex=0);for(var n=arguments.length,s=new Array(n>1?n-1:0),i=1;i<n;i++)s[i-1]=arguments[i];return ys(e,t,s)}}function Dd(e){return function(){for(var t=arguments.length,n=new Array(t),s=0;s<t;s++)n[s]=arguments[s];return bs(e,n)}}function M(e,t){let n=arguments.length>2&&arguments[2]!==void 0?arguments[2]:Yt;lr&&lr(e,null);let s=t.length;for(;s--;){let i=t[s];if(typeof i=="string"){const r=n(i);r!==i&&(Md(t)||(t[s]=r),i=r)}e[i]=!0}return e}function Bd(e){for(let t=0;t<e.length;t++)re(e,t)||(e[t]=null);return e}function pe(e){const t=ms(null);for(const[n,s]of qa(e))re(e,n)&&(Array.isArray(s)?t[n]=Bd(s):s&&typeof s=="object"&&s.constructor===Object?t[n]=pe(s):t[n]=s);return t}function gt(e,t){for(;e!==null;){const s=Ld(e,t);if(s){if(s.get)return J(s.get);if(typeof s.value=="function")return J(s.value)}e=Id(e)}function n(){return null}return n}const dr=X(["a","abbr","acronym","address","area","article","aside","audio","b","bdi","bdo","big","blink","blockquote","body","br","button","canvas","caption","center","cite","code","col","colgroup","content","data","datalist","dd","decorator","del","details","dfn","dialog","dir","div","dl","dt","element","em","fieldset","figcaption","figure","font","footer","form","h1","h2","h3","h4","h5","h6","head","header","hgroup","hr","html","i","img","input","ins","kbd","label","legend","li","main","map","mark","marquee","menu","menuitem","meter","nav","nobr","ol","optgroup","option","output","p","picture","pre","progress","q","rp","rt","ruby","s","samp","search","section","select","shadow","slot","small","source","spacer","span","strike","strong","style","sub","summary","sup","table","tbody","td","template","textarea","tfoot","th","thead","time","tr","track","tt","u","ul","var","video","wbr"]),Qn=X(["svg","a","altglyph","altglyphdef","altglyphitem","animatecolor","animatemotion","animatetransform","circle","clippath","defs","desc","ellipse","enterkeyhint","exportparts","filter","font","g","glyph","glyphref","hkern","image","inputmode","line","lineargradient","marker","mask","metadata","mpath","part","path","pattern","polygon","polyline","radialgradient","rect","stop","style","switch","symbol","text","textpath","title","tref","tspan","view","vkern"]),Zn=X(["feBlend","feColorMatrix","feComponentTransfer","feComposite","feConvolveMatrix","feDiffuseLighting","feDisplacementMap","feDistantLight","feDropShadow","feFlood","feFuncA","feFuncB","feFuncG","feFuncR","feGaussianBlur","feImage","feMerge","feMergeNode","feMorphology","feOffset","fePointLight","feSpecularLighting","feSpotLight","feTile","feTurbulence"]),Fd=X(["animate","color-profile","cursor","discard","font-face","font-face-format","font-face-name","font-face-src","font-face-uri","foreignobject","hatch","hatchpath","mesh","meshgradient","meshpatch","meshrow","missing-glyph","script","set","solidcolor","unknown","use"]),Yn=X(["math","menclose","merror","mfenced","mfrac","mglyph","mi","mlabeledtr","mmultiscripts","mn","mo","mover","mpadded","mphantom","mroot","mrow","ms","mspace","msqrt","mstyle","msub","msup","msubsup","mtable","mtd","mtext","mtr","munder","munderover","mprescripts"]),Ud=X(["maction","maligngroup","malignmark","mlongdiv","mscarries","mscarry","msgroup","mstack","msline","msrow","semantics","annotation","annotation-xml","mprescripts","none"]),ur=X(["#text"]),pr=X(["accept","action","align","alt","autocapitalize","autocomplete","autopictureinpicture","autoplay","background","bgcolor","border","capture","cellpadding","cellspacing","checked","cite","class","clear","color","cols","colspan","controls","controlslist","coords","crossorigin","datetime","decoding","default","dir","disabled","disablepictureinpicture","disableremoteplayback","download","draggable","enctype","enterkeyhint","exportparts","face","for","headers","height","hidden","high","href","hreflang","id","inert","inputmode","integrity","ismap","kind","label","lang","list","loading","loop","low","max","maxlength","media","method","min","minlength","multiple","muted","name","nonce","noshade","novalidate","nowrap","open","optimum","part","pattern","placeholder","playsinline","popover","popovertarget","popovertargetaction","poster","preload","pubdate","radiogroup","readonly","rel","required","rev","reversed","role","rows","rowspan","spellcheck","scope","selected","shape","size","sizes","slot","span","srclang","start","src","srcset","step","style","summary","tabindex","title","translate","type","usemap","valign","value","width","wrap","xmlns","slot"]),Xn=X(["accent-height","accumulate","additive","alignment-baseline","amplitude","ascent","attributename","attributetype","azimuth","basefrequency","baseline-shift","begin","bias","by","class","clip","clippathunits","clip-path","clip-rule","color","color-interpolation","color-interpolation-filters","color-profile","color-rendering","cx","cy","d","dx","dy","diffuseconstant","direction","display","divisor","dur","edgemode","elevation","end","exponent","fill","fill-opacity","fill-rule","filter","filterunits","flood-color","flood-opacity","font-family","font-size","font-size-adjust","font-stretch","font-style","font-variant","font-weight","fx","fy","g1","g2","glyph-name","glyphref","gradientunits","gradienttransform","height","href","id","image-rendering","in","in2","intercept","k","k1","k2","k3","k4","kerning","keypoints","keysplines","keytimes","lang","lengthadjust","letter-spacing","kernelmatrix","kernelunitlength","lighting-color","local","marker-end","marker-mid","marker-start","markerheight","markerunits","markerwidth","maskcontentunits","maskunits","max","mask","mask-type","media","method","mode","min","name","numoctaves","offset","operator","opacity","order","orient","orientation","origin","overflow","paint-order","path","pathlength","patterncontentunits","patterntransform","patternunits","points","preservealpha","preserveaspectratio","primitiveunits","r","rx","ry","radius","refx","refy","repeatcount","repeatdur","restart","result","rotate","scale","seed","shape-rendering","slope","specularconstant","specularexponent","spreadmethod","startoffset","stddeviation","stitchtiles","stop-color","stop-opacity","stroke-dasharray","stroke-dashoffset","stroke-linecap","stroke-linejoin","stroke-miterlimit","stroke-opacity","stroke","stroke-width","style","surfacescale","systemlanguage","tabindex","tablevalues","targetx","targety","transform","transform-origin","text-anchor","text-decoration","text-rendering","textlength","type","u1","u2","unicode","values","viewbox","visibility","version","vert-adv-y","vert-origin-x","vert-origin-y","width","word-spacing","wrap","writing-mode","xchannelselector","ychannelselector","x","x1","x2","xmlns","y","y1","y2","z","zoomandpan"]),fr=X(["accent","accentunder","align","bevelled","close","columnsalign","columnlines","columnspan","denomalign","depth","dir","display","displaystyle","encoding","fence","frame","height","href","id","largeop","length","linethickness","lspace","lquote","mathbackground","mathcolor","mathsize","mathvariant","maxsize","minsize","movablelimits","notation","numalign","open","rowalign","rowlines","rowspacing","rowspan","rspace","rquote","scriptlevel","scriptminsize","scriptsizemultiplier","selection","separator","separators","stretchy","subscriptshift","supscriptshift","symmetric","voffset","width","xmlns"]),Vt=X(["xlink:href","xml:id","xlink:title","xml:space","xmlns:xlink"]),Kd=ie(/\{\{[\w\W]*|[\w\W]*\}\}/gm),Hd=ie(/<%[\w\W]*|[\w\W]*%>/gm),zd=ie(/\$\{[\w\W]*/gm),jd=ie(/^data-[\-\w.\u00B7-\uFFFF]+$/),qd=ie(/^aria-[\-\w]+$/),Va=ie(/^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i),Vd=ie(/^(?:\w+script|data):/i),Wd=ie(/[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g),Wa=ie(/^html$/i),Gd=ie(/^[a-z][.\w]*(-[.\w]+)+$/i);var hr=Object.freeze({__proto__:null,ARIA_ATTR:qd,ATTR_WHITESPACE:Wd,CUSTOM_ELEMENT:Gd,DATA_ATTR:jd,DOCTYPE_NAME:Wa,ERB_EXPR:Hd,IS_ALLOWED_URI:Va,IS_SCRIPT_OR_DATA:Vd,MUSTACHE_EXPR:Kd,TMPLIT_EXPR:zd});const vt={element:1,text:3,progressingInstruction:7,comment:8,document:9},Qd=function(){return typeof window>"u"?null:window},Zd=function(t,n){if(typeof t!="object"||typeof t.createPolicy!="function")return null;let s=null;const i="data-tt-policy-suffix";n&&n.hasAttribute(i)&&(s=n.getAttribute(i));const r="dompurify"+(s?"#"+s:"");try{return t.createPolicy(r,{createHTML(a){return a},createScriptURL(a){return a}})}catch{return console.warn("TrustedTypes policy "+r+" could not be created."),null}},gr=function(){return{afterSanitizeAttributes:[],afterSanitizeElements:[],afterSanitizeShadowDOM:[],beforeSanitizeAttributes:[],beforeSanitizeElements:[],beforeSanitizeShadowDOM:[],uponSanitizeAttribute:[],uponSanitizeElement:[],uponSanitizeShadowNode:[]}};function Ga(){let e=arguments.length>0&&arguments[0]!==void 0?arguments[0]:Qd();const t=T=>Ga(T);if(t.version="3.3.1",t.removed=[],!e||!e.document||e.document.nodeType!==vt.document||!e.Element)return t.isSupported=!1,t;let{document:n}=e;const s=n,i=s.currentScript,{DocumentFragment:r,HTMLTemplateElement:a,Node:o,Element:c,NodeFilter:p,NamedNodeMap:d=e.NamedNodeMap||e.MozNamedAttrMap,HTMLFormElement:u,DOMParser:v,trustedTypes:g}=e,y=c.prototype,w=gt(y,"cloneNode"),A=gt(y,"remove"),E=gt(y,"nextSibling"),C=gt(y,"childNodes"),O=gt(y,"parentNode");if(typeof a=="function"){const T=n.createElement("template");T.content&&T.content.ownerDocument&&(n=T.content.ownerDocument)}let I,L="";const{implementation:k,createNodeIterator:N,createDocumentFragment:te,getElementsByTagName:ze}=n,{importNode:Pt}=s;let Q=gr();t.isSupported=typeof qa=="function"&&typeof O=="function"&&k&&k.createHTMLDocument!==void 0;const{MUSTACHE_EXPR:xn,ERB_EXPR:An,TMPLIT_EXPR:kn,DATA_ATTR:ko,ARIA_ATTR:So,IS_SCRIPT_OR_DATA:_o,ATTR_WHITESPACE:ui,CUSTOM_ELEMENT:To}=hr;let{IS_ALLOWED_URI:pi}=hr,H=null;const fi=M({},[...dr,...Qn,...Zn,...Yn,...ur]);let j=null;const hi=M({},[...pr,...Xn,...fr,...Vt]);let F=Object.seal(ms(null,{tagNameCheck:{writable:!0,configurable:!1,enumerable:!0,value:null},attributeNameCheck:{writable:!0,configurable:!1,enumerable:!0,value:null},allowCustomizedBuiltInElements:{writable:!0,configurable:!1,enumerable:!0,value:!1}})),ot=null,Sn=null;const je=Object.seal(ms(null,{tagCheck:{writable:!0,configurable:!1,enumerable:!0,value:null},attributeCheck:{writable:!0,configurable:!1,enumerable:!0,value:null}}));let gi=!0,_n=!0,vi=!1,mi=!0,qe=!1,Nt=!0,Ce=!1,Tn=!1,En=!1,Ve=!1,Ot=!1,Dt=!1,yi=!0,bi=!1;const Eo="user-content-";let Cn=!0,lt=!1,We={},ce=null;const Mn=M({},["annotation-xml","audio","colgroup","desc","foreignobject","head","iframe","math","mi","mn","mo","ms","mtext","noembed","noframes","noscript","plaintext","script","style","svg","template","thead","title","video","xmp"]);let $i=null;const wi=M({},["audio","video","img","source","image","track"]);let In=null;const xi=M({},["alt","class","for","id","label","name","pattern","placeholder","role","summary","title","value","style","xmlns"]),Bt="http://www.w3.org/1998/Math/MathML",Ft="http://www.w3.org/2000/svg",he="http://www.w3.org/1999/xhtml";let Ge=he,Ln=!1,Rn=null;const Co=M({},[Bt,Ft,he],Wn);let Ut=M({},["mi","mo","mn","ms","mtext"]),Kt=M({},["annotation-xml"]);const Mo=M({},["title","style","font","a","script"]);let ct=null;const Io=["application/xhtml+xml","text/html"],Lo="text/html";let K=null,Qe=null;const Ro=n.createElement("form"),Ai=function(f){return f instanceof RegExp||f instanceof Function},Pn=function(){let f=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{};if(!(Qe&&Qe===f)){if((!f||typeof f!="object")&&(f={}),f=pe(f),ct=Io.indexOf(f.PARSER_MEDIA_TYPE)===-1?Lo:f.PARSER_MEDIA_TYPE,K=ct==="application/xhtml+xml"?Wn:Yt,H=re(f,"ALLOWED_TAGS")?M({},f.ALLOWED_TAGS,K):fi,j=re(f,"ALLOWED_ATTR")?M({},f.ALLOWED_ATTR,K):hi,Rn=re(f,"ALLOWED_NAMESPACES")?M({},f.ALLOWED_NAMESPACES,Wn):Co,In=re(f,"ADD_URI_SAFE_ATTR")?M(pe(xi),f.ADD_URI_SAFE_ATTR,K):xi,$i=re(f,"ADD_DATA_URI_TAGS")?M(pe(wi),f.ADD_DATA_URI_TAGS,K):wi,ce=re(f,"FORBID_CONTENTS")?M({},f.FORBID_CONTENTS,K):Mn,ot=re(f,"FORBID_TAGS")?M({},f.FORBID_TAGS,K):pe({}),Sn=re(f,"FORBID_ATTR")?M({},f.FORBID_ATTR,K):pe({}),We=re(f,"USE_PROFILES")?f.USE_PROFILES:!1,gi=f.ALLOW_ARIA_ATTR!==!1,_n=f.ALLOW_DATA_ATTR!==!1,vi=f.ALLOW_UNKNOWN_PROTOCOLS||!1,mi=f.ALLOW_SELF_CLOSE_IN_ATTR!==!1,qe=f.SAFE_FOR_TEMPLATES||!1,Nt=f.SAFE_FOR_XML!==!1,Ce=f.WHOLE_DOCUMENT||!1,Ve=f.RETURN_DOM||!1,Ot=f.RETURN_DOM_FRAGMENT||!1,Dt=f.RETURN_TRUSTED_TYPE||!1,En=f.FORCE_BODY||!1,yi=f.SANITIZE_DOM!==!1,bi=f.SANITIZE_NAMED_PROPS||!1,Cn=f.KEEP_CONTENT!==!1,lt=f.IN_PLACE||!1,pi=f.ALLOWED_URI_REGEXP||Va,Ge=f.NAMESPACE||he,Ut=f.MATHML_TEXT_INTEGRATION_POINTS||Ut,Kt=f.HTML_INTEGRATION_POINTS||Kt,F=f.CUSTOM_ELEMENT_HANDLING||{},f.CUSTOM_ELEMENT_HANDLING&&Ai(f.CUSTOM_ELEMENT_HANDLING.tagNameCheck)&&(F.tagNameCheck=f.CUSTOM_ELEMENT_HANDLING.tagNameCheck),f.CUSTOM_ELEMENT_HANDLING&&Ai(f.CUSTOM_ELEMENT_HANDLING.attributeNameCheck)&&(F.attributeNameCheck=f.CUSTOM_ELEMENT_HANDLING.attributeNameCheck),f.CUSTOM_ELEMENT_HANDLING&&typeof f.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements=="boolean"&&(F.allowCustomizedBuiltInElements=f.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements),qe&&(_n=!1),Ot&&(Ve=!0),We&&(H=M({},ur),j=[],We.html===!0&&(M(H,dr),M(j,pr)),We.svg===!0&&(M(H,Qn),M(j,Xn),M(j,Vt)),We.svgFilters===!0&&(M(H,Zn),M(j,Xn),M(j,Vt)),We.mathMl===!0&&(M(H,Yn),M(j,fr),M(j,Vt))),f.ADD_TAGS&&(typeof f.ADD_TAGS=="function"?je.tagCheck=f.ADD_TAGS:(H===fi&&(H=pe(H)),M(H,f.ADD_TAGS,K))),f.ADD_ATTR&&(typeof f.ADD_ATTR=="function"?je.attributeCheck=f.ADD_ATTR:(j===hi&&(j=pe(j)),M(j,f.ADD_ATTR,K))),f.ADD_URI_SAFE_ATTR&&M(In,f.ADD_URI_SAFE_ATTR,K),f.FORBID_CONTENTS&&(ce===Mn&&(ce=pe(ce)),M(ce,f.FORBID_CONTENTS,K)),f.ADD_FORBID_CONTENTS&&(ce===Mn&&(ce=pe(ce)),M(ce,f.ADD_FORBID_CONTENTS,K)),Cn&&(H["#text"]=!0),Ce&&M(H,["html","head","body"]),H.table&&(M(H,["tbody"]),delete ot.tbody),f.TRUSTED_TYPES_POLICY){if(typeof f.TRUSTED_TYPES_POLICY.createHTML!="function")throw ht('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');if(typeof f.TRUSTED_TYPES_POLICY.createScriptURL!="function")throw ht('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');I=f.TRUSTED_TYPES_POLICY,L=I.createHTML("")}else I===void 0&&(I=Zd(g,i)),I!==null&&typeof L=="string"&&(L=I.createHTML(""));X&&X(f),Qe=f}},ki=M({},[...Qn,...Zn,...Fd]),Si=M({},[...Yn,...Ud]),Po=function(f){let x=O(f);(!x||!x.tagName)&&(x={namespaceURI:Ge,tagName:"template"});const _=Yt(f.tagName),B=Yt(x.tagName);return Rn[f.namespaceURI]?f.namespaceURI===Ft?x.namespaceURI===he?_==="svg":x.namespaceURI===Bt?_==="svg"&&(B==="annotation-xml"||Ut[B]):!!ki[_]:f.namespaceURI===Bt?x.namespaceURI===he?_==="math":x.namespaceURI===Ft?_==="math"&&Kt[B]:!!Si[_]:f.namespaceURI===he?x.namespaceURI===Ft&&!Kt[B]||x.namespaceURI===Bt&&!Ut[B]?!1:!Si[_]&&(Mo[_]||!ki[_]):!!(ct==="application/xhtml+xml"&&Rn[f.namespaceURI]):!1},de=function(f){pt(t.removed,{element:f});try{O(f).removeChild(f)}catch{A(f)}},Me=function(f,x){try{pt(t.removed,{attribute:x.getAttributeNode(f),from:x})}catch{pt(t.removed,{attribute:null,from:x})}if(x.removeAttribute(f),f==="is")if(Ve||Ot)try{de(x)}catch{}else try{x.setAttribute(f,"")}catch{}},_i=function(f){let x=null,_=null;if(En)f="<remove></remove>"+f;else{const U=Gn(f,/^[\r\n\t ]+/);_=U&&U[0]}ct==="application/xhtml+xml"&&Ge===he&&(f='<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>'+f+"</body></html>");const B=I?I.createHTML(f):f;if(Ge===he)try{x=new v().parseFromString(B,ct)}catch{}if(!x||!x.documentElement){x=k.createDocument(Ge,"template",null);try{x.documentElement.innerHTML=Ln?L:B}catch{}}const V=x.body||x.documentElement;return f&&_&&V.insertBefore(n.createTextNode(_),V.childNodes[0]||null),Ge===he?ze.call(x,Ce?"html":"body")[0]:Ce?x.documentElement:V},Ti=function(f){return N.call(f.ownerDocument||f,f,p.SHOW_ELEMENT|p.SHOW_COMMENT|p.SHOW_TEXT|p.SHOW_PROCESSING_INSTRUCTION|p.SHOW_CDATA_SECTION,null)},Nn=function(f){return f instanceof u&&(typeof f.nodeName!="string"||typeof f.textContent!="string"||typeof f.removeChild!="function"||!(f.attributes instanceof d)||typeof f.removeAttribute!="function"||typeof f.setAttribute!="function"||typeof f.namespaceURI!="string"||typeof f.insertBefore!="function"||typeof f.hasChildNodes!="function")},Ei=function(f){return typeof o=="function"&&f instanceof o};function ge(T,f,x){qt(T,_=>{_.call(t,f,x,Qe)})}const Ci=function(f){let x=null;if(ge(Q.beforeSanitizeElements,f,null),Nn(f))return de(f),!0;const _=K(f.nodeName);if(ge(Q.uponSanitizeElement,f,{tagName:_,allowedTags:H}),Nt&&f.hasChildNodes()&&!Ei(f.firstElementChild)&&Z(/<[/\w!]/g,f.innerHTML)&&Z(/<[/\w!]/g,f.textContent)||f.nodeType===vt.progressingInstruction||Nt&&f.nodeType===vt.comment&&Z(/<[/\w]/g,f.data))return de(f),!0;if(!(je.tagCheck instanceof Function&&je.tagCheck(_))&&(!H[_]||ot[_])){if(!ot[_]&&Ii(_)&&(F.tagNameCheck instanceof RegExp&&Z(F.tagNameCheck,_)||F.tagNameCheck instanceof Function&&F.tagNameCheck(_)))return!1;if(Cn&&!ce[_]){const B=O(f)||f.parentNode,V=C(f)||f.childNodes;if(V&&B){const U=V.length;for(let ee=U-1;ee>=0;--ee){const ve=w(V[ee],!0);ve.__removalCount=(f.__removalCount||0)+1,B.insertBefore(ve,E(f))}}}return de(f),!0}return f instanceof c&&!Po(f)||(_==="noscript"||_==="noembed"||_==="noframes")&&Z(/<\/no(script|embed|frames)/i,f.innerHTML)?(de(f),!0):(qe&&f.nodeType===vt.text&&(x=f.textContent,qt([xn,An,kn],B=>{x=ft(x,B," ")}),f.textContent!==x&&(pt(t.removed,{element:f.cloneNode()}),f.textContent=x)),ge(Q.afterSanitizeElements,f,null),!1)},Mi=function(f,x,_){if(yi&&(x==="id"||x==="name")&&(_ in n||_ in Ro))return!1;if(!(_n&&!Sn[x]&&Z(ko,x))){if(!(gi&&Z(So,x))){if(!(je.attributeCheck instanceof Function&&je.attributeCheck(x,f))){if(!j[x]||Sn[x]){if(!(Ii(f)&&(F.tagNameCheck instanceof RegExp&&Z(F.tagNameCheck,f)||F.tagNameCheck instanceof Function&&F.tagNameCheck(f))&&(F.attributeNameCheck instanceof RegExp&&Z(F.attributeNameCheck,x)||F.attributeNameCheck instanceof Function&&F.attributeNameCheck(x,f))||x==="is"&&F.allowCustomizedBuiltInElements&&(F.tagNameCheck instanceof RegExp&&Z(F.tagNameCheck,_)||F.tagNameCheck instanceof Function&&F.tagNameCheck(_))))return!1}else if(!In[x]){if(!Z(pi,ft(_,ui,""))){if(!((x==="src"||x==="xlink:href"||x==="href")&&f!=="script"&&Nd(_,"data:")===0&&$i[f])){if(!(vi&&!Z(_o,ft(_,ui,"")))){if(_)return!1}}}}}}}return!0},Ii=function(f){return f!=="annotation-xml"&&Gn(f,To)},Li=function(f){ge(Q.beforeSanitizeAttributes,f,null);const{attributes:x}=f;if(!x||Nn(f))return;const _={attrName:"",attrValue:"",keepAttr:!0,allowedAttributes:j,forceKeepAttr:void 0};let B=x.length;for(;B--;){const V=x[B],{name:U,namespaceURI:ee,value:ve}=V,Ze=K(U),On=ve;let q=U==="value"?On:Od(On);if(_.attrName=Ze,_.attrValue=q,_.keepAttr=!0,_.forceKeepAttr=void 0,ge(Q.uponSanitizeAttribute,f,_),q=_.attrValue,bi&&(Ze==="id"||Ze==="name")&&(Me(U,f),q=Eo+q),Nt&&Z(/((--!?|])>)|<\/(style|title|textarea)/i,q)){Me(U,f);continue}if(Ze==="attributename"&&Gn(q,"href")){Me(U,f);continue}if(_.forceKeepAttr)continue;if(!_.keepAttr){Me(U,f);continue}if(!mi&&Z(/\/>/i,q)){Me(U,f);continue}qe&&qt([xn,An,kn],Pi=>{q=ft(q,Pi," ")});const Ri=K(f.nodeName);if(!Mi(Ri,Ze,q)){Me(U,f);continue}if(I&&typeof g=="object"&&typeof g.getAttributeType=="function"&&!ee)switch(g.getAttributeType(Ri,Ze)){case"TrustedHTML":{q=I.createHTML(q);break}case"TrustedScriptURL":{q=I.createScriptURL(q);break}}if(q!==On)try{ee?f.setAttributeNS(ee,U,q):f.setAttribute(U,q),Nn(f)?de(f):cr(t.removed)}catch{Me(U,f)}}ge(Q.afterSanitizeAttributes,f,null)},No=function T(f){let x=null;const _=Ti(f);for(ge(Q.beforeSanitizeShadowDOM,f,null);x=_.nextNode();)ge(Q.uponSanitizeShadowNode,x,null),Ci(x),Li(x),x.content instanceof r&&T(x.content);ge(Q.afterSanitizeShadowDOM,f,null)};return t.sanitize=function(T){let f=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},x=null,_=null,B=null,V=null;if(Ln=!T,Ln&&(T="<!-->"),typeof T!="string"&&!Ei(T))if(typeof T.toString=="function"){if(T=T.toString(),typeof T!="string")throw ht("dirty is not a string, aborting")}else throw ht("toString is not a function");if(!t.isSupported)return T;if(Tn||Pn(f),t.removed=[],typeof T=="string"&&(lt=!1),lt){if(T.nodeName){const ve=K(T.nodeName);if(!H[ve]||ot[ve])throw ht("root node is forbidden and cannot be sanitized in-place")}}else if(T instanceof o)x=_i("<!---->"),_=x.ownerDocument.importNode(T,!0),_.nodeType===vt.element&&_.nodeName==="BODY"||_.nodeName==="HTML"?x=_:x.appendChild(_);else{if(!Ve&&!qe&&!Ce&&T.indexOf("<")===-1)return I&&Dt?I.createHTML(T):T;if(x=_i(T),!x)return Ve?null:Dt?L:""}x&&En&&de(x.firstChild);const U=Ti(lt?T:x);for(;B=U.nextNode();)Ci(B),Li(B),B.content instanceof r&&No(B.content);if(lt)return T;if(Ve){if(Ot)for(V=te.call(x.ownerDocument);x.firstChild;)V.appendChild(x.firstChild);else V=x;return(j.shadowroot||j.shadowrootmode)&&(V=Pt.call(s,V,!0)),V}let ee=Ce?x.outerHTML:x.innerHTML;return Ce&&H["!doctype"]&&x.ownerDocument&&x.ownerDocument.doctype&&x.ownerDocument.doctype.name&&Z(Wa,x.ownerDocument.doctype.name)&&(ee="<!DOCTYPE "+x.ownerDocument.doctype.name+`>
`+ee),qe&&qt([xn,An,kn],ve=>{ee=ft(ee,ve," ")}),I&&Dt?I.createHTML(ee):ee},t.setConfig=function(){let T=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{};Pn(T),Tn=!0},t.clearConfig=function(){Qe=null,Tn=!1},t.isValidAttribute=function(T,f,x){Qe||Pn({});const _=K(T),B=K(f);return Mi(_,B,x)},t.addHook=function(T,f){typeof f=="function"&&pt(Q[T],f)},t.removeHook=function(T,f){if(f!==void 0){const x=Rd(Q[T],f);return x===-1?void 0:Pd(Q[T],x,1)[0]}return cr(Q[T])},t.removeHooks=function(T){Q[T]=[]},t.removeAllHooks=function(){Q=gr()},t}var $s=Ga();function ei(){return{async:!1,breaks:!1,extensions:null,gfm:!0,hooks:null,pedantic:!1,renderer:null,silent:!1,tokenizer:null,walkTokens:null}}var He=ei();function Qa(e){He=e}var At={exec:()=>null};function R(e,t=""){let n=typeof e=="string"?e:e.source,s={replace:(i,r)=>{let a=typeof r=="string"?r:r.source;return a=a.replace(Y.caret,"$1"),n=n.replace(i,a),s},getRegex:()=>new RegExp(n,t)};return s}var Yd=(()=>{try{return!!new RegExp("(?<=1)(?<!1)")}catch{return!1}})(),Y={codeRemoveIndent:/^(?: {1,4}| {0,3}\t)/gm,outputLinkReplace:/\\([\[\]])/g,indentCodeCompensation:/^(\s+)(?:```)/,beginningSpace:/^\s+/,endingHash:/#$/,startingSpaceChar:/^ /,endingSpaceChar:/ $/,nonSpaceChar:/[^ ]/,newLineCharGlobal:/\n/g,tabCharGlobal:/\t/g,multipleSpaceGlobal:/\s+/g,blankLine:/^[ \t]*$/,doubleBlankLine:/\n[ \t]*\n[ \t]*$/,blockquoteStart:/^ {0,3}>/,blockquoteSetextReplace:/\n {0,3}((?:=+|-+) *)(?=\n|$)/g,blockquoteSetextReplace2:/^ {0,3}>[ \t]?/gm,listReplaceTabs:/^\t+/,listReplaceNesting:/^ {1,4}(?=( {4})*[^ ])/g,listIsTask:/^\[[ xX]\] +\S/,listReplaceTask:/^\[[ xX]\] +/,listTaskCheckbox:/\[[ xX]\]/,anyLine:/\n.*\n/,hrefBrackets:/^<(.*)>$/,tableDelimiter:/[:|]/,tableAlignChars:/^\||\| *$/g,tableRowBlankLine:/\n[ \t]*$/,tableAlignRight:/^ *-+: *$/,tableAlignCenter:/^ *:-+: *$/,tableAlignLeft:/^ *:-+ *$/,startATag:/^<a /i,endATag:/^<\/a>/i,startPreScriptTag:/^<(pre|code|kbd|script)(\s|>)/i,endPreScriptTag:/^<\/(pre|code|kbd|script)(\s|>)/i,startAngleBracket:/^</,endAngleBracket:/>$/,pedanticHrefTitle:/^([^'"]*[^\s])\s+(['"])(.*)\2/,unicodeAlphaNumeric:/[\p{L}\p{N}]/u,escapeTest:/[&<>"']/,escapeReplace:/[&<>"']/g,escapeTestNoEncode:/[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/,escapeReplaceNoEncode:/[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/g,unescapeTest:/&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig,caret:/(^|[^\[])\^/g,percentDecode:/%25/g,findPipe:/\|/g,splitPipe:/ \|/,slashPipe:/\\\|/g,carriageReturn:/\r\n|\r/g,spaceLine:/^ +$/gm,notSpaceStart:/^\S*/,endingNewline:/\n$/,listItemRegex:e=>new RegExp(`^( {0,3}${e})((?:[	 ][^\\n]*)?(?:\\n|$))`),nextBulletRegex:e=>new RegExp(`^ {0,${Math.min(3,e-1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`),hrRegex:e=>new RegExp(`^ {0,${Math.min(3,e-1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`),fencesBeginRegex:e=>new RegExp(`^ {0,${Math.min(3,e-1)}}(?:\`\`\`|~~~)`),headingBeginRegex:e=>new RegExp(`^ {0,${Math.min(3,e-1)}}#`),htmlBeginRegex:e=>new RegExp(`^ {0,${Math.min(3,e-1)}}<(?:[a-z].*>|!--)`,"i")},Xd=/^(?:[ \t]*(?:\n|$))+/,Jd=/^((?: {4}| {0,3}\t)[^\n]+(?:\n(?:[ \t]*(?:\n|$))*)?)+/,eu=/^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/,Lt=/^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/,tu=/^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/,ti=/(?:[*+-]|\d{1,9}[.)])/,Za=/^(?!bull |blockCode|fences|blockquote|heading|html|table)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html|table))+?)\n {0,3}(=+|-+) *(?:\n+|$)/,Ya=R(Za).replace(/bull/g,ti).replace(/blockCode/g,/(?: {4}| {0,3}\t)/).replace(/fences/g,/ {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g,/ {0,3}>/).replace(/heading/g,/ {0,3}#{1,6}/).replace(/html/g,/ {0,3}<[^\n>]+>\n/).replace(/\|table/g,"").getRegex(),nu=R(Za).replace(/bull/g,ti).replace(/blockCode/g,/(?: {4}| {0,3}\t)/).replace(/fences/g,/ {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g,/ {0,3}>/).replace(/heading/g,/ {0,3}#{1,6}/).replace(/html/g,/ {0,3}<[^\n>]+>\n/).replace(/table/g,/ {0,3}\|?(?:[:\- ]*\|)+[\:\- ]*\n/).getRegex(),ni=/^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/,su=/^[^\n]+/,si=/(?!\s*\])(?:\\[\s\S]|[^\[\]\\])+/,iu=R(/^ {0,3}\[(label)\]: *(?:\n[ \t]*)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n[ \t]*)?| *\n[ \t]*)(title))? *(?:\n+|$)/).replace("label",si).replace("title",/(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(),ru=R(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g,ti).getRegex(),bn="address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul",ii=/<!--(?:-?>|[\s\S]*?(?:-->|$))/,au=R("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$))","i").replace("comment",ii).replace("tag",bn).replace("attribute",/ +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(),Xa=R(ni).replace("hr",Lt).replace("heading"," {0,3}#{1,6}(?:\\s|$)").replace("|lheading","").replace("|table","").replace("blockquote"," {0,3}>").replace("fences"," {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list"," {0,3}(?:[*+-]|1[.)]) ").replace("html","</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag",bn).getRegex(),ou=R(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph",Xa).getRegex(),ri={blockquote:ou,code:Jd,def:iu,fences:eu,heading:tu,hr:Lt,html:au,lheading:Ya,list:ru,newline:Xd,paragraph:Xa,table:At,text:su},vr=R("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr",Lt).replace("heading"," {0,3}#{1,6}(?:\\s|$)").replace("blockquote"," {0,3}>").replace("code","(?: {4}| {0,3}	)[^\\n]").replace("fences"," {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list"," {0,3}(?:[*+-]|1[.)]) ").replace("html","</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag",bn).getRegex(),lu={...ri,lheading:nu,table:vr,paragraph:R(ni).replace("hr",Lt).replace("heading"," {0,3}#{1,6}(?:\\s|$)").replace("|lheading","").replace("table",vr).replace("blockquote"," {0,3}>").replace("fences"," {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list"," {0,3}(?:[*+-]|1[.)]) ").replace("html","</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag",bn).getRegex()},cu={...ri,html:R(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment",ii).replace(/tag/g,"(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),def:/^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,heading:/^(#{1,6})(.*)(?:\n+|$)/,fences:At,lheading:/^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,paragraph:R(ni).replace("hr",Lt).replace("heading",` *#{1,6} *[^
]`).replace("lheading",Ya).replace("|table","").replace("blockquote"," {0,3}>").replace("|fences","").replace("|list","").replace("|html","").replace("|tag","").getRegex()},du=/^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/,uu=/^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/,Ja=/^( {2,}|\\)\n(?!\s*$)/,pu=/^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/,$n=/[\p{P}\p{S}]/u,ai=/[\s\p{P}\p{S}]/u,eo=/[^\s\p{P}\p{S}]/u,fu=R(/^((?![*_])punctSpace)/,"u").replace(/punctSpace/g,ai).getRegex(),to=/(?!~)[\p{P}\p{S}]/u,hu=/(?!~)[\s\p{P}\p{S}]/u,gu=/(?:[^\s\p{P}\p{S}]|~)/u,vu=R(/link|precode-code|html/,"g").replace("link",/\[(?:[^\[\]`]|(?<a>`+)[^`]+\k<a>(?!`))*?\]\((?:\\[\s\S]|[^\\\(\)]|\((?:\\[\s\S]|[^\\\(\)])*\))*\)/).replace("precode-",Yd?"(?<!`)()":"(^^|[^`])").replace("code",/(?<b>`+)[^`]+\k<b>(?!`)/).replace("html",/<(?! )[^<>]*?>/).getRegex(),no=/^(?:\*+(?:((?!\*)punct)|[^\s*]))|^_+(?:((?!_)punct)|([^\s_]))/,mu=R(no,"u").replace(/punct/g,$n).getRegex(),yu=R(no,"u").replace(/punct/g,to).getRegex(),so="^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)punctSpace(\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|notPunctSpace(\\*+)(?=notPunctSpace)",bu=R(so,"gu").replace(/notPunctSpace/g,eo).replace(/punctSpace/g,ai).replace(/punct/g,$n).getRegex(),$u=R(so,"gu").replace(/notPunctSpace/g,gu).replace(/punctSpace/g,hu).replace(/punct/g,to).getRegex(),wu=R("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)punctSpace(_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)","gu").replace(/notPunctSpace/g,eo).replace(/punctSpace/g,ai).replace(/punct/g,$n).getRegex(),xu=R(/\\(punct)/,"gu").replace(/punct/g,$n).getRegex(),Au=R(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme",/[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email",/[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(),ku=R(ii).replace("(?:-->|$)","-->").getRegex(),Su=R("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment",ku).replace("attribute",/\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(),sn=/(?:\[(?:\\[\s\S]|[^\[\]\\])*\]|\\[\s\S]|`+[^`]*?`+(?!`)|[^\[\]\\`])*?/,_u=R(/^!?\[(label)\]\(\s*(href)(?:(?:[ \t]*(?:\n[ \t]*)?)(title))?\s*\)/).replace("label",sn).replace("href",/<(?:\\.|[^\n<>\\])+>|[^ \t\n\x00-\x1f]*/).replace("title",/"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(),io=R(/^!?\[(label)\]\[(ref)\]/).replace("label",sn).replace("ref",si).getRegex(),ro=R(/^!?\[(ref)\](?:\[\])?/).replace("ref",si).getRegex(),Tu=R("reflink|nolink(?!\\()","g").replace("reflink",io).replace("nolink",ro).getRegex(),mr=/[hH][tT][tT][pP][sS]?|[fF][tT][pP]/,oi={_backpedal:At,anyPunctuation:xu,autolink:Au,blockSkip:vu,br:Ja,code:uu,del:At,emStrongLDelim:mu,emStrongRDelimAst:bu,emStrongRDelimUnd:wu,escape:du,link:_u,nolink:ro,punctuation:fu,reflink:io,reflinkSearch:Tu,tag:Su,text:pu,url:At},Eu={...oi,link:R(/^!?\[(label)\]\((.*?)\)/).replace("label",sn).getRegex(),reflink:R(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label",sn).getRegex()},ws={...oi,emStrongRDelimAst:$u,emStrongLDelim:yu,url:R(/^((?:protocol):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/).replace("protocol",mr).replace("email",/[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),_backpedal:/(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,del:/^(~~?)(?=[^\s~])((?:\\[\s\S]|[^\\])*?(?:\\[\s\S]|[^\s~\\]))\1(?=[^~]|$)/,text:R(/^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|protocol:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/).replace("protocol",mr).getRegex()},Cu={...ws,br:R(Ja).replace("{2,}","*").getRegex(),text:R(ws.text).replace("\\b_","\\b_| {2,}\\n").replace(/\{2,\}/g,"*").getRegex()},Wt={normal:ri,gfm:lu,pedantic:cu},mt={normal:oi,gfm:ws,breaks:Cu,pedantic:Eu},Mu={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"},yr=e=>Mu[e];function ye(e,t){if(t){if(Y.escapeTest.test(e))return e.replace(Y.escapeReplace,yr)}else if(Y.escapeTestNoEncode.test(e))return e.replace(Y.escapeReplaceNoEncode,yr);return e}function br(e){try{e=encodeURI(e).replace(Y.percentDecode,"%")}catch{return null}return e}function $r(e,t){let n=e.replace(Y.findPipe,(r,a,o)=>{let c=!1,p=a;for(;--p>=0&&o[p]==="\\";)c=!c;return c?"|":" |"}),s=n.split(Y.splitPipe),i=0;if(s[0].trim()||s.shift(),s.length>0&&!s.at(-1)?.trim()&&s.pop(),t)if(s.length>t)s.splice(t);else for(;s.length<t;)s.push("");for(;i<s.length;i++)s[i]=s[i].trim().replace(Y.slashPipe,"|");return s}function yt(e,t,n){let s=e.length;if(s===0)return"";let i=0;for(;i<s&&e.charAt(s-i-1)===t;)i++;return e.slice(0,s-i)}function Iu(e,t){if(e.indexOf(t[1])===-1)return-1;let n=0;for(let s=0;s<e.length;s++)if(e[s]==="\\")s++;else if(e[s]===t[0])n++;else if(e[s]===t[1]&&(n--,n<0))return s;return n>0?-2:-1}function wr(e,t,n,s,i){let r=t.href,a=t.title||null,o=e[1].replace(i.other.outputLinkReplace,"$1");s.state.inLink=!0;let c={type:e[0].charAt(0)==="!"?"image":"link",raw:n,href:r,title:a,text:o,tokens:s.inlineTokens(o)};return s.state.inLink=!1,c}function Lu(e,t,n){let s=e.match(n.other.indentCodeCompensation);if(s===null)return t;let i=s[1];return t.split(`
`).map(r=>{let a=r.match(n.other.beginningSpace);if(a===null)return r;let[o]=a;return o.length>=i.length?r.slice(i.length):r}).join(`
`)}var rn=class{options;rules;lexer;constructor(e){this.options=e||He}space(e){let t=this.rules.block.newline.exec(e);if(t&&t[0].length>0)return{type:"space",raw:t[0]}}code(e){let t=this.rules.block.code.exec(e);if(t){let n=t[0].replace(this.rules.other.codeRemoveIndent,"");return{type:"code",raw:t[0],codeBlockStyle:"indented",text:this.options.pedantic?n:yt(n,`
`)}}}fences(e){let t=this.rules.block.fences.exec(e);if(t){let n=t[0],s=Lu(n,t[3]||"",this.rules);return{type:"code",raw:n,lang:t[2]?t[2].trim().replace(this.rules.inline.anyPunctuation,"$1"):t[2],text:s}}}heading(e){let t=this.rules.block.heading.exec(e);if(t){let n=t[2].trim();if(this.rules.other.endingHash.test(n)){let s=yt(n,"#");(this.options.pedantic||!s||this.rules.other.endingSpaceChar.test(s))&&(n=s.trim())}return{type:"heading",raw:t[0],depth:t[1].length,text:n,tokens:this.lexer.inline(n)}}}hr(e){let t=this.rules.block.hr.exec(e);if(t)return{type:"hr",raw:yt(t[0],`
`)}}blockquote(e){let t=this.rules.block.blockquote.exec(e);if(t){let n=yt(t[0],`
`).split(`
`),s="",i="",r=[];for(;n.length>0;){let a=!1,o=[],c;for(c=0;c<n.length;c++)if(this.rules.other.blockquoteStart.test(n[c]))o.push(n[c]),a=!0;else if(!a)o.push(n[c]);else break;n=n.slice(c);let p=o.join(`
`),d=p.replace(this.rules.other.blockquoteSetextReplace,`
    $1`).replace(this.rules.other.blockquoteSetextReplace2,"");s=s?`${s}
${p}`:p,i=i?`${i}
${d}`:d;let u=this.lexer.state.top;if(this.lexer.state.top=!0,this.lexer.blockTokens(d,r,!0),this.lexer.state.top=u,n.length===0)break;let v=r.at(-1);if(v?.type==="code")break;if(v?.type==="blockquote"){let g=v,y=g.raw+`
`+n.join(`
`),w=this.blockquote(y);r[r.length-1]=w,s=s.substring(0,s.length-g.raw.length)+w.raw,i=i.substring(0,i.length-g.text.length)+w.text;break}else if(v?.type==="list"){let g=v,y=g.raw+`
`+n.join(`
`),w=this.list(y);r[r.length-1]=w,s=s.substring(0,s.length-v.raw.length)+w.raw,i=i.substring(0,i.length-g.raw.length)+w.raw,n=y.substring(r.at(-1).raw.length).split(`
`);continue}}return{type:"blockquote",raw:s,tokens:r,text:i}}}list(e){let t=this.rules.block.list.exec(e);if(t){let n=t[1].trim(),s=n.length>1,i={type:"list",raw:"",ordered:s,start:s?+n.slice(0,-1):"",loose:!1,items:[]};n=s?`\\d{1,9}\\${n.slice(-1)}`:`\\${n}`,this.options.pedantic&&(n=s?n:"[*+-]");let r=this.rules.other.listItemRegex(n),a=!1;for(;e;){let c=!1,p="",d="";if(!(t=r.exec(e))||this.rules.block.hr.test(e))break;p=t[0],e=e.substring(p.length);let u=t[2].split(`
`,1)[0].replace(this.rules.other.listReplaceTabs,w=>" ".repeat(3*w.length)),v=e.split(`
`,1)[0],g=!u.trim(),y=0;if(this.options.pedantic?(y=2,d=u.trimStart()):g?y=t[1].length+1:(y=t[2].search(this.rules.other.nonSpaceChar),y=y>4?1:y,d=u.slice(y),y+=t[1].length),g&&this.rules.other.blankLine.test(v)&&(p+=v+`
`,e=e.substring(v.length+1),c=!0),!c){let w=this.rules.other.nextBulletRegex(y),A=this.rules.other.hrRegex(y),E=this.rules.other.fencesBeginRegex(y),C=this.rules.other.headingBeginRegex(y),O=this.rules.other.htmlBeginRegex(y);for(;e;){let I=e.split(`
`,1)[0],L;if(v=I,this.options.pedantic?(v=v.replace(this.rules.other.listReplaceNesting,"  "),L=v):L=v.replace(this.rules.other.tabCharGlobal,"    "),E.test(v)||C.test(v)||O.test(v)||w.test(v)||A.test(v))break;if(L.search(this.rules.other.nonSpaceChar)>=y||!v.trim())d+=`
`+L.slice(y);else{if(g||u.replace(this.rules.other.tabCharGlobal,"    ").search(this.rules.other.nonSpaceChar)>=4||E.test(u)||C.test(u)||A.test(u))break;d+=`
`+v}!g&&!v.trim()&&(g=!0),p+=I+`
`,e=e.substring(I.length+1),u=L.slice(y)}}i.loose||(a?i.loose=!0:this.rules.other.doubleBlankLine.test(p)&&(a=!0)),i.items.push({type:"list_item",raw:p,task:!!this.options.gfm&&this.rules.other.listIsTask.test(d),loose:!1,text:d,tokens:[]}),i.raw+=p}let o=i.items.at(-1);if(o)o.raw=o.raw.trimEnd(),o.text=o.text.trimEnd();else return;i.raw=i.raw.trimEnd();for(let c of i.items){if(this.lexer.state.top=!1,c.tokens=this.lexer.blockTokens(c.text,[]),c.task){if(c.text=c.text.replace(this.rules.other.listReplaceTask,""),c.tokens[0]?.type==="text"||c.tokens[0]?.type==="paragraph"){c.tokens[0].raw=c.tokens[0].raw.replace(this.rules.other.listReplaceTask,""),c.tokens[0].text=c.tokens[0].text.replace(this.rules.other.listReplaceTask,"");for(let d=this.lexer.inlineQueue.length-1;d>=0;d--)if(this.rules.other.listIsTask.test(this.lexer.inlineQueue[d].src)){this.lexer.inlineQueue[d].src=this.lexer.inlineQueue[d].src.replace(this.rules.other.listReplaceTask,"");break}}let p=this.rules.other.listTaskCheckbox.exec(c.raw);if(p){let d={type:"checkbox",raw:p[0]+" ",checked:p[0]!=="[ ]"};c.checked=d.checked,i.loose?c.tokens[0]&&["paragraph","text"].includes(c.tokens[0].type)&&"tokens"in c.tokens[0]&&c.tokens[0].tokens?(c.tokens[0].raw=d.raw+c.tokens[0].raw,c.tokens[0].text=d.raw+c.tokens[0].text,c.tokens[0].tokens.unshift(d)):c.tokens.unshift({type:"paragraph",raw:d.raw,text:d.raw,tokens:[d]}):c.tokens.unshift(d)}}if(!i.loose){let p=c.tokens.filter(u=>u.type==="space"),d=p.length>0&&p.some(u=>this.rules.other.anyLine.test(u.raw));i.loose=d}}if(i.loose)for(let c of i.items){c.loose=!0;for(let p of c.tokens)p.type==="text"&&(p.type="paragraph")}return i}}html(e){let t=this.rules.block.html.exec(e);if(t)return{type:"html",block:!0,raw:t[0],pre:t[1]==="pre"||t[1]==="script"||t[1]==="style",text:t[0]}}def(e){let t=this.rules.block.def.exec(e);if(t){let n=t[1].toLowerCase().replace(this.rules.other.multipleSpaceGlobal," "),s=t[2]?t[2].replace(this.rules.other.hrefBrackets,"$1").replace(this.rules.inline.anyPunctuation,"$1"):"",i=t[3]?t[3].substring(1,t[3].length-1).replace(this.rules.inline.anyPunctuation,"$1"):t[3];return{type:"def",tag:n,raw:t[0],href:s,title:i}}}table(e){let t=this.rules.block.table.exec(e);if(!t||!this.rules.other.tableDelimiter.test(t[2]))return;let n=$r(t[1]),s=t[2].replace(this.rules.other.tableAlignChars,"").split("|"),i=t[3]?.trim()?t[3].replace(this.rules.other.tableRowBlankLine,"").split(`
`):[],r={type:"table",raw:t[0],header:[],align:[],rows:[]};if(n.length===s.length){for(let a of s)this.rules.other.tableAlignRight.test(a)?r.align.push("right"):this.rules.other.tableAlignCenter.test(a)?r.align.push("center"):this.rules.other.tableAlignLeft.test(a)?r.align.push("left"):r.align.push(null);for(let a=0;a<n.length;a++)r.header.push({text:n[a],tokens:this.lexer.inline(n[a]),header:!0,align:r.align[a]});for(let a of i)r.rows.push($r(a,r.header.length).map((o,c)=>({text:o,tokens:this.lexer.inline(o),header:!1,align:r.align[c]})));return r}}lheading(e){let t=this.rules.block.lheading.exec(e);if(t)return{type:"heading",raw:t[0],depth:t[2].charAt(0)==="="?1:2,text:t[1],tokens:this.lexer.inline(t[1])}}paragraph(e){let t=this.rules.block.paragraph.exec(e);if(t){let n=t[1].charAt(t[1].length-1)===`
`?t[1].slice(0,-1):t[1];return{type:"paragraph",raw:t[0],text:n,tokens:this.lexer.inline(n)}}}text(e){let t=this.rules.block.text.exec(e);if(t)return{type:"text",raw:t[0],text:t[0],tokens:this.lexer.inline(t[0])}}escape(e){let t=this.rules.inline.escape.exec(e);if(t)return{type:"escape",raw:t[0],text:t[1]}}tag(e){let t=this.rules.inline.tag.exec(e);if(t)return!this.lexer.state.inLink&&this.rules.other.startATag.test(t[0])?this.lexer.state.inLink=!0:this.lexer.state.inLink&&this.rules.other.endATag.test(t[0])&&(this.lexer.state.inLink=!1),!this.lexer.state.inRawBlock&&this.rules.other.startPreScriptTag.test(t[0])?this.lexer.state.inRawBlock=!0:this.lexer.state.inRawBlock&&this.rules.other.endPreScriptTag.test(t[0])&&(this.lexer.state.inRawBlock=!1),{type:"html",raw:t[0],inLink:this.lexer.state.inLink,inRawBlock:this.lexer.state.inRawBlock,block:!1,text:t[0]}}link(e){let t=this.rules.inline.link.exec(e);if(t){let n=t[2].trim();if(!this.options.pedantic&&this.rules.other.startAngleBracket.test(n)){if(!this.rules.other.endAngleBracket.test(n))return;let r=yt(n.slice(0,-1),"\\");if((n.length-r.length)%2===0)return}else{let r=Iu(t[2],"()");if(r===-2)return;if(r>-1){let a=(t[0].indexOf("!")===0?5:4)+t[1].length+r;t[2]=t[2].substring(0,r),t[0]=t[0].substring(0,a).trim(),t[3]=""}}let s=t[2],i="";if(this.options.pedantic){let r=this.rules.other.pedanticHrefTitle.exec(s);r&&(s=r[1],i=r[3])}else i=t[3]?t[3].slice(1,-1):"";return s=s.trim(),this.rules.other.startAngleBracket.test(s)&&(this.options.pedantic&&!this.rules.other.endAngleBracket.test(n)?s=s.slice(1):s=s.slice(1,-1)),wr(t,{href:s&&s.replace(this.rules.inline.anyPunctuation,"$1"),title:i&&i.replace(this.rules.inline.anyPunctuation,"$1")},t[0],this.lexer,this.rules)}}reflink(e,t){let n;if((n=this.rules.inline.reflink.exec(e))||(n=this.rules.inline.nolink.exec(e))){let s=(n[2]||n[1]).replace(this.rules.other.multipleSpaceGlobal," "),i=t[s.toLowerCase()];if(!i){let r=n[0].charAt(0);return{type:"text",raw:r,text:r}}return wr(n,i,n[0],this.lexer,this.rules)}}emStrong(e,t,n=""){let s=this.rules.inline.emStrongLDelim.exec(e);if(!(!s||s[3]&&n.match(this.rules.other.unicodeAlphaNumeric))&&(!(s[1]||s[2])||!n||this.rules.inline.punctuation.exec(n))){let i=[...s[0]].length-1,r,a,o=i,c=0,p=s[0][0]==="*"?this.rules.inline.emStrongRDelimAst:this.rules.inline.emStrongRDelimUnd;for(p.lastIndex=0,t=t.slice(-1*e.length+i);(s=p.exec(t))!=null;){if(r=s[1]||s[2]||s[3]||s[4]||s[5]||s[6],!r)continue;if(a=[...r].length,s[3]||s[4]){o+=a;continue}else if((s[5]||s[6])&&i%3&&!((i+a)%3)){c+=a;continue}if(o-=a,o>0)continue;a=Math.min(a,a+o+c);let d=[...s[0]][0].length,u=e.slice(0,i+s.index+d+a);if(Math.min(i,a)%2){let g=u.slice(1,-1);return{type:"em",raw:u,text:g,tokens:this.lexer.inlineTokens(g)}}let v=u.slice(2,-2);return{type:"strong",raw:u,text:v,tokens:this.lexer.inlineTokens(v)}}}}codespan(e){let t=this.rules.inline.code.exec(e);if(t){let n=t[2].replace(this.rules.other.newLineCharGlobal," "),s=this.rules.other.nonSpaceChar.test(n),i=this.rules.other.startingSpaceChar.test(n)&&this.rules.other.endingSpaceChar.test(n);return s&&i&&(n=n.substring(1,n.length-1)),{type:"codespan",raw:t[0],text:n}}}br(e){let t=this.rules.inline.br.exec(e);if(t)return{type:"br",raw:t[0]}}del(e){let t=this.rules.inline.del.exec(e);if(t)return{type:"del",raw:t[0],text:t[2],tokens:this.lexer.inlineTokens(t[2])}}autolink(e){let t=this.rules.inline.autolink.exec(e);if(t){let n,s;return t[2]==="@"?(n=t[1],s="mailto:"+n):(n=t[1],s=n),{type:"link",raw:t[0],text:n,href:s,tokens:[{type:"text",raw:n,text:n}]}}}url(e){let t;if(t=this.rules.inline.url.exec(e)){let n,s;if(t[2]==="@")n=t[0],s="mailto:"+n;else{let i;do i=t[0],t[0]=this.rules.inline._backpedal.exec(t[0])?.[0]??"";while(i!==t[0]);n=t[0],t[1]==="www."?s="http://"+t[0]:s=t[0]}return{type:"link",raw:t[0],text:n,href:s,tokens:[{type:"text",raw:n,text:n}]}}}inlineText(e){let t=this.rules.inline.text.exec(e);if(t){let n=this.lexer.state.inRawBlock;return{type:"text",raw:t[0],text:t[0],escaped:n}}}},ae=class xs{tokens;options;state;inlineQueue;tokenizer;constructor(t){this.tokens=[],this.tokens.links=Object.create(null),this.options=t||He,this.options.tokenizer=this.options.tokenizer||new rn,this.tokenizer=this.options.tokenizer,this.tokenizer.options=this.options,this.tokenizer.lexer=this,this.inlineQueue=[],this.state={inLink:!1,inRawBlock:!1,top:!0};let n={other:Y,block:Wt.normal,inline:mt.normal};this.options.pedantic?(n.block=Wt.pedantic,n.inline=mt.pedantic):this.options.gfm&&(n.block=Wt.gfm,this.options.breaks?n.inline=mt.breaks:n.inline=mt.gfm),this.tokenizer.rules=n}static get rules(){return{block:Wt,inline:mt}}static lex(t,n){return new xs(n).lex(t)}static lexInline(t,n){return new xs(n).inlineTokens(t)}lex(t){t=t.replace(Y.carriageReturn,`
`),this.blockTokens(t,this.tokens);for(let n=0;n<this.inlineQueue.length;n++){let s=this.inlineQueue[n];this.inlineTokens(s.src,s.tokens)}return this.inlineQueue=[],this.tokens}blockTokens(t,n=[],s=!1){for(this.options.pedantic&&(t=t.replace(Y.tabCharGlobal,"    ").replace(Y.spaceLine,""));t;){let i;if(this.options.extensions?.block?.some(a=>(i=a.call({lexer:this},t,n))?(t=t.substring(i.raw.length),n.push(i),!0):!1))continue;if(i=this.tokenizer.space(t)){t=t.substring(i.raw.length);let a=n.at(-1);i.raw.length===1&&a!==void 0?a.raw+=`
`:n.push(i);continue}if(i=this.tokenizer.code(t)){t=t.substring(i.raw.length);let a=n.at(-1);a?.type==="paragraph"||a?.type==="text"?(a.raw+=(a.raw.endsWith(`
`)?"":`
`)+i.raw,a.text+=`
`+i.text,this.inlineQueue.at(-1).src=a.text):n.push(i);continue}if(i=this.tokenizer.fences(t)){t=t.substring(i.raw.length),n.push(i);continue}if(i=this.tokenizer.heading(t)){t=t.substring(i.raw.length),n.push(i);continue}if(i=this.tokenizer.hr(t)){t=t.substring(i.raw.length),n.push(i);continue}if(i=this.tokenizer.blockquote(t)){t=t.substring(i.raw.length),n.push(i);continue}if(i=this.tokenizer.list(t)){t=t.substring(i.raw.length),n.push(i);continue}if(i=this.tokenizer.html(t)){t=t.substring(i.raw.length),n.push(i);continue}if(i=this.tokenizer.def(t)){t=t.substring(i.raw.length);let a=n.at(-1);a?.type==="paragraph"||a?.type==="text"?(a.raw+=(a.raw.endsWith(`
`)?"":`
`)+i.raw,a.text+=`
`+i.raw,this.inlineQueue.at(-1).src=a.text):this.tokens.links[i.tag]||(this.tokens.links[i.tag]={href:i.href,title:i.title},n.push(i));continue}if(i=this.tokenizer.table(t)){t=t.substring(i.raw.length),n.push(i);continue}if(i=this.tokenizer.lheading(t)){t=t.substring(i.raw.length),n.push(i);continue}let r=t;if(this.options.extensions?.startBlock){let a=1/0,o=t.slice(1),c;this.options.extensions.startBlock.forEach(p=>{c=p.call({lexer:this},o),typeof c=="number"&&c>=0&&(a=Math.min(a,c))}),a<1/0&&a>=0&&(r=t.substring(0,a+1))}if(this.state.top&&(i=this.tokenizer.paragraph(r))){let a=n.at(-1);s&&a?.type==="paragraph"?(a.raw+=(a.raw.endsWith(`
`)?"":`
`)+i.raw,a.text+=`
`+i.text,this.inlineQueue.pop(),this.inlineQueue.at(-1).src=a.text):n.push(i),s=r.length!==t.length,t=t.substring(i.raw.length);continue}if(i=this.tokenizer.text(t)){t=t.substring(i.raw.length);let a=n.at(-1);a?.type==="text"?(a.raw+=(a.raw.endsWith(`
`)?"":`
`)+i.raw,a.text+=`
`+i.text,this.inlineQueue.pop(),this.inlineQueue.at(-1).src=a.text):n.push(i);continue}if(t){let a="Infinite loop on byte: "+t.charCodeAt(0);if(this.options.silent){console.error(a);break}else throw new Error(a)}}return this.state.top=!0,n}inline(t,n=[]){return this.inlineQueue.push({src:t,tokens:n}),n}inlineTokens(t,n=[]){let s=t,i=null;if(this.tokens.links){let c=Object.keys(this.tokens.links);if(c.length>0)for(;(i=this.tokenizer.rules.inline.reflinkSearch.exec(s))!=null;)c.includes(i[0].slice(i[0].lastIndexOf("[")+1,-1))&&(s=s.slice(0,i.index)+"["+"a".repeat(i[0].length-2)+"]"+s.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex))}for(;(i=this.tokenizer.rules.inline.anyPunctuation.exec(s))!=null;)s=s.slice(0,i.index)+"++"+s.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);let r;for(;(i=this.tokenizer.rules.inline.blockSkip.exec(s))!=null;)r=i[2]?i[2].length:0,s=s.slice(0,i.index+r)+"["+"a".repeat(i[0].length-r-2)+"]"+s.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);s=this.options.hooks?.emStrongMask?.call({lexer:this},s)??s;let a=!1,o="";for(;t;){a||(o=""),a=!1;let c;if(this.options.extensions?.inline?.some(d=>(c=d.call({lexer:this},t,n))?(t=t.substring(c.raw.length),n.push(c),!0):!1))continue;if(c=this.tokenizer.escape(t)){t=t.substring(c.raw.length),n.push(c);continue}if(c=this.tokenizer.tag(t)){t=t.substring(c.raw.length),n.push(c);continue}if(c=this.tokenizer.link(t)){t=t.substring(c.raw.length),n.push(c);continue}if(c=this.tokenizer.reflink(t,this.tokens.links)){t=t.substring(c.raw.length);let d=n.at(-1);c.type==="text"&&d?.type==="text"?(d.raw+=c.raw,d.text+=c.text):n.push(c);continue}if(c=this.tokenizer.emStrong(t,s,o)){t=t.substring(c.raw.length),n.push(c);continue}if(c=this.tokenizer.codespan(t)){t=t.substring(c.raw.length),n.push(c);continue}if(c=this.tokenizer.br(t)){t=t.substring(c.raw.length),n.push(c);continue}if(c=this.tokenizer.del(t)){t=t.substring(c.raw.length),n.push(c);continue}if(c=this.tokenizer.autolink(t)){t=t.substring(c.raw.length),n.push(c);continue}if(!this.state.inLink&&(c=this.tokenizer.url(t))){t=t.substring(c.raw.length),n.push(c);continue}let p=t;if(this.options.extensions?.startInline){let d=1/0,u=t.slice(1),v;this.options.extensions.startInline.forEach(g=>{v=g.call({lexer:this},u),typeof v=="number"&&v>=0&&(d=Math.min(d,v))}),d<1/0&&d>=0&&(p=t.substring(0,d+1))}if(c=this.tokenizer.inlineText(p)){t=t.substring(c.raw.length),c.raw.slice(-1)!=="_"&&(o=c.raw.slice(-1)),a=!0;let d=n.at(-1);d?.type==="text"?(d.raw+=c.raw,d.text+=c.text):n.push(c);continue}if(t){let d="Infinite loop on byte: "+t.charCodeAt(0);if(this.options.silent){console.error(d);break}else throw new Error(d)}}return n}},an=class{options;parser;constructor(e){this.options=e||He}space(e){return""}code({text:e,lang:t,escaped:n}){let s=(t||"").match(Y.notSpaceStart)?.[0],i=e.replace(Y.endingNewline,"")+`
`;return s?'<pre><code class="language-'+ye(s)+'">'+(n?i:ye(i,!0))+`</code></pre>
`:"<pre><code>"+(n?i:ye(i,!0))+`</code></pre>
`}blockquote({tokens:e}){return`<blockquote>
${this.parser.parse(e)}</blockquote>
`}html({text:e}){return e}def(e){return""}heading({tokens:e,depth:t}){return`<h${t}>${this.parser.parseInline(e)}</h${t}>
`}hr(e){return`<hr>
`}list(e){let t=e.ordered,n=e.start,s="";for(let a=0;a<e.items.length;a++){let o=e.items[a];s+=this.listitem(o)}let i=t?"ol":"ul",r=t&&n!==1?' start="'+n+'"':"";return"<"+i+r+`>
`+s+"</"+i+`>
`}listitem(e){return`<li>${this.parser.parse(e.tokens)}</li>
`}checkbox({checked:e}){return"<input "+(e?'checked="" ':"")+'disabled="" type="checkbox"> '}paragraph({tokens:e}){return`<p>${this.parser.parseInline(e)}</p>
`}table(e){let t="",n="";for(let i=0;i<e.header.length;i++)n+=this.tablecell(e.header[i]);t+=this.tablerow({text:n});let s="";for(let i=0;i<e.rows.length;i++){let r=e.rows[i];n="";for(let a=0;a<r.length;a++)n+=this.tablecell(r[a]);s+=this.tablerow({text:n})}return s&&(s=`<tbody>${s}</tbody>`),`<table>
<thead>
`+t+`</thead>
`+s+`</table>
`}tablerow({text:e}){return`<tr>
${e}</tr>
`}tablecell(e){let t=this.parser.parseInline(e.tokens),n=e.header?"th":"td";return(e.align?`<${n} align="${e.align}">`:`<${n}>`)+t+`</${n}>
`}strong({tokens:e}){return`<strong>${this.parser.parseInline(e)}</strong>`}em({tokens:e}){return`<em>${this.parser.parseInline(e)}</em>`}codespan({text:e}){return`<code>${ye(e,!0)}</code>`}br(e){return"<br>"}del({tokens:e}){return`<del>${this.parser.parseInline(e)}</del>`}link({href:e,title:t,tokens:n}){let s=this.parser.parseInline(n),i=br(e);if(i===null)return s;e=i;let r='<a href="'+e+'"';return t&&(r+=' title="'+ye(t)+'"'),r+=">"+s+"</a>",r}image({href:e,title:t,text:n,tokens:s}){s&&(n=this.parser.parseInline(s,this.parser.textRenderer));let i=br(e);if(i===null)return ye(n);e=i;let r=`<img src="${e}" alt="${n}"`;return t&&(r+=` title="${ye(t)}"`),r+=">",r}text(e){return"tokens"in e&&e.tokens?this.parser.parseInline(e.tokens):"escaped"in e&&e.escaped?e.text:ye(e.text)}},li=class{strong({text:e}){return e}em({text:e}){return e}codespan({text:e}){return e}del({text:e}){return e}html({text:e}){return e}text({text:e}){return e}link({text:e}){return""+e}image({text:e}){return""+e}br(){return""}checkbox({raw:e}){return e}},oe=class As{options;renderer;textRenderer;constructor(t){this.options=t||He,this.options.renderer=this.options.renderer||new an,this.renderer=this.options.renderer,this.renderer.options=this.options,this.renderer.parser=this,this.textRenderer=new li}static parse(t,n){return new As(n).parse(t)}static parseInline(t,n){return new As(n).parseInline(t)}parse(t){let n="";for(let s=0;s<t.length;s++){let i=t[s];if(this.options.extensions?.renderers?.[i.type]){let a=i,o=this.options.extensions.renderers[a.type].call({parser:this},a);if(o!==!1||!["space","hr","heading","code","table","blockquote","list","html","def","paragraph","text"].includes(a.type)){n+=o||"";continue}}let r=i;switch(r.type){case"space":{n+=this.renderer.space(r);break}case"hr":{n+=this.renderer.hr(r);break}case"heading":{n+=this.renderer.heading(r);break}case"code":{n+=this.renderer.code(r);break}case"table":{n+=this.renderer.table(r);break}case"blockquote":{n+=this.renderer.blockquote(r);break}case"list":{n+=this.renderer.list(r);break}case"checkbox":{n+=this.renderer.checkbox(r);break}case"html":{n+=this.renderer.html(r);break}case"def":{n+=this.renderer.def(r);break}case"paragraph":{n+=this.renderer.paragraph(r);break}case"text":{n+=this.renderer.text(r);break}default:{let a='Token with "'+r.type+'" type was not found.';if(this.options.silent)return console.error(a),"";throw new Error(a)}}}return n}parseInline(t,n=this.renderer){let s="";for(let i=0;i<t.length;i++){let r=t[i];if(this.options.extensions?.renderers?.[r.type]){let o=this.options.extensions.renderers[r.type].call({parser:this},r);if(o!==!1||!["escape","html","link","image","strong","em","codespan","br","del","text"].includes(r.type)){s+=o||"";continue}}let a=r;switch(a.type){case"escape":{s+=n.text(a);break}case"html":{s+=n.html(a);break}case"link":{s+=n.link(a);break}case"image":{s+=n.image(a);break}case"checkbox":{s+=n.checkbox(a);break}case"strong":{s+=n.strong(a);break}case"em":{s+=n.em(a);break}case"codespan":{s+=n.codespan(a);break}case"br":{s+=n.br(a);break}case"del":{s+=n.del(a);break}case"text":{s+=n.text(a);break}default:{let o='Token with "'+a.type+'" type was not found.';if(this.options.silent)return console.error(o),"";throw new Error(o)}}}return s}},$t=class{options;block;constructor(e){this.options=e||He}static passThroughHooks=new Set(["preprocess","postprocess","processAllTokens","emStrongMask"]);static passThroughHooksRespectAsync=new Set(["preprocess","postprocess","processAllTokens"]);preprocess(e){return e}postprocess(e){return e}processAllTokens(e){return e}emStrongMask(e){return e}provideLexer(){return this.block?ae.lex:ae.lexInline}provideParser(){return this.block?oe.parse:oe.parseInline}},Ru=class{defaults=ei();options=this.setOptions;parse=this.parseMarkdown(!0);parseInline=this.parseMarkdown(!1);Parser=oe;Renderer=an;TextRenderer=li;Lexer=ae;Tokenizer=rn;Hooks=$t;constructor(...e){this.use(...e)}walkTokens(e,t){let n=[];for(let s of e)switch(n=n.concat(t.call(this,s)),s.type){case"table":{let i=s;for(let r of i.header)n=n.concat(this.walkTokens(r.tokens,t));for(let r of i.rows)for(let a of r)n=n.concat(this.walkTokens(a.tokens,t));break}case"list":{let i=s;n=n.concat(this.walkTokens(i.items,t));break}default:{let i=s;this.defaults.extensions?.childTokens?.[i.type]?this.defaults.extensions.childTokens[i.type].forEach(r=>{let a=i[r].flat(1/0);n=n.concat(this.walkTokens(a,t))}):i.tokens&&(n=n.concat(this.walkTokens(i.tokens,t)))}}return n}use(...e){let t=this.defaults.extensions||{renderers:{},childTokens:{}};return e.forEach(n=>{let s={...n};if(s.async=this.defaults.async||s.async||!1,n.extensions&&(n.extensions.forEach(i=>{if(!i.name)throw new Error("extension name required");if("renderer"in i){let r=t.renderers[i.name];r?t.renderers[i.name]=function(...a){let o=i.renderer.apply(this,a);return o===!1&&(o=r.apply(this,a)),o}:t.renderers[i.name]=i.renderer}if("tokenizer"in i){if(!i.level||i.level!=="block"&&i.level!=="inline")throw new Error("extension level must be 'block' or 'inline'");let r=t[i.level];r?r.unshift(i.tokenizer):t[i.level]=[i.tokenizer],i.start&&(i.level==="block"?t.startBlock?t.startBlock.push(i.start):t.startBlock=[i.start]:i.level==="inline"&&(t.startInline?t.startInline.push(i.start):t.startInline=[i.start]))}"childTokens"in i&&i.childTokens&&(t.childTokens[i.name]=i.childTokens)}),s.extensions=t),n.renderer){let i=this.defaults.renderer||new an(this.defaults);for(let r in n.renderer){if(!(r in i))throw new Error(`renderer '${r}' does not exist`);if(["options","parser"].includes(r))continue;let a=r,o=n.renderer[a],c=i[a];i[a]=(...p)=>{let d=o.apply(i,p);return d===!1&&(d=c.apply(i,p)),d||""}}s.renderer=i}if(n.tokenizer){let i=this.defaults.tokenizer||new rn(this.defaults);for(let r in n.tokenizer){if(!(r in i))throw new Error(`tokenizer '${r}' does not exist`);if(["options","rules","lexer"].includes(r))continue;let a=r,o=n.tokenizer[a],c=i[a];i[a]=(...p)=>{let d=o.apply(i,p);return d===!1&&(d=c.apply(i,p)),d}}s.tokenizer=i}if(n.hooks){let i=this.defaults.hooks||new $t;for(let r in n.hooks){if(!(r in i))throw new Error(`hook '${r}' does not exist`);if(["options","block"].includes(r))continue;let a=r,o=n.hooks[a],c=i[a];$t.passThroughHooks.has(r)?i[a]=p=>{if(this.defaults.async&&$t.passThroughHooksRespectAsync.has(r))return(async()=>{let u=await o.call(i,p);return c.call(i,u)})();let d=o.call(i,p);return c.call(i,d)}:i[a]=(...p)=>{if(this.defaults.async)return(async()=>{let u=await o.apply(i,p);return u===!1&&(u=await c.apply(i,p)),u})();let d=o.apply(i,p);return d===!1&&(d=c.apply(i,p)),d}}s.hooks=i}if(n.walkTokens){let i=this.defaults.walkTokens,r=n.walkTokens;s.walkTokens=function(a){let o=[];return o.push(r.call(this,a)),i&&(o=o.concat(i.call(this,a))),o}}this.defaults={...this.defaults,...s}}),this}setOptions(e){return this.defaults={...this.defaults,...e},this}lexer(e,t){return ae.lex(e,t??this.defaults)}parser(e,t){return oe.parse(e,t??this.defaults)}parseMarkdown(e){return(t,n)=>{let s={...n},i={...this.defaults,...s},r=this.onError(!!i.silent,!!i.async);if(this.defaults.async===!0&&s.async===!1)return r(new Error("marked(): The async option was set to true by an extension. Remove async: false from the parse options object to return a Promise."));if(typeof t>"u"||t===null)return r(new Error("marked(): input parameter is undefined or null"));if(typeof t!="string")return r(new Error("marked(): input parameter is of type "+Object.prototype.toString.call(t)+", string expected"));if(i.hooks&&(i.hooks.options=i,i.hooks.block=e),i.async)return(async()=>{let a=i.hooks?await i.hooks.preprocess(t):t,o=await(i.hooks?await i.hooks.provideLexer():e?ae.lex:ae.lexInline)(a,i),c=i.hooks?await i.hooks.processAllTokens(o):o;i.walkTokens&&await Promise.all(this.walkTokens(c,i.walkTokens));let p=await(i.hooks?await i.hooks.provideParser():e?oe.parse:oe.parseInline)(c,i);return i.hooks?await i.hooks.postprocess(p):p})().catch(r);try{i.hooks&&(t=i.hooks.preprocess(t));let a=(i.hooks?i.hooks.provideLexer():e?ae.lex:ae.lexInline)(t,i);i.hooks&&(a=i.hooks.processAllTokens(a)),i.walkTokens&&this.walkTokens(a,i.walkTokens);let o=(i.hooks?i.hooks.provideParser():e?oe.parse:oe.parseInline)(a,i);return i.hooks&&(o=i.hooks.postprocess(o)),o}catch(a){return r(a)}}}onError(e,t){return n=>{if(n.message+=`
Please report this to https://github.com/markedjs/marked.`,e){let s="<p>An error occurred:</p><pre>"+ye(n.message+"",!0)+"</pre>";return t?Promise.resolve(s):s}if(t)return Promise.reject(n);throw n}}},Ke=new Ru;function P(e,t){return Ke.parse(e,t)}P.options=P.setOptions=function(e){return Ke.setOptions(e),P.defaults=Ke.defaults,Qa(P.defaults),P};P.getDefaults=ei;P.defaults=He;P.use=function(...e){return Ke.use(...e),P.defaults=Ke.defaults,Qa(P.defaults),P};P.walkTokens=function(e,t){return Ke.walkTokens(e,t)};P.parseInline=Ke.parseInline;P.Parser=oe;P.parser=oe.parse;P.Renderer=an;P.TextRenderer=li;P.Lexer=ae;P.lexer=ae.lex;P.Tokenizer=rn;P.Hooks=$t;P.parse=P;P.options;P.setOptions;P.use;P.walkTokens;P.parseInline;oe.parse;ae.lex;P.setOptions({gfm:!0,breaks:!0,mangle:!1});const xr=["a","b","blockquote","br","code","del","em","h1","h2","h3","h4","hr","i","li","ol","p","pre","strong","table","tbody","td","th","thead","tr","ul"],Ar=["class","href","rel","target","title","start"];let kr=!1;const Pu=14e4,Nu=4e4,Ou=200,Jn=5e4,Oe=new Map;function Du(e){const t=Oe.get(e);return t===void 0?null:(Oe.delete(e),Oe.set(e,t),t)}function Sr(e,t){if(Oe.set(e,t),Oe.size<=Ou)return;const n=Oe.keys().next().value;n&&Oe.delete(n)}function Bu(){kr||(kr=!0,$s.addHook("afterSanitizeAttributes",e=>{!(e instanceof HTMLAnchorElement)||!e.getAttribute("href")||(e.setAttribute("rel","noreferrer noopener"),e.setAttribute("target","_blank"))}))}function ks(e){const t=e.trim();if(!t)return"";if(Bu(),t.length<=Jn){const a=Du(t);if(a!==null)return a}const n=aa(t,Pu),s=n.truncated?`

… truncated (${n.total} chars, showing first ${n.text.length}).`:"";if(n.text.length>Nu){const o=`<pre class="code-block">${Fu(`${n.text}${s}`)}</pre>`,c=$s.sanitize(o,{ALLOWED_TAGS:xr,ALLOWED_ATTR:Ar});return t.length<=Jn&&Sr(t,c),c}const i=P.parse(`${n.text}${s}`),r=$s.sanitize(i,{ALLOWED_TAGS:xr,ALLOWED_ATTR:Ar});return t.length<=Jn&&Sr(t,r),r}function Fu(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}const Uu=1500,Ku=2e3,ao="Copy as markdown",Hu="Copied",zu="Copy failed";async function ju(e){if(!e)return!1;try{return await navigator.clipboard.writeText(e),!0}catch{return!1}}function Gt(e,t){e.title=t,e.setAttribute("aria-label",t)}function qu(e){const t=e.label??ao;return l`
    <button
      class="chat-copy-btn"
      type="button"
      title=${t}
      aria-label=${t}
      @click=${async n=>{const s=n.currentTarget;if(s?.querySelector(".chat-copy-btn__icon"),!s||s.dataset.copying==="1")return;s.dataset.copying="1",s.setAttribute("aria-busy","true"),s.disabled=!0;const i=await ju(e.text());if(s.isConnected){if(delete s.dataset.copying,s.removeAttribute("aria-busy"),s.disabled=!1,!i){s.dataset.error="1",Gt(s,zu),window.setTimeout(()=>{s.isConnected&&(delete s.dataset.error,Gt(s,t))},Ku);return}s.dataset.copied="1",Gt(s,Hu),window.setTimeout(()=>{s.isConnected&&(delete s.dataset.copied,Gt(s,t))},Uu)}}}
    >
      <span class="chat-copy-btn__icon" aria-hidden="true">
        <span class="chat-copy-btn__icon-copy">${G.copy}</span>
        <span class="chat-copy-btn__icon-check">${G.check}</span>
      </span>
    </button>
  `}function Vu(e){return qu({text:()=>e,label:ao})}const Wu={icon:"puzzle",detailKeys:["command","path","url","targetUrl","targetId","ref","element","node","nodeId","id","requestId","to","channelId","guildId","userId","name","query","pattern","messageId"]},Gu={bash:{icon:"wrench",title:"Bash",detailKeys:["command"]},process:{icon:"wrench",title:"Process",detailKeys:["sessionId"]},read:{icon:"fileText",title:"Read",detailKeys:["path"]},write:{icon:"edit",title:"Write",detailKeys:["path"]},edit:{icon:"penLine",title:"Edit",detailKeys:["path"]},attach:{icon:"paperclip",title:"Attach",detailKeys:["path","url","fileName"]},browser:{icon:"globe",title:"Browser",actions:{status:{label:"status"},start:{label:"start"},stop:{label:"stop"},tabs:{label:"tabs"},open:{label:"open",detailKeys:["targetUrl"]},focus:{label:"focus",detailKeys:["targetId"]},close:{label:"close",detailKeys:["targetId"]},snapshot:{label:"snapshot",detailKeys:["targetUrl","targetId","ref","element","format"]},screenshot:{label:"screenshot",detailKeys:["targetUrl","targetId","ref","element"]},navigate:{label:"navigate",detailKeys:["targetUrl","targetId"]},console:{label:"console",detailKeys:["level","targetId"]},pdf:{label:"pdf",detailKeys:["targetId"]},upload:{label:"upload",detailKeys:["paths","ref","inputRef","element","targetId"]},dialog:{label:"dialog",detailKeys:["accept","promptText","targetId"]},act:{label:"act",detailKeys:["request.kind","request.ref","request.selector","request.text","request.value"]}}},canvas:{icon:"image",title:"Canvas",actions:{present:{label:"present",detailKeys:["target","node","nodeId"]},hide:{label:"hide",detailKeys:["node","nodeId"]},navigate:{label:"navigate",detailKeys:["url","node","nodeId"]},eval:{label:"eval",detailKeys:["javaScript","node","nodeId"]},snapshot:{label:"snapshot",detailKeys:["format","node","nodeId"]},a2ui_push:{label:"A2UI push",detailKeys:["jsonlPath","node","nodeId"]},a2ui_reset:{label:"A2UI reset",detailKeys:["node","nodeId"]}}},nodes:{icon:"smartphone",title:"Nodes",actions:{status:{label:"status"},describe:{label:"describe",detailKeys:["node","nodeId"]},pending:{label:"pending"},approve:{label:"approve",detailKeys:["requestId"]},reject:{label:"reject",detailKeys:["requestId"]},notify:{label:"notify",detailKeys:["node","nodeId","title","body"]},camera_snap:{label:"camera snap",detailKeys:["node","nodeId","facing","deviceId"]},camera_list:{label:"camera list",detailKeys:["node","nodeId"]},camera_clip:{label:"camera clip",detailKeys:["node","nodeId","facing","duration","durationMs"]},screen_record:{label:"screen record",detailKeys:["node","nodeId","duration","durationMs","fps","screenIndex"]}}},cron:{icon:"loader",title:"Cron",actions:{status:{label:"status"},list:{label:"list"},add:{label:"add",detailKeys:["job.name","job.id","job.schedule","job.cron"]},update:{label:"update",detailKeys:["id"]},remove:{label:"remove",detailKeys:["id"]},run:{label:"run",detailKeys:["id"]},runs:{label:"runs",detailKeys:["id"]},wake:{label:"wake",detailKeys:["text","mode"]}}},gateway:{icon:"plug",title:"Gateway",actions:{restart:{label:"restart",detailKeys:["reason","delayMs"]},"config.get":{label:"config get"},"config.schema":{label:"config schema"},"config.apply":{label:"config apply",detailKeys:["restartDelayMs"]},"update.run":{label:"update run",detailKeys:["restartDelayMs"]}}},whatsapp_login:{icon:"circle",title:"WhatsApp Login",actions:{start:{label:"start"},wait:{label:"wait"}}},discord:{icon:"messageSquare",title:"Discord",actions:{react:{label:"react",detailKeys:["channelId","messageId","emoji"]},reactions:{label:"reactions",detailKeys:["channelId","messageId"]},sticker:{label:"sticker",detailKeys:["to","stickerIds"]},poll:{label:"poll",detailKeys:["question","to"]},permissions:{label:"permissions",detailKeys:["channelId"]},readMessages:{label:"read messages",detailKeys:["channelId","limit"]},sendMessage:{label:"send",detailKeys:["to","content"]},editMessage:{label:"edit",detailKeys:["channelId","messageId"]},deleteMessage:{label:"delete",detailKeys:["channelId","messageId"]},threadCreate:{label:"thread create",detailKeys:["channelId","name"]},threadList:{label:"thread list",detailKeys:["guildId","channelId"]},threadReply:{label:"thread reply",detailKeys:["channelId","content"]},pinMessage:{label:"pin",detailKeys:["channelId","messageId"]},unpinMessage:{label:"unpin",detailKeys:["channelId","messageId"]},listPins:{label:"list pins",detailKeys:["channelId"]},searchMessages:{label:"search",detailKeys:["guildId","content"]},memberInfo:{label:"member",detailKeys:["guildId","userId"]},roleInfo:{label:"roles",detailKeys:["guildId"]},emojiList:{label:"emoji list",detailKeys:["guildId"]},roleAdd:{label:"role add",detailKeys:["guildId","userId","roleId"]},roleRemove:{label:"role remove",detailKeys:["guildId","userId","roleId"]},channelInfo:{label:"channel",detailKeys:["channelId"]},channelList:{label:"channels",detailKeys:["guildId"]},voiceStatus:{label:"voice",detailKeys:["guildId","userId"]},eventList:{label:"events",detailKeys:["guildId"]},eventCreate:{label:"event create",detailKeys:["guildId","name"]},timeout:{label:"timeout",detailKeys:["guildId","userId"]},kick:{label:"kick",detailKeys:["guildId","userId"]},ban:{label:"ban",detailKeys:["guildId","userId"]}}},slack:{icon:"messageSquare",title:"Slack",actions:{react:{label:"react",detailKeys:["channelId","messageId","emoji"]},reactions:{label:"reactions",detailKeys:["channelId","messageId"]},sendMessage:{label:"send",detailKeys:["to","content"]},editMessage:{label:"edit",detailKeys:["channelId","messageId"]},deleteMessage:{label:"delete",detailKeys:["channelId","messageId"]},readMessages:{label:"read messages",detailKeys:["channelId","limit"]},pinMessage:{label:"pin",detailKeys:["channelId","messageId"]},unpinMessage:{label:"unpin",detailKeys:["channelId","messageId"]},listPins:{label:"list pins",detailKeys:["channelId"]},memberInfo:{label:"member",detailKeys:["userId"]},emojiList:{label:"emoji list"}}}},Qu={fallback:Wu,tools:Gu},oo=Qu,_r=oo.fallback??{icon:"puzzle"},Zu=oo.tools??{};function Yu(e){return(e??"tool").trim()}function Xu(e){const t=e.replace(/_/g," ").trim();return t?t.split(/\s+/).map(n=>n.length<=2&&n.toUpperCase()===n?n:`${n.at(0)?.toUpperCase()??""}${n.slice(1)}`).join(" "):"Tool"}function Ju(e){const t=e?.trim();if(t)return t.replace(/_/g," ")}function lo(e){if(e!=null){if(typeof e=="string"){const t=e.trim();if(!t)return;const n=t.split(/\r?\n/)[0]?.trim()??"";return n?n.length>160?`${n.slice(0,157)}…`:n:void 0}if(typeof e=="number"||typeof e=="boolean")return String(e);if(Array.isArray(e)){const t=e.map(s=>lo(s)).filter(s=>!!s);if(t.length===0)return;const n=t.slice(0,3).join(", ");return t.length>3?`${n}…`:n}}}function ep(e,t){if(!e||typeof e!="object")return;let n=e;for(const s of t.split(".")){if(!s||!n||typeof n!="object")return;n=n[s]}return n}function tp(e,t){for(const n of t){const s=ep(e,n),i=lo(s);if(i)return i}}function np(e){if(!e||typeof e!="object")return;const t=e,n=typeof t.path=="string"?t.path:void 0;if(!n)return;const s=typeof t.offset=="number"?t.offset:void 0,i=typeof t.limit=="number"?t.limit:void 0;return s!==void 0&&i!==void 0?`${n}:${s}-${s+i}`:n}function sp(e){if(!e||typeof e!="object")return;const t=e;return typeof t.path=="string"?t.path:void 0}function ip(e,t){if(!(!e||!t))return e.actions?.[t]??void 0}function rp(e){const t=Yu(e.name),n=t.toLowerCase(),s=Zu[n],i=s?.icon??_r.icon??"puzzle",r=s?.title??Xu(t),a=s?.label??t,o=e.args&&typeof e.args=="object"?e.args.action:void 0,c=typeof o=="string"?o.trim():void 0,p=ip(s,c),d=Ju(p?.label??c);let u;n==="read"&&(u=np(e.args)),!u&&(n==="write"||n==="edit"||n==="attach")&&(u=sp(e.args));const v=p?.detailKeys??s?.detailKeys??_r.detailKeys??[];return!u&&v.length>0&&(u=tp(e.args,v)),!u&&e.meta&&(u=e.meta),u&&(u=op(u)),{name:t,icon:i,title:r,label:a,verb:d,detail:u}}function ap(e){const t=[];if(e.verb&&t.push(e.verb),e.detail&&t.push(e.detail),t.length!==0)return t.join(" · ")}function op(e){return e&&e.replace(/\/Users\/[^/]+/g,"~").replace(/\/home\/[^/]+/g,"~")}const lp=80,cp=2,Tr=100;function dp(e){const t=e.trim();if(t.startsWith("{")||t.startsWith("["))try{const n=JSON.parse(t);return"```json\n"+JSON.stringify(n,null,2)+"\n```"}catch{}return e}function up(e){const t=e.split(`
`),n=t.slice(0,cp),s=n.join(`
`);return s.length>Tr?s.slice(0,Tr)+"…":n.length<t.length?s+"…":s}function pp(e){const t=e,n=fp(t.content),s=[];for(const i of n){const r=String(i.type??"").toLowerCase();(["toolcall","tool_call","tooluse","tool_use"].includes(r)||typeof i.name=="string"&&i.arguments!=null)&&s.push({kind:"call",name:i.name??"tool",args:hp(i.arguments??i.args)})}for(const i of n){const r=String(i.type??"").toLowerCase();if(r!=="toolresult"&&r!=="tool_result")continue;const a=gp(i),o=typeof i.name=="string"?i.name:"tool";s.push({kind:"result",name:o,text:a})}if(ja(e)&&!s.some(i=>i.kind==="result")){const i=typeof t.toolName=="string"&&t.toolName||typeof t.tool_name=="string"&&t.tool_name||"tool",r=oa(e)??void 0;s.push({kind:"result",name:i,text:r})}return s}function Er(e,t){const n=rp({name:e.name,args:e.args}),s=ap(n),i=!!e.text?.trim(),r=!!t,a=r?()=>{if(i){t(dp(e.text));return}const u=`## ${n.label}

${s?`**Command:** \`${s}\`

`:""}*No output — tool completed successfully.*`;t(u)}:void 0,o=i&&(e.text?.length??0)<=lp,c=i&&!o,p=i&&o,d=!i;return l`
    <div
      class="chat-tool-card ${r?"chat-tool-card--clickable":""}"
      @click=${a}
      role=${r?"button":h}
      tabindex=${r?"0":h}
      @keydown=${r?u=>{u.key!=="Enter"&&u.key!==" "||(u.preventDefault(),a?.())}:h}
    >
      <div class="chat-tool-card__header">
        <div class="chat-tool-card__title">
          <span class="chat-tool-card__icon">${G[n.icon]}</span>
          <span>${n.label}</span>
        </div>
        ${r?l`<span class="chat-tool-card__action">${i?"View":""} ${G.check}</span>`:h}
        ${d&&!r?l`<span class="chat-tool-card__status">${G.check}</span>`:h}
      </div>
      ${s?l`<div class="chat-tool-card__detail">${s}</div>`:h}
      ${d?l`<div class="chat-tool-card__status-text muted">Completed</div>`:h}
      ${c?l`<div class="chat-tool-card__preview mono">${up(e.text)}</div>`:h}
      ${p?l`<div class="chat-tool-card__inline mono">${e.text}</div>`:h}
    </div>
  `}function fp(e){return Array.isArray(e)?e.filter(Boolean):[]}function hp(e){if(typeof e!="string")return e;const t=e.trim();if(!t||!t.startsWith("{")&&!t.startsWith("["))return e;try{return JSON.parse(t)}catch{return e}}function gp(e){if(typeof e.text=="string")return e.text;if(typeof e.content=="string")return e.content}function vp(e){const n=e.content,s=[];if(Array.isArray(n))for(const i of n){if(typeof i!="object"||i===null)continue;const r=i;if(r.type==="image"){const a=r.source;if(a?.type==="base64"&&typeof a.data=="string"){const o=a.data,c=a.media_type||"image/png",p=o.startsWith("data:")?o:`data:${c};base64,${o}`;s.push({url:p})}else typeof r.url=="string"&&s.push({url:r.url})}else if(r.type==="image_url"){const a=r.image_url;typeof a?.url=="string"&&s.push({url:a.url})}}return s}function mp(e){return l`
    <div class="chat-group assistant">
      ${ci("assistant",e)}
      <div class="chat-group-messages">
        <div class="chat-bubble chat-reading-indicator" aria-hidden="true">
          <span class="chat-reading-indicator__dots">
            <span></span><span></span><span></span>
          </span>
        </div>
      </div>
    </div>
  `}function yp(e,t,n,s){const i=new Date(t).toLocaleTimeString([],{hour:"numeric",minute:"2-digit"}),r=s?.name??"智能体";return l`
    <div class="chat-group assistant">
      ${ci("assistant",s)}
      <div class="chat-group-messages">
        ${co({role:"assistant",content:[{type:"text",text:e}],timestamp:t},{isStreaming:!0,showReasoning:!1},n)}
        <div class="chat-group-footer">
          <span class="chat-sender-name">${r}</span>
          <span class="chat-group-timestamp">${i}</span>
        </div>
      </div>
    </div>
  `}function bp(e,t){const n=Js(e.role),s=t.assistantName??"智能体",i=n==="user"?"你":n==="assistant"?s:n,r=n==="user"?"user":n==="assistant"?"assistant":"other",a=new Date(e.timestamp).toLocaleTimeString([],{hour:"numeric",minute:"2-digit"});return l`
    <div class="chat-group ${r}">
      ${ci(e.role,{name:s,avatar:t.assistantAvatar??null})}
      <div class="chat-group-messages">
        ${e.messages.map((o,c)=>co(o.message,{isStreaming:e.isStreaming&&c===e.messages.length-1,showReasoning:t.showReasoning},t.onOpenSidebar))}
        <div class="chat-group-footer">
          <span class="chat-sender-name">${i}</span>
          <span class="chat-group-timestamp">${a}</span>
        </div>
      </div>
    </div>
  `}function ci(e,t){const n=Js(e),s=t?.name?.trim()||"智能体",i=t?.avatar?.trim()||"",r=n==="user"?"我":n==="assistant"?s.charAt(0).toUpperCase()||"助":n==="tool"?"⚙":"?",a=n==="user"?"user":n==="assistant"?"assistant":n==="tool"?"tool":"other";return i&&n==="assistant"?$p(i)?l`<img
        class="chat-avatar ${a}"
        src="${i}"
        alt="${s}"
      />`:l`<div class="chat-avatar ${a}">${i}</div>`:l`<div class="chat-avatar ${a}">${r}</div>`}function $p(e){return/^https?:\/\//i.test(e)||/^data:image\//i.test(e)||/^\//.test(e)}function wp(e){return e.length===0?h:l`
    <div class="chat-message-images">
      ${e.map(t=>l`
          <img
            src=${t.url}
            alt=${t.alt??"附件图片"}
            class="chat-message-image"
            @click=${()=>window.open(t.url,"_blank")}
          />
        `)}
    </div>
  `}function co(e,t,n){const s=e,i=typeof s.role=="string"?s.role:"unknown",r=ja(e)||i.toLowerCase()==="toolresult"||i.toLowerCase()==="tool_result"||typeof s.toolCallId=="string"||typeof s.tool_call_id=="string",a=pp(e),o=a.length>0,c=vp(e),p=c.length>0,d=oa(e),u=t.showReasoning&&i==="assistant"?kl(e):null,v=d?.trim()?d:null,g=u?_l(u):null,y=v,w=i==="assistant"&&!!y?.trim(),A=["chat-bubble",w?"has-copy":"",t.isStreaming?"streaming":"","fade-in"].filter(Boolean).join(" ");return!y&&o&&r?l`${a.map(E=>Er(E,n))}`:!y&&!o&&!p?h:l`
    <div class="${A}">
      ${w?Vu(y):h}
      ${wp(c)}
      ${g?l`<div class="chat-thinking">${vs(ks(g))}</div>`:h}
      ${y?l`<div class="chat-text">${vs(ks(y))}</div>`:h}
      ${a.map(E=>Er(E,n))}
    </div>
  `}function xp(e){return l`
    <div class="sidebar-panel">
      <div class="sidebar-header">
        <div class="sidebar-title">工具输出</div>
        <button @click=${e.onClose} class="btn" title="关闭侧边栏">
          ${G.x}
        </button>
      </div>
      <div class="sidebar-content">
        ${e.error?l`
              <div class="callout danger">${e.error}</div>
              <button @click=${e.onViewRawText} class="btn" style="margin-top: 12px;">
                查看原始文本
              </button>
            `:e.content?l`<div class="sidebar-markdown">${vs(ks(e.content))}</div>`:l`<div class="muted">无可用内容</div>`}
      </div>
    </div>
  `}var Ap=Object.defineProperty,kp=Object.getOwnPropertyDescriptor,wn=(e,t,n,s)=>{for(var i=s>1?void 0:s?kp(t,n):t,r=e.length-1,a;r>=0;r--)(a=e[r])&&(i=(s?a(t,n,i):a(i))||i);return s&&i&&Ap(t,n,i),i};let it=class extends Je{constructor(){super(...arguments),this.splitRatio=.6,this.minRatio=.4,this.maxRatio=.7,this.isDragging=!1,this.startX=0,this.startRatio=0,this.handleMouseDown=e=>{this.isDragging=!0,this.startX=e.clientX,this.startRatio=this.splitRatio,this.classList.add("dragging"),document.addEventListener("mousemove",this.handleMouseMove),document.addEventListener("mouseup",this.handleMouseUp),e.preventDefault()},this.handleMouseMove=e=>{if(!this.isDragging)return;const t=this.parentElement;if(!t)return;const n=t.getBoundingClientRect().width,i=(e.clientX-this.startX)/n;let r=this.startRatio+i;r=Math.max(this.minRatio,Math.min(this.maxRatio,r)),this.dispatchEvent(new CustomEvent("resize",{detail:{splitRatio:r},bubbles:!0,composed:!0}))},this.handleMouseUp=()=>{this.isDragging=!1,this.classList.remove("dragging"),document.removeEventListener("mousemove",this.handleMouseMove),document.removeEventListener("mouseup",this.handleMouseUp)}}render(){return l``}connectedCallback(){super.connectedCallback(),this.addEventListener("mousedown",this.handleMouseDown)}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener("mousedown",this.handleMouseDown),document.removeEventListener("mousemove",this.handleMouseMove),document.removeEventListener("mouseup",this.handleMouseUp)}};it.styles=Do`
    :host {
      width: 4px;
      cursor: col-resize;
      background: var(--border, #333);
      transition: background 150ms ease-out;
      flex-shrink: 0;
      position: relative;
    }

    :host::before {
      content: "";
      position: absolute;
      top: 0;
      left: -4px;
      right: -4px;
      bottom: 0;
    }

    :host(:hover) {
      background: var(--accent, #007bff);
    }

    :host(.dragging) {
      background: var(--accent, #007bff);
    }
  `;wn([dn({type:Number})],it.prototype,"splitRatio",2);wn([dn({type:Number})],it.prototype,"minRatio",2);wn([dn({type:Number})],it.prototype,"maxRatio",2);it=wn([Jr("resizable-divider")],it);const Sp=5e3;function _p(e){return e?e.active?l`
      <div class="callout info compaction-indicator compaction-indicator--active">
        ${G.loader} 正在压缩上下文...
      </div>
    `:e.completedAt&&Date.now()-e.completedAt<Sp?l`
        <div class="callout success compaction-indicator compaction-indicator--complete">
          ${G.check} 上下文已压缩
        </div>
      `:h:h}function Tp(){return`att-${Date.now()}-${Math.random().toString(36).slice(2,9)}`}function Ep(e,t){const n=e.clipboardData?.items;if(!n||!t.onAttachmentsChange)return;const s=[];for(let i=0;i<n.length;i++){const r=n[i];r.type.startsWith("image/")&&s.push(r)}if(s.length!==0){e.preventDefault();for(const i of s){const r=i.getAsFile();if(!r)continue;const a=new FileReader;a.onload=()=>{const o=a.result,c={id:Tp(),dataUrl:o,mimeType:r.type},p=t.attachments??[];t.onAttachmentsChange?.([...p,c])},a.readAsDataURL(r)}}}function Cp(e){const t=e.attachments??[];return t.length===0?h:l`
    <div class="chat-attachments">
      ${t.map(n=>l`
          <div class="chat-attachment">
            <img
              src=${n.dataUrl}
              alt="附件预览"
              class="chat-attachment__img"
            />
            <button
              class="chat-attachment__remove"
              type="button"
              aria-label="移除附件"
              @click=${()=>{const s=(e.attachments??[]).filter(i=>i.id!==n.id);e.onAttachmentsChange?.(s)}}
            >
              ${G.x}
            </button>
          </div>
        `)}
    </div>
  `}function Mp(e){const t=e.connected,n=e.sending||e.stream!==null,s=!!(e.canAbort&&e.onAbort),r=e.sessions?.sessions?.find(g=>g.key===e.sessionKey)?.reasoningLevel??"off",a=e.showThinking&&r!=="off",o={name:e.assistantName,avatar:e.assistantAvatar??e.assistantAvatarUrl??null},c=(e.attachments?.length??0)>0,p=e.connected?c?"添加消息或粘贴更多图片...":"发送消息（↩ 发送，Shift+↩ 换行，可粘贴图片）":"连接到网关以开始聊天...",d=e.splitRatio??.6,u=!!(e.sidebarOpen&&e.onCloseSidebar),v=l`
    <div
      class="chat-thread"
      role="log"
      aria-live="polite"
      @scroll=${e.onChatScroll}
    >
      ${e.loading?l`<div class="muted">正在加载聊天...</div>`:h}
      ${Ha(Lp(e),g=>g.key,g=>g.kind==="reading-indicator"?mp(o):g.kind==="stream"?yp(g.text,g.startedAt,e.onOpenSidebar,o):g.kind==="group"?bp(g,{onOpenSidebar:e.onOpenSidebar,showReasoning:a,assistantName:e.assistantName,assistantAvatar:o.avatar}):h)}
    </div>
  `;return l`
    <section class="card chat">
      ${e.disabledReason?l`<div class="callout">${e.disabledReason}</div>`:h}

      ${e.error?l`<div class="callout danger">${e.error}</div>`:h}

      ${_p(e.compactionStatus)}

      ${e.focusMode?l`
            <button
              class="chat-focus-exit"
              type="button"
              @click=${e.onToggleFocusMode}
              aria-label="退出专注模式"
              title="退出专注模式"
            >
              ${G.x}
            </button>
          `:h}

      <div
        class="chat-split-container ${u?"chat-split-container--open":""}"
      >
        <div
          class="chat-main"
          style="flex: ${u?`0 0 ${d*100}%`:"1 1 100%"}"
        >
          ${v}
        </div>

        ${u?l`
              <resizable-divider
                .splitRatio=${d}
                @resize=${g=>e.onSplitRatioChange?.(g.detail.splitRatio)}
              ></resizable-divider>
              <div class="chat-sidebar">
                ${xp({content:e.sidebarContent??null,error:e.sidebarError??null,onClose:e.onCloseSidebar,onViewRawText:()=>{!e.sidebarContent||!e.onOpenSidebar||e.onOpenSidebar(`\`\`\`
${e.sidebarContent}
\`\`\``)}})}
              </div>
            `:h}
      </div>

      ${e.queue.length?l`
            <div class="chat-queue" role="status" aria-live="polite">
              <div class="chat-queue__title">已排队 (${e.queue.length})</div>
              <div class="chat-queue__list">
                ${e.queue.map(g=>l`
                    <div class="chat-queue__item">
                      <div class="chat-queue__text">
                        ${g.text||(g.attachments?.length?`图片 (${g.attachments.length})`:"")}
                      </div>
                      <button
                        class="btn chat-queue__remove"
                        type="button"
                        aria-label="移除排队消息"
                        @click=${()=>e.onQueueRemove(g.id)}
                      >
                        ${G.x}
                      </button>
                    </div>
                  `)}
              </div>
            </div>
          `:h}

      <div class="chat-compose">
        ${Cp(e)}
        <div class="chat-compose__row">
          <label class="field chat-compose__field">
            <span>消息</span>
            <textarea
              .value=${e.draft}
              ?disabled=${!e.connected}
              @keydown=${g=>{g.key==="Enter"&&(g.isComposing||g.keyCode===229||g.shiftKey||e.connected&&(g.preventDefault(),t&&e.onSend()))}}
              @input=${g=>e.onDraftChange(g.target.value)}
              @paste=${g=>Ep(g,e)}
              placeholder=${p}
            ></textarea>
          </label>
          <div class="chat-compose__actions">
            <button
              class="btn"
              ?disabled=${!e.connected||!s&&e.sending}
              @click=${s?e.onAbort:e.onNewSession}
            >
              ${s?"停止回传":"开启新会话"}
            </button>
            <button
              class="btn primary"
              ?disabled=${!e.connected}
              @click=${e.onSend}
            >
              ${n?"排队":"发送"}<kbd class="btn-kbd">↵</kbd>
            </button>
          </div>
        </div>
      </div>
    </section>
  `}const Cr=200;function Ip(e){const t=[];let n=null;for(const s of e){if(s.kind!=="message"){n&&(t.push(n),n=null),t.push(s);continue}const i=za(s.message),r=Js(i.role),a=i.timestamp||Date.now();!n||n.role!==r?(n&&t.push(n),n={kind:"group",key:`group:${r}:${s.key}`,role:r,messages:[{message:s.message,key:s.key}],timestamp:a,isStreaming:!1}):n.messages.push({message:s.message,key:s.key})}return n&&t.push(n),t}function Lp(e){const t=[],n=Array.isArray(e.messages)?e.messages:[],s=Array.isArray(e.toolMessages)?e.toolMessages:[],i=Math.max(0,n.length-Cr);i>0&&t.push({kind:"message",key:"chat:history:notice",message:{role:"system",content:`显示最近 ${Cr} 条消息（隐藏了 ${i} 条）。`,timestamp:Date.now()}});for(let r=i;r<n.length;r++){const a=n[r],o=za(a);!e.showThinking&&o.role.toLowerCase()==="toolresult"||t.push({kind:"message",key:Mr(a,r),message:a})}if(e.showThinking)for(let r=0;r<s.length;r++)t.push({kind:"message",key:Mr(s[r],r+n.length),message:s[r]});if(e.stream!==null){const r=`stream:${e.sessionKey}:${e.streamStartedAt??"live"}`;e.stream.trim().length>0?t.push({kind:"stream",key:r,text:e.stream,startedAt:e.streamStartedAt??Date.now()}):t.push({kind:"reading-indicator",key:r})}return Ip(t)}function Mr(e,t){const n=e,s=typeof n.toolCallId=="string"?n.toolCallId:"";if(s)return`tool:${s}`;const i=typeof n.id=="string"?n.id:"";if(i)return`msg:${i}`;const r=typeof n.messageId=="string"?n.messageId:"";if(r)return`msg:${r}`;const a=typeof n.timestamp=="number"?n.timestamp:null,o=typeof n.role=="string"?n.role:"unknown";return a!=null?`msg:${o}:${a}:${t}`:`msg:${o}:${t}`}function fe(e){if(e)return Array.isArray(e.type)?e.type.filter(n=>n!=="null")[0]??e.type[0]:e.type}function uo(e){if(!e)return"";if(e.default!==void 0)return e.default;switch(fe(e)){case"object":return{};case"array":return[];case"boolean":return!1;case"number":case"integer":return 0;case"string":return"";default:return""}}function Rt(e){return e.map(t=>typeof t=="number"?"*":t).join(".")}function se(e,t){const n=Rt(e),s=t[n];if(s)return s;const i=n.split(".");for(const[r,a]of Object.entries(t)){if(!r.includes("*"))continue;const o=r.split(".");if(o.length!==i.length)continue;let c=!0;for(let p=0;p<i.length;p+=1)if(o[p]!=="*"&&o[p]!==i[p]){c=!1;break}if(c)return a}}function we(e){return e.replace(/_/g," ").replace(/([a-z0-9])([A-Z])/g,"$1 $2").replace(/\s+/g," ").replace(/^./,t=>t.toUpperCase())}function Rp(e){const t=Rt(e).toLowerCase();return t.includes("token")||t.includes("password")||t.includes("secret")||t.includes("apikey")||t.endsWith("key")}function Pp(e,t){const n=Rt(e);if(t.has(n))return!0;const s=n.split(".");for(const i of t){if(!i.includes("*"))continue;const r=i.split(".");if(r.length!==s.length)continue;let a=!0;for(let o=0;o<s.length;o+=1)if(r[o]!=="*"&&r[o]!==s[o]){a=!1;break}if(a)return!0}return!1}const Np=new Set(["title","description","default","nullable"]);function Op(e){return Object.keys(e??{}).filter(n=>!Np.has(n)).length===0}function Dp(e){if(e===void 0)return"";try{return JSON.stringify(e,null,2)??""}catch{return""}}const rt={chevronDown:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>`,plus:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>`,minus:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line></svg>`,trash:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>`,edit:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>`,refresh:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 4v6h-6"></path><path d="M1 20v-6h6"></path><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg>`};function $e(e){const{schema:t,value:n,path:s,hints:i,unsupported:r,disabled:a,onPatch:o,onDiscoverModels:c}=e,p=e.showLabel??!0,d=fe(t),u=se(s,i),v=u?.label??t.title??String(s.at(-1)??""),g=v==="undefined"||!v?we(String(s.at(-1)??"")):v,y=u?.help??t.description;if(Rt(s),Pp(s,r))return l`<div class="cfg-field cfg-field--error">
      <div class="cfg-field__label">${g}</div>
      <div class="cfg-field__error">不支持的架构节点。请使用原生模式 (Raw)。</div>
    </div>`;if(t.anyOf||t.oneOf){const A=(t.anyOf??t.oneOf??[]).filter(k=>!(k.type==="null"||Array.isArray(k.type)&&k.type.includes("null")));if(A.length===1)return $e({...e,schema:A[0]});const E=k=>{if(k.const!==void 0)return k.const;if(k.enum&&k.enum.length===1)return k.enum[0]},C=A.map(E),O=C.every(k=>k!==void 0);if(O&&C.length>0&&C.length<=5){const k=n??t.default;return l`
        <div class="cfg-field">
          ${p?l`<label class="cfg-field__label">${g}</label>`:h}
          ${y?l`<div class="cfg-field__help">${y}</div>`:h}
          <div class="cfg-segmented">
            ${C.map((N,te)=>l`
              <button
                type="button"
                class="cfg-segmented__btn ${N===k||String(N)===String(k)?"active":""}"
                ?disabled=${a}
                @click=${()=>o(s,N)}
              >
                ${String(N)}
              </button>
            `)}
          </div>
        </div>
      `}if(O&&C.length>5)return Lr({...e,options:C,value:n??t.default});const I=new Set(A.map(k=>fe(k)).filter(Boolean)),L=new Set([...I].map(k=>k==="integer"?"number":k));if([...L].every(k=>["string","number","boolean"].includes(k))){const k=L.has("string"),N=L.has("number");if(L.has("boolean")&&L.size===1)return $e({...e,schema:{...t,type:"boolean",anyOf:void 0,oneOf:void 0}});if(k||N)return Ir({...e,inputType:N&&!k?"number":"text"})}}if(t.enum){const w=t.enum;if(w.length<=5){const A=n??t.default;return l`
        <div class="cfg-field">
          ${p?l`<label class="cfg-field__label">${g}</label>`:h}
          ${y?l`<div class="cfg-field__help">${y}</div>`:h}
          <div class="cfg-segmented">
            ${w.map(E=>l`
              <button
                type="button"
                class="cfg-segmented__btn ${E===A||String(E)===String(A)?"active":""}"
                ?disabled=${a}
                @click=${()=>o(s,E)}
              >
                ${String(E)}
              </button>
            `)}
          </div>
        </div>
      `}return Lr({...e,options:w,value:n??t.default})}if(d==="object")return Fp(e);if(d==="array")return Up(e);if(d==="boolean"){const w=typeof n=="boolean"?n:typeof t.default=="boolean"?t.default:!1;return l`
      <label class="cfg-toggle-row ${a?"disabled":""}">
        <div class="cfg-toggle-row__content">
          <span class="cfg-toggle-row__label">${g}</span>
          ${y?l`<span class="cfg-toggle-row__help">${y}</span>`:h}
        </div>
        <div class="cfg-toggle">
          <input
            type="checkbox"
            .checked=${w}
            ?disabled=${a}
            @change=${A=>o(s,A.target.checked)}
          />
          <span class="cfg-toggle__track"></span>
        </div>
      </label>
    `}return d==="number"||d==="integer"?Bp(e):d==="string"?Ir({...e,inputType:"text"}):l`
    <div class="cfg-field cfg-field--error">
      <div class="cfg-field__label">${g}</div>
      <div class="cfg-field__error">不支持的类型: ${d}。请使用原生模式 (Raw)。</div>
    </div>
  `}function Ir(e){const{schema:t,value:n,path:s,hints:i,disabled:r,onPatch:a,inputType:o}=e,c=e.showLabel??!0,p=se(s,i),d=p?.label??t.title??we(String(s.at(-1))),u=p?.help??t.description,v=p?.sensitive??Rp(s),g=p?.placeholder??(v?"••••":t.default!==void 0?`默认值: ${t.default}`:""),y=n??"";return l`
    <div class="cfg-field">
      ${c?l`<label class="cfg-field__label">${d}</label>`:h}
      ${u?l`<div class="cfg-field__help">${u}</div>`:h}
      <div class="cfg-input-wrap">
        <input
          type=${v?"password":o}
          class="cfg-input"
          placeholder=${g}
          .value=${y==null?"":String(y)}
          ?disabled=${r}
          @input=${w=>{const A=w.target.value;if(o==="number"){if(A.trim()===""){a(s,void 0);return}const E=Number(A);a(s,Number.isNaN(E)?A:E);return}a(s,A)}}
        />
        ${t.default!==void 0?l`
          <button
            type="button"
            class="cfg-input__reset"
            title="重置为默认值"
            ?disabled=${r}
            @click=${()=>a(s,t.default)}
          >↺</button>
        `:h}
      </div>
    </div>
  `}function Bp(e){const{schema:t,value:n,path:s,hints:i,disabled:r,onPatch:a}=e,o=e.showLabel??!0,c=se(s,i),p=c?.label??t.title??we(String(s.at(-1))),d=c?.help??t.description,u=n??t.default??"",v=typeof u=="number"?u:0;return l`
    <div class="cfg-field">
      ${o?l`<label class="cfg-field__label">${p}</label>`:h}
      ${d?l`<div class="cfg-field__help">${d}</div>`:h}
      <div class="cfg-number">
        <button
          type="button"
          class="cfg-number__btn"
          ?disabled=${r}
          @click=${()=>a(s,v-1)}
        >−</button>
        <input
          type="number"
          class="cfg-number__input"
          .value=${u==null?"":String(u)}
          ?disabled=${r}
          @input=${g=>{const y=g.target.value,w=y===""?void 0:Number(y);a(s,w)}}
        />
        <button
          type="button"
          class="cfg-number__btn"
          ?disabled=${r}
          @click=${()=>a(s,v+1)}
        >+</button>
      </div>
    </div>
  `}function Lr(e){const{schema:t,value:n,path:s,hints:i,disabled:r,options:a,onPatch:o}=e,c=e.showLabel??!0,p=se(s,i),d=p?.label??t.title??we(String(s.at(-1))),u=p?.help??t.description,v=n??t.default,g=a.findIndex(w=>w===v||String(w)===String(v)),y="__unset__";return l`
    <div class="cfg-field">
      ${c?l`<label class="cfg-field__label">${d}</label>`:h}
      ${u?l`<div class="cfg-field__help">${u}</div>`:h}
      <select
        class="cfg-select"
        ?disabled=${r}
        .value=${g>=0?String(g):y}
        @change=${w=>{const A=w.target.value;o(s,A===y?void 0:a[Number(A)])}}
      >
        <option value=${y}>请选择...</option>
        ${a.map((w,A)=>l`
          <option value=${String(A)}>${String(w)}</option>
        `)}
      </select>
    </div>
  `}function Fp(e){const{schema:t,value:n,path:s,hints:i,unsupported:r,disabled:a,onPatch:o,onDiscoverModels:c}=e;e.showLabel;const p=se(s,i),d=p?.label??t.title??String(s.at(-1)??""),u=d==="undefined"||!d?we(String(s.at(-1)??"")):d,v=p?.help??t.description,y=s.length===3&&s[0]==="models"&&s[1]==="providers"?String(s[2]):null,w=n??t.default,A=w&&typeof w=="object"&&!Array.isArray(w)?w:{},E=t.properties??{},O=Object.entries(E).sort((N,te)=>{const ze=se([...s,N[0]],i)?.order??0,Pt=se([...s,te[0]],i)?.order??0;return ze!==Pt?ze-Pt:N[0].localeCompare(te[0])}),I=new Set(Object.keys(E)),L=t.additionalProperties,k=!!L&&typeof L=="object";return s.length===1?l`
      <div class="cfg-fields">
        ${O.map(([N,te])=>$e({schema:te,value:A[N],path:[...s,N],hints:i,unsupported:r,disabled:a,onPatch:o,onDiscoverModels:c}))}
        ${k?Rr({schema:L,value:A,path:s,hints:i,unsupported:r,disabled:a,reservedKeys:I,onPatch:o}):h}
      </div>
    `:l`
    <details class="cfg-object" open>
      <summary class="cfg-object__header">
        <span class="cfg-object__title">${u}</span>
        ${y?l`
          <button 
            type="button" 
            class="cfg-btn cfg-btn--sm cfg-btn--ghost"
            style="margin-left: auto; margin-right: 8px; font-size: 11px; padding: 2px 6px;"
            ?disabled=${a}
            @click=${N=>{N.preventDefault(),N.stopPropagation(),c?.(y)}}
          >
            <span style="display: inline-flex; width: 12px; height: 12px; margin-right: 4px;">${rt.refresh}</span>
            获取模型列表
          </button>
        `:h}
        <span class="cfg-object__chevron">${rt.chevronDown}</span>
      </summary>
      ${v?l`<div class="cfg-object__help">${v}</div>`:h}
      <div class="cfg-object__content">
        ${O.map(([N,te])=>$e({schema:te,value:A[N],path:[...s,N],hints:i,unsupported:r,disabled:a,onPatch:o,onDiscoverModels:c}))}
        ${k?Rr({schema:L,value:A,path:s,hints:i,unsupported:r,disabled:a,reservedKeys:I,onPatch:o}):h}
      </div>
    </details>
  `}function Up(e){const{schema:t,value:n,path:s,hints:i,unsupported:r,disabled:a,onPatch:o}=e,c=e.showLabel??!0,p=se(s,i),d=p?.label??t.title??we(String(s.at(-1))),u=p?.help??t.description,v=Array.isArray(t.items)?t.items[0]:t.items;if(!v)return l`
      <div class="cfg-field cfg-field--error">
        <div class="cfg-field__label">${d}</div>
        <div class="cfg-field__error">不支持的数组架构。请使用原生模式 (Raw)。</div>
      </div>
    `;const g=Array.isArray(n)?n:Array.isArray(t.default)?t.default:[];return l`
    <div class="cfg-array">
      <div class="cfg-array__header">
        ${c?l`<span class="cfg-array__label">${d}</span>`:h}
        <span class="cfg-array__count">${g.length} 个条目</span>
        <button
          type="button"
          class="cfg-array__add"
          ?disabled=${a}
          @click=${()=>{const y=[...g,uo(v)];o(s,y)}}
        >
          <span class="cfg-array__add-icon">${rt.plus}</span>
          添加
        </button>
      </div>
      ${u?l`<div class="cfg-array__help">${u}</div>`:h}

      ${g.length===0?l`
        <div class="cfg-array__empty">
          暂无项目。点击“添加”创建一个。
        </div>
      `:l`
        <div class="cfg-array__items">
          ${g.map((y,w)=>l`
            <div class="cfg-array__item">
              <div class="cfg-array__item-header">
                <span class="cfg-array__item-index">#${w+1}</span>
                <button
                  type="button"
                  class="cfg-array__item-remove"
                  title="删除项目"
                  ?disabled=${a}
                  @click=${()=>{const A=[...g];A.splice(w,1),o(s,A)}}
                >
                  ${rt.trash}
                </button>
              </div>
              <div class="cfg-array__item-content">
                ${$e({schema:v,value:y,path:[...s,w],hints:i,unsupported:r,disabled:a,showLabel:!1,onPatch:o,onDiscoverModels})}
              </div>
            </div>
          `)}
        </div>
      `}
    </div>
  `}function Rr(e){const{schema:t,value:n,path:s,hints:i,unsupported:r,disabled:a,reservedKeys:o,onPatch:c}=e,p=Op(t),d=Object.entries(n??{}).filter(([u])=>!o.has(u));return l`
    <div class="cfg-map">
      <div class="cfg-map__header">
        <span class="cfg-map__label">自定义条目</span>
        <button
          type="button"
          class="cfg-map__add"
          ?disabled=${a}
          @click=${()=>{const u={...n??{}};let v=1,g=`custom-${v}`;for(;g in u;)v+=1,g=`custom-${v}`;u[g]=p?{}:uo(t),c(s,u)}}
        >
          <span class="cfg-map__add-icon">${rt.plus}</span>
          添加条目
        </button>
      </div>

      ${d.length===0?l`
        <div class="cfg-map__empty">暂无自定义条目。</div>
      `:l`
        <div class="cfg-map__items">
          ${d.map(([u,v])=>{const g=[...s,u],y=Dp(v);return l`
              <div class="cfg-map__item">
                <div class="cfg-map__item-key">
                  <input
                    type="text"
                    class="cfg-input cfg-input--sm"
                    placeholder="键 (Key)"
                    .value=${u}
                    ?disabled=${a}
                    @change=${w=>{const A=w.target.value.trim();if(!A||A===u)return;const E={...n??{}};A in E||(E[A]=E[u],delete E[u],c(s,E))}}
                  />
                </div>
                <div class="cfg-map__item-value">
                  ${p?l`
                        <textarea
                          class="cfg-textarea cfg-textarea--sm"
                          placeholder="JSON 值"
                          rows="2"
                          .value=${y}
                          ?disabled=${a}
                          @change=${w=>{const A=w.target,E=A.value.trim();if(!E){c(g,void 0);return}try{c(g,JSON.parse(E))}catch{A.value=y}}}
                        ></textarea>
                      `:$e({schema:t,value:v,path:g,hints:i,unsupported:r,disabled:a,showLabel:!1,onPatch:c,onDiscoverModels})}
                </div>
                <button
                  type="button"
                  class="cfg-map__item-remove"
                  title="删除条目"
                  ?disabled=${a}
                  @click=${()=>{const w={...n??{}};delete w[u],c(s,w)}}
                >
                  ${rt.trash}
                </button>
              </div>
            `})}
        </div>
      `}
    </div>
  `}const Pr={env:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>`,update:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>`,agents:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 2a2 2 0 0 1 2 2c0 .74-.4 1.39-1 1.73V7h1a7 7 0 0 1 7 7h1a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-1v1a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-1H2a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h1a7 7 0 0 1 7-7h1V5.73c-.6-.34-1-.99-1-1.73a2 2 0 0 1 2-2z"></path><circle cx="8" cy="14" r="1"></circle><circle cx="16" cy="14" r="1"></circle></svg>`,auth:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>`,channels:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>`,messages:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>`,commands:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><polyline points="4 17 10 11 4 5"></polyline><line x1="12" y1="19" x2="20" y2="19"></line></svg>`,hooks:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg>`,skills:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>`,tools:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path></svg>`,gateway:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>`,wizard:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M15 4V2"></path><path d="M15 16v-2"></path><path d="M8 9h2"></path><path d="M20 9h2"></path><path d="M17.8 11.8 19 13"></path><path d="M15 9h0"></path><path d="M17.8 6.2 19 5"></path><path d="m3 21 9-9"></path><path d="M12.2 6.2 11 5"></path></svg>`,meta:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 20h9"></path><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"></path></svg>`,logging:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>`,browser:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"></circle><circle cx="12" cy="12" r="4"></circle><line x1="21.17" y1="8" x2="12" y2="8"></line><line x1="3.95" y1="6.06" x2="8.54" y2="14"></line><line x1="10.88" y1="21.94" x2="15.46" y2="14"></line></svg>`,ui:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="3" y1="9" x2="21" y2="9"></line><line x1="9" y1="21" x2="9" y2="9"></line></svg>`,models:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>`,bindings:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect><rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect><line x1="6" y1="6" x2="6.01" y2="6"></line><line x1="6" y1="18" x2="6.01" y2="18"></line></svg>`,broadcast:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4.9 19.1C1 15.2 1 8.8 4.9 4.9"></path><path d="M7.8 16.2c-2.3-2.3-2.3-6.1 0-8.5"></path><circle cx="12" cy="12" r="2"></circle><path d="M16.2 7.8c2.3 2.3 2.3 6.1 0 8.5"></path><path d="M19.1 4.9C23 8.8 23 15.1 19.1 19"></path></svg>`,audio:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M9 18V5l12-2v13"></path><circle cx="6" cy="18" r="3"></circle><circle cx="18" cy="16" r="3"></circle></svg>`,session:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>`,cron:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>`,web:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>`,discovery:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>`,canvasHost:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>`,talk:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path><path d="M19 10v2a7 7 0 0 1-14 0v-2"></path><line x1="12" y1="19" x2="12" y2="23"></line><line x1="8" y1="23" x2="16" y2="23"></line></svg>`,plugins:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 2v6"></path><path d="m4.93 10.93 4.24 4.24"></path><path d="M2 12h6"></path><path d="m4.93 13.07 4.24-4.24"></path><path d="M12 22v-6"></path><path d="m19.07 13.07-4.24-4.24"></path><path d="M22 12h-6"></path><path d="m19.07 10.93-4.24 4.24"></path></svg>`,default:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg>`},di={env:{label:"环境",description:"传递给网关进程的环境变量"},update:{label:"更新",description:"自动更新设置与发布渠道"},agents:{label:"智能体",description:"智能体配置、模型与身份"},auth:{label:"身份验证",description:"API 密钥与身份验证配置文件"},channels:{label:"渠道",description:"消息渠道 (Telegram, Discord, Slack 等)"},messages:{label:"消息",description:"消息处理与路由设置"},commands:{label:"命令",description:"自定义斜杠命令"},hooks:{label:"钩子",description:"Webhook 与事件钩子"},skills:{label:"技能",description:"技能包与底层技术能力"},tools:{label:"工具",description:"工具配置 (浏览器、搜索等)"},gateway:{label:"网关",description:"网关服务器设置 (端口、身份验证、绑定)"},wizard:{label:"设置向导",description:"设置向导状态与历史记录"},meta:{label:"元数据",description:"网关元数据与版本信息"},logging:{label:"日志",description:"日志级别与输出配置"},browser:{label:"浏览器",description:"浏览器自动化设置"},ui:{label:"界面",description:"用户界面偏好设置"},models:{label:"模型",description:"AI 模型配置与供应商"},bindings:{label:"绑定",description:"按键绑定与快捷键"},broadcast:{label:"广播",description:"广播与通知设置"},audio:{label:"音频",description:"音频输入/输出设置"},session:{label:"会话",description:"会话管理与持久化"},cron:{label:"定时任务",description:"计划任务与自动化"},web:{label:"网页",description:"Web 服务器与 API 设置"},discovery:{label:"发现",description:"服务发现与网络设置"},canvasHost:{label:"画布宿主",description:"画布渲染与显示"},talk:{label:"语音",description:"语音与对话设置"},plugins:{label:"插件",description:"插件管理与扩展"}};function Nr(e){return Pr[e]??Pr.default}function Kp(e,t,n){if(!n)return!0;const s=n.toLowerCase(),i=di[e];return e.toLowerCase().includes(s)||i&&(i.label.toLowerCase().includes(s)||i.description.toLowerCase().includes(s))?!0:wt(t,s)}function wt(e,t){if(e.title?.toLowerCase().includes(t)||e.description?.toLowerCase().includes(t)||e.enum?.some(s=>String(s).toLowerCase().includes(t)))return!0;if(e.properties){for(const[s,i]of Object.entries(e.properties))if(s.toLowerCase().includes(t)||wt(i,t))return!0}if(e.items){const s=Array.isArray(e.items)?e.items:[e.items];for(const i of s)if(i&&wt(i,t))return!0}if(e.additionalProperties&&typeof e.additionalProperties=="object"&&wt(e.additionalProperties,t))return!0;const n=e.anyOf??e.oneOf??e.allOf;if(n){for(const s of n)if(s&&wt(s,t))return!0}return!1}function Hp(e){if(!e.schema)return l`<div class="muted">架构定义不可用。</div>`;const t=e.schema,n=e.value??{};if(fe(t)!=="object"||!t.properties)return l`<div class="callout danger">不支持的架构。请使用原生模式 (Raw)。</div>`;const s=new Set(e.unsupportedPaths??[]),i=t.properties,r=e.searchQuery??"",a=e.activeSection,o=e.activeSubsection??null,p=Object.entries(i).sort((u,v)=>{const g=se([u[0]],e.uiHints)?.order??50,y=se([v[0]],e.uiHints)?.order??50;return g!==y?g-y:u[0].localeCompare(v[0])}).filter(([u,v])=>!(a&&u!==a||r&&!Kp(u,v,r)));let d=null;if(a&&o&&p.length===1){const u=p[0]?.[1];u&&fe(u)==="object"&&u.properties&&u.properties[o]&&(d={sectionKey:a,subsectionKey:o,schema:u.properties[o]})}return p.length===0?l`
      <div class="config-empty">
        <div class="config-empty__icon">${G.search}</div>
        <div class="config-empty__text">
          ${r?`没有匹配 “${r}” 的设置`:"此部分暂无设置"}
        </div>
      </div>
    `:l`
    <div class="config-form config-form--modern">
      ${d?(()=>{const{sectionKey:u,subsectionKey:v,schema:g}=d,y=se([u,v],e.uiHints),w=y?.label??g.title??we(v),A=y?.help??g.description??"",E=n[u],C=E&&typeof E=="object"?E[v]:void 0,O=`config-section-${u}-${v}`;return l`
              <section class="config-section-card" id=${O}>
                <div class="config-section-card__header">
                  <span class="config-section-card__icon">${Nr(u)}</span>
                  <div class="config-section-card__titles">
                    <h3 class="config-section-card__title">${w}</h3>
                    ${A?l`<p class="config-section-card__desc">${A}</p>`:h}
                  </div>
                </div>
                <div class="config-section-card__content">
                  ${$e({schema:g,value:C,path:[u,v],hints:e.uiHints,unsupported:s,disabled:e.disabled??!1,showLabel:!1,onPatch:e.onPatch,onDiscoverModels:e.onDiscoverModels})}
                </div>
              </section>
            `})():p.map(([u,v])=>{const g=di[u]??{label:u.charAt(0).toUpperCase()+u.slice(1),description:v.description??""};return l`
              <section class="config-section-card" id="config-section-${u}">
                <div class="config-section-card__header">
                  <span class="config-section-card__icon">${Nr(u)}</span>
                  <div class="config-section-card__titles">
                    <h3 class="config-section-card__title">${g.label}</h3>
                    ${g.description?l`<p class="config-section-card__desc">${g.description}</p>`:h}
                  </div>
                </div>
                <div class="config-section-card__content">
                  ${$e({schema:v,value:n[u],path:[u],hints:e.uiHints,unsupported:s,disabled:e.disabled??!1,showLabel:!1,onPatch:e.onPatch,onDiscoverModels:e.onDiscoverModels})}
                </div>
              </section>
            `})}
    </div>
  `}const zp=new Set(["title","description","default","nullable"]);function jp(e){return Object.keys(e??{}).filter(n=>!zp.has(n)).length===0}function po(e){const t=e.filter(i=>i!=null),n=t.length!==e.length,s=[];for(const i of t)s.some(r=>Object.is(r,i))||s.push(i);return{enumValues:s,nullable:n}}function fo(e){return!e||typeof e!="object"?{schema:null,unsupportedPaths:["<root>"]}:kt(e,[])}function kt(e,t){const n=new Set,s={...e},i=Rt(t)||"<root>";if(e.anyOf||e.oneOf||e.allOf){const o=qp(e,t);return o||{schema:e,unsupportedPaths:[i]}}const r=Array.isArray(e.type)&&e.type.includes("null"),a=fe(e)??(e.properties||e.additionalProperties?"object":void 0);if(s.type=a??e.type,s.nullable=r||e.nullable,s.enum){const{enumValues:o,nullable:c}=po(s.enum);s.enum=o,c&&(s.nullable=!0),o.length===0&&n.add(i)}if(a==="object"){const o=e.properties??{},c={};for(const[p,d]of Object.entries(o)){const u=kt(d,[...t,p]);u.schema&&(c[p]=u.schema);for(const v of u.unsupportedPaths)n.add(v)}if(s.properties=c,e.additionalProperties===!0)s.additionalProperties=!0;else if(e.additionalProperties===!1)s.additionalProperties=!1;else if(e.additionalProperties&&typeof e.additionalProperties=="object"&&!jp(e.additionalProperties)){const p=kt(e.additionalProperties,[...t,"*"]);s.additionalProperties=p.schema??e.additionalProperties}}else if(a==="array"){const o=Array.isArray(e.items)?e.items[0]:e.items;if(!o)n.add(i);else{const c=kt(o,[...t,"*"]);s.items=c.schema??o}}else a!=="string"&&a!=="number"&&a!=="integer"&&a!=="boolean"&&!s.enum&&n.add(i);return{schema:s,unsupportedPaths:Array.from(n)}}function qp(e,t){if(e.allOf)return null;const n=e.anyOf??e.oneOf;if(!n)return null;const s=[],i=[];let r=!1;for(const o of n){if(!o||typeof o!="object")return null;if(Array.isArray(o.enum)){const{enumValues:c,nullable:p}=po(o.enum);s.push(...c),p&&(r=!0);continue}if("const"in o){if(o.const==null){r=!0;continue}s.push(o.const);continue}if(fe(o)==="null"){r=!0;continue}i.push(o)}if(s.length>0&&i.length===0){const o=[];for(const c of s)o.some(p=>Object.is(p,c))||o.push(c);return{schema:{...e,enum:o,nullable:r,anyOf:void 0,oneOf:void 0,allOf:void 0},unsupportedPaths:[]}}if(i.length===1){const o=kt(i[0],t);return o.schema&&(o.schema.nullable=r||o.schema.nullable),o}const a=["string","number","integer","boolean"];return i.length>0&&s.length===0&&i.every(o=>o.type&&a.includes(String(o.type)))?{schema:{...e,nullable:r},unsupportedPaths:[]}:null}const Ss={all:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>`,env:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>`,update:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>`,agents:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2a2 2 0 0 1 2 2c0 .74-.4 1.39-1 1.73V7h1a7 7 0 0 1 7 7h1a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-1v1a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-1H2a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h1a7 7 0 0 1 7-7h1V5.73c-.6-.34-1-.99-1-1.73a2 2 0 0 1 2-2z"></path><circle cx="8" cy="14" r="1"></circle><circle cx="16" cy="14" r="1"></circle></svg>`,auth:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>`,channels:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>`,messages:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>`,commands:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="4 17 10 11 4 5"></polyline><line x1="12" y1="19" x2="20" y2="19"></line></svg>`,hooks:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg>`,skills:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>`,tools:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path></svg>`,gateway:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>`,wizard:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 4V2"></path><path d="M15 16v-2"></path><path d="M8 9h2"></path><path d="M20 9h2"></path><path d="M17.8 11.8 19 13"></path><path d="M15 9h0"></path><path d="M17.8 6.2 19 5"></path><path d="m3 21 9-9"></path><path d="M12.2 6.2 11 5"></path></svg>`,meta:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"></path><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"></path></svg>`,logging:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>`,browser:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><circle cx="12" cy="12" r="4"></circle><line x1="21.17" y1="8" x2="12" y2="8"></line><line x1="3.95" y1="6.06" x2="8.54" y2="14"></line><line x1="10.88" y1="21.94" x2="15.46" y2="14"></line></svg>`,ui:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="3" y1="9" x2="21" y2="9"></line><line x1="9" y1="21" x2="9" y2="9"></line></svg>`,models:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>`,bindings:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect><rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect><line x1="6" y1="6" x2="6.01" y2="6"></line><line x1="6" y1="18" x2="6.01" y2="18"></line></svg>`,broadcast:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4.9 19.1C1 15.2 1 8.8 4.9 4.9"></path><path d="M7.8 16.2c-2.3-2.3-2.3-6.1 0-8.5"></path><circle cx="12" cy="12" r="2"></circle><path d="M16.2 7.8c2.3 2.3 2.3 6.1 0 8.5"></path><path d="M19.1 4.9C23 8.8 23 15.1 19.1 19"></path></svg>`,audio:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18V5l12-2v13"></path><circle cx="6" cy="18" r="3"></circle><circle cx="18" cy="16" r="3"></circle></svg>`,session:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>`,cron:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>`,web:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>`,discovery:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>`,canvasHost:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>`,talk:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path><path d="M19 10v2a7 7 0 0 1-14 0v-2"></path><line x1="12" y1="19" x2="12" y2="23"></line><line x1="8" y1="23" x2="16" y2="23"></line></svg>`,plugins:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v6"></path><path d="m4.93 10.93 4.24 4.24"></path><path d="M2 12h6"></path><path d="m4.93 13.07 4.24-4.24"></path><path d="M12 22v-6"></path><path d="m19.07 13.07-4.24-4.24"></path><path d="M22 12h-6"></path><path d="m19.07 10.93-4.24 4.24"></path></svg>`,default:l`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg>`},Or=[{key:"models",label:"大模型"},{key:"auth",label:"身份验证"},{key:"agents",label:"智能体"},{key:"channels",label:"渠道"},{key:"env",label:"环境"},{key:"gateway",label:"网关"},{key:"skills",label:"技能"},{key:"tools",label:"工具"},{key:"messages",label:"消息"},{key:"commands",label:"命令"},{key:"hooks",label:"钩子"},{key:"update",label:"更新"},{key:"wizard",label:"设置向导"},{key:"ui",label:"界面"},{key:"logging",label:"日志"}],Dr="__all__";function Br(e){return Ss[e]??Ss.default}function Vp(e,t){const n=di[e];return n||{label:t?.title??we(e),description:t?.description??""}}function Wp(e){const{key:t,schema:n,uiHints:s}=e;if(!n||fe(n)!=="object"||!n.properties)return[];const i=Object.entries(n.properties).map(([r,a])=>{const o=se([t,r],s),c=o?.label??a.title??we(r),p=o?.help??a.description??"",d=o?.order??50;return{key:r,label:c,description:p,order:d}});return i.sort((r,a)=>r.order!==a.order?r.order-a.order:r.key.localeCompare(a.key)),i}function Gp(e,t){if(!e||!t)return[];const n=[];function s(i,r,a){if(i===r)return;if(typeof i!=typeof r){n.push({path:a,from:i,to:r});return}if(typeof i!="object"||i===null||r===null){i!==r&&n.push({path:a,from:i,to:r});return}if(Array.isArray(i)&&Array.isArray(r)){JSON.stringify(i)!==JSON.stringify(r)&&n.push({path:a,from:i,to:r});return}const o=i,c=r,p=new Set([...Object.keys(o),...Object.keys(c)]);for(const d of p)s(o[d],c[d],a?`${a}.${d}`:d)}return s(e,t,""),n}function Fr(e,t=40){let n;try{n=JSON.stringify(e)??String(e)}catch{n=String(e)}return n.length<=t?n:n.slice(0,t-3)+"..."}function Qp(e){const t=e.valid==null?"unknown":e.valid?"valid":"invalid",n=fo(e.schema),s=n.schema?n.unsupportedPaths.length>0:!1,i=n.schema?.properties??{},r=Or.filter(k=>k.key in i),a=new Set(Or.map(k=>k.key)),o=Object.keys(i).filter(k=>!a.has(k)).map(k=>({key:k,label:k.charAt(0).toUpperCase()+k.slice(1)})),c=[...r,...o],p=e.activeSection&&n.schema&&fe(n.schema)==="object"?n.schema.properties?.[e.activeSection]:void 0,d=e.activeSection?Vp(e.activeSection,p):null,u=e.activeSection?Wp({key:e.activeSection,schema:p,uiHints:e.uiHints}):[],v=e.formMode==="form"&&!!e.activeSection&&u.length>0,g=e.activeSubsection===Dr,y=e.searchQuery||g?null:e.activeSubsection??u[0]?.key??null,w=e.formMode==="form"?Gp(e.originalValue,e.formValue):[],A=e.formMode==="raw"&&e.raw!==e.originalRaw,E=e.formMode==="form"?w.length>0:A,C=!!e.formValue&&!e.loading&&!!n.schema,O=e.connected&&!e.saving&&E&&(e.formMode==="raw"?!0:C),I=e.connected&&!e.applying&&!e.updating&&E&&(e.formMode==="raw"?!0:C),L=e.connected&&!e.applying&&!e.updating;return l`
    <div class="config-layout">
      <!-- Sidebar -->
      <aside class="config-sidebar">
        <div class="config-sidebar__header">
          <div class="config-sidebar__title">设置</div>
          <span class="pill pill--sm ${t==="valid"?"pill--ok":t==="invalid"?"pill--danger":""}">${t==="valid"?"有效":t==="invalid"?"无效":"未知"}</span>
        </div>

        <!-- Search -->
        <div class="config-search">
          <svg class="config-search__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="11" cy="11" r="8"></circle>
            <path d="M21 21l-4.35-4.35"></path>
          </svg>
          <input
            type="text"
            class="config-search__input"
            placeholder="搜索设置..."
            .value=${e.searchQuery}
            @input=${k=>e.onSearchChange(k.target.value)}
          />
          ${e.searchQuery?l`
            <button
              class="config-search__clear"
              @click=${()=>e.onSearchChange("")}
            >×</button>
          `:h}
        </div>

        <!-- Section nav -->
        <nav class="config-nav">
          <button
            class="config-nav__item ${e.activeSection===null?"active":""}"
            @click=${()=>e.onSectionChange(null)}
          >
            <span class="config-nav__icon">${Ss.all}</span>
            <span class="config-nav__label">所有设置</span>
          </button>
          ${c.map(k=>l`
            <button
              class="config-nav__item ${e.activeSection===k.key?"active":""}"
              @click=${()=>e.onSectionChange(k.key)}
            >
              <span class="config-nav__icon">${Br(k.key)}</span>
              <span class="config-nav__label">${k.label}</span>
            </button>
          `)}
        </nav>

        <!-- Mode toggle at bottom -->
        <div class="config-sidebar__footer">
          <div class="config-mode-toggle">
            <button
              class="config-mode-toggle__btn ${e.formMode==="form"?"active":""}"
              ?disabled=${e.schemaLoading||!e.schema}
              @click=${()=>e.onFormModeChange("form")}
            >
              表单
            </button>
            <button
              class="config-mode-toggle__btn ${e.formMode==="raw"?"active":""}"
              @click=${()=>e.onFormModeChange("raw")}
            >
              原文 (JSON5)
            </button>
          </div>
        </div>
      </aside>

      <!-- Main content -->
      <main class="config-main">
        <!-- Action bar -->
        <div class="config-actions">
          <div class="config-actions__left">
            ${E?l`
              <span class="config-changes-badge">${e.formMode==="raw"?"未保存的更改":`有 ${w.length} 项更改未保存`}</span>
            `:l`
              <span class="config-status muted">无更改</span>
            `}
          </div>
          <div class="config-actions__right">
            <button class="btn btn--sm" ?disabled=${e.loading} @click=${e.onReload}>
              ${e.loading?"正在加载...":"重新加载"}
            </button>
            <button
              class="btn btn--sm primary"
              ?disabled=${!O}
              @click=${e.onSave}
            >
              ${e.saving?"正在保存...":"保存"}
            </button>
            <button
              class="btn btn--sm"
              ?disabled=${!I}
              @click=${e.onApply}
            >
              ${e.applying?"正在应用...":"应用"}
            </button>
            <button
              class="btn btn--sm"
              ?disabled=${!L}
              @click=${e.onUpdate}
            >
              ${e.updating?"正在更新...":"更新"}
            </button>
          </div>
        </div>

        <!-- Diff panel (form mode only - raw mode doesn't have granular diff) -->
        ${E&&e.formMode==="form"?l`
          <details class="config-diff">
            <summary class="config-diff__summary">
              <span>查看 ${w.length} 项待处理的更改</span>
              <svg class="config-diff__chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="6 9 12 15 18 9"></polyline>
              </svg>
            </summary>
            <div class="config-diff__content">
              ${w.map(k=>l`
                <div class="config-diff__item">
                  <div class="config-diff__path">${k.path}</div>
                  <div class="config-diff__values">
                    <span class="config-diff__from">${Fr(k.from)}</span>
                    <span class="config-diff__arrow">→</span>
                    <span class="config-diff__to">${Fr(k.to)}</span>
                  </div>
                </div>
              `)}
            </div>
          </details>
        `:h}

        ${d&&e.formMode==="form"?l`
              <div class="config-section-hero">
                <div class="config-section-hero__icon">${Br(e.activeSection??"")}</div>
                <div class="config-section-hero__text">
                  <div class="config-section-hero__title">${d.label}</div>
                  ${d.description?l`<div class="config-section-hero__desc">${d.description}</div>`:h}
                </div>
              </div>
            `:h}

        ${v?l`
              <div class="config-subnav">
                <button
                  class="config-subnav__item ${y===null?"active":""}"
                  @click=${()=>e.onSubsectionChange(Dr)}
                >
                  全部
                </button>
                ${u.map(k=>l`
                    <button
                      class="config-subnav__item ${y===k.key?"active":""}"
                      title=${k.description||k.label}
                      @click=${()=>e.onSubsectionChange(k.key)}
                    >
                      ${k.label}
                    </button>
                  `)}
              </div>
            `:h}

        <!-- Form content -->
        <div class="config-content">
          ${e.formMode==="form"?l`
                ${e.schemaLoading?l`<div class="config-loading">
                      <div class="config-loading__spinner"></div>
                      <span>正在加载架构 (Schema)...</span>
                    </div>`:Hp({schema:n.schema,uiHints:e.uiHints,value:e.formValue,disabled:e.loading||!e.formValue,unsupportedPaths:n.unsupportedPaths,onPatch:e.onFormPatch,onDiscoverModels:e.onDiscoverModels,searchQuery:e.searchQuery,activeSection:e.activeSection,activeSubsection:y})}
                ${s?l`<div class="callout danger" style="margin-top: 12px;">
                      表单视图无法安全编辑某些字段。
                      请使用“原文”模式以避免丢失配置项。
                    </div>`:h}
              `:l`
                <label class="field config-raw-field">
                  <span>JSON5 源码</span>
                  <textarea
                    .value=${e.raw}
                    @input=${k=>e.onRawChange(k.target.value)}
                  ></textarea>
                </label>
              `}
        </div>

        ${e.issues.length>0?l`<div class="callout danger" style="margin-top: 12px;">
              <pre class="code-block">${JSON.stringify(e.issues,null,2)}</pre>
            </div>`:h}
      </main>
    </div>
  `}function Zp(e){if(!e&&e!==0)return"无";const t=Math.round(e/1e3);if(t<60)return`${t}s`;const n=Math.round(t/60);return n<60?`${n}m`:`${Math.round(n/60)}h`}function Yp(e,t){const n=t.snapshot,s=n?.channels;if(!n||!s)return!1;const i=s[e],r=typeof i?.configured=="boolean"&&i.configured,a=typeof i?.running=="boolean"&&i.running,o=typeof i?.connected=="boolean"&&i.connected,p=(n.channelAccounts?.[e]??[]).some(d=>d.configured||d.running||d.connected);return r||a||o||p}function Xp(e,t){return t?.[e]?.length??0}function ho(e,t){const n=Xp(e,t);return n<2?h:l`<div class="account-count">账号 (${n})</div>`}function Jp(e,t){let n=e;for(const s of t){if(!n)return null;const i=fe(n);if(i==="object"){const r=n.properties??{};if(typeof s=="string"&&r[s]){n=r[s];continue}const a=n.additionalProperties;if(typeof s=="string"&&a&&typeof a=="object"){n=a;continue}return null}if(i==="array"){if(typeof s!="number")return null;n=(Array.isArray(n.items)?n.items[0]:n.items)??null;continue}return null}return n}function ef(e,t){const s=(e.channels??{})[t],i=e[t];return(s&&typeof s=="object"?s:null)??(i&&typeof i=="object"?i:null)??{}}function tf(e){const t=fo(e.schema),n=t.schema;if(!n)return l`<div class="callout danger">架构不可用。请使用原始数据。</div>`;const s=Jp(n,["channels",e.channelId]);if(!s)return l`<div class="callout danger">渠道配置架构不可用。</div>`;const i=e.configValue??{},r=ef(i,e.channelId);return l`
    <div class="config-form">
      ${$e({schema:s,value:r,path:["channels",e.channelId],hints:e.uiHints,unsupported:new Set(t.unsupportedPaths),disabled:e.disabled,showLabel:!1,onPatch:e.onPatch})}
    </div>
  `}function xe(e){const{channelId:t,props:n}=e,s=n.configSaving||n.configSchemaLoading;return l`
    <div style="margin-top: 16px;">
      ${n.configSchemaLoading?l`<div class="muted">正在加载配置架构...</div>`:tf({channelId:t,configValue:n.configForm,schema:n.configSchema,uiHints:n.configUiHints,disabled:s,onPatch:n.onConfigPatch})}
      <div class="row" style="margin-top: 12px;">
        <button
          class="btn primary"
          ?disabled=${s||!n.configFormDirty}
          @click=${()=>n.onConfigSave()}
        >
          ${n.configSaving?"正在保存...":"保存"}
        </button>
        <button
          class="btn"
          ?disabled=${s}
          @click=${()=>n.onConfigReload()}
        >
          重载
        </button>
      </div>
    </div>
  `}function nf(e){const{props:t,discord:n,accountCountLabel:s}=e;return l`
    <div class="card">
      <div class="card-title">Discord</div>
      <div class="card-sub">机器人状态与渠道配置。</div>
      ${s}

      <div class="status-list" style="margin-top: 16px;">
        <div>
          <span class="label">已配置</span>
          <span>${n?.configured?"是":"否"}</span>
        </div>
        <div>
          <span class="label">运行中</span>
          <span>${n?.running?"是":"否"}</span>
        </div>
        <div>
          <span class="label">上次启动</span>
          <span>${n?.lastStartAt?D(n.lastStartAt):"无"}</span>
        </div>
        <div>
          <span class="label">上次探测</span>
          <span>${n?.lastProbeAt?D(n.lastProbeAt):"无"}</span>
        </div>
      </div>

      ${n?.lastError?l`<div class="callout danger" style="margin-top: 12px;">
            ${n.lastError}
          </div>`:h}

      ${n?.probe?l`<div class="callout" style="margin-top: 12px;">
            探测 ${n.probe.ok?"成功":"失败"} ·
            ${n.probe.status??""} ${n.probe.error??""}
          </div>`:h}

      ${xe({channelId:"discord",props:t})}

      <div class="row" style="margin-top: 12px;">
        <button class="btn" @click=${()=>t.onRefresh(!0)}>
          刷新探测
        </button>
      </div>
    </div>
  `}function sf(e){const{props:t,googleChat:n,accountCountLabel:s}=e;return l`
    <div class="card">
      <div class="card-title">Google Chat</div>
      <div class="card-sub">Chat API Webhook 状态与渠道配置。</div>
      ${s}

      <div class="status-list" style="margin-top: 16px;">
        <div>
          <span class="label">已配置</span>
          <span>${n?n.configured?"是":"否":"无"}</span>
        </div>
        <div>
          <span class="label">运行中</span>
          <span>${n?n.running?"是":"否":"无"}</span>
        </div>
        <div>
          <span class="label">凭据</span>
          <span>${n?.credentialSource??"无"}</span>
        </div>
        <div>
          <span class="label">受众 (Audience)</span>
          <span>
            ${n?.audienceType?`${n.audienceType}${n.audience?` · ${n.audience}`:""}`:"无"}
          </span>
        </div>
        <div>
          <span class="label">上次启动</span>
          <span>${n?.lastStartAt?D(n.lastStartAt):"无"}</span>
        </div>
        <div>
          <span class="label">上次探测</span>
          <span>${n?.lastProbeAt?D(n.lastProbeAt):"无"}</span>
        </div>
      </div>

      ${n?.lastError?l`<div class="callout danger" style="margin-top: 12px;">
            ${n.lastError}
          </div>`:h}

      ${n?.probe?l`<div class="callout" style="margin-top: 12px;">
            探测 ${n.probe.ok?"成功":"失败"} ·
            ${n.probe.status??""} ${n.probe.error??""}
          </div>`:h}

      ${xe({channelId:"googlechat",props:t})}

      <div class="row" style="margin-top: 12px;">
        <button class="btn" @click=${()=>t.onRefresh(!0)}>
          刷新探测
        </button>
      </div>
    </div>
  `}function rf(e){const{props:t,imessage:n,accountCountLabel:s}=e;return l`
    <div class="card">
      <div class="card-title">iMessage</div>
      <div class="card-sub">macOS 桥接状态与渠道配置。</div>
      ${s}

      <div class="status-list" style="margin-top: 16px;">
        <div>
          <span class="label">已配置</span>
          <span>${n?.configured?"是":"否"}</span>
        </div>
        <div>
          <span class="label">运行中</span>
          <span>${n?.running?"是":"否"}</span>
        </div>
        <div>
          <span class="label">上次启动</span>
          <span>${n?.lastStartAt?D(n.lastStartAt):"无"}</span>
        </div>
        <div>
          <span class="label">上次探测</span>
          <span>${n?.lastProbeAt?D(n.lastProbeAt):"无"}</span>
        </div>
      </div>

      ${n?.lastError?l`<div class="callout danger" style="margin-top: 12px;">
            ${n.lastError}
          </div>`:h}

      ${n?.probe?l`<div class="callout" style="margin-top: 12px;">
            探测 ${n.probe.ok?"成功":"失败"} ·
            ${n.probe.error??""}
          </div>`:h}

      ${xe({channelId:"imessage",props:t})}

      <div class="row" style="margin-top: 12px;">
        <button class="btn" @click=${()=>t.onRefresh(!0)}>
          刷新探测
        </button>
      </div>
    </div>
  `}function af(e){const{values:t,original:n}=e;return t.name!==n.name||t.displayName!==n.displayName||t.about!==n.about||t.picture!==n.picture||t.banner!==n.banner||t.website!==n.website||t.nip05!==n.nip05||t.lud16!==n.lud16}function of(e){const{state:t,callbacks:n,accountId:s}=e,i=af(t),r=(o,c,p={})=>{const{type:d="text",placeholder:u,maxLength:v,help:g}=p,y=t.values[o]??"",w=t.fieldErrors[o],A=`nostr-profile-${o}`;return d==="textarea"?l`
        <div class="form-field" style="margin-bottom: 12px;">
          <label for="${A}" style="display: block; margin-bottom: 4px; font-weight: 500;">
            ${c}
          </label>
          <textarea
            id="${A}"
            .value=${y}
            placeholder=${u??""}
            maxlength=${v??2e3}
            rows="3"
            style="width: 100%; padding: 8px; border: 1px solid var(--border-color); border-radius: 4px; resize: vertical; font-family: inherit;"
            @input=${E=>{const C=E.target;n.onFieldChange(o,C.value)}}
            ?disabled=${t.saving}
          ></textarea>
          ${g?l`<div style="font-size: 12px; color: var(--text-muted); margin-top: 2px;">${g}</div>`:h}
          ${w?l`<div style="font-size: 12px; color: var(--danger-color); margin-top: 2px;">${w}</div>`:h}
        </div>
      `:l`
      <div class="form-field" style="margin-bottom: 12px;">
        <label for="${A}" style="display: block; margin-bottom: 4px; font-weight: 500;">
          ${c}
        </label>
        <input
          id="${A}"
          type=${d}
          .value=${y}
          placeholder=${u??""}
          maxlength=${v??256}
          style="width: 100%; padding: 8px; border: 1px solid var(--border-color); border-radius: 4px;"
          @input=${E=>{const C=E.target;n.onFieldChange(o,C.value)}}
          ?disabled=${t.saving}
        />
        ${g?l`<div style="font-size: 12px; color: var(--text-muted); margin-top: 2px;">${g}</div>`:h}
        ${w?l`<div style="font-size: 12px; color: var(--danger-color); margin-top: 2px;">${w}</div>`:h}
      </div>
    `},a=()=>{const o=t.values.picture;return o?l`
      <div style="margin-bottom: 12px;">
        <img
          src=${o}
          alt="头像预览"
          style="max-width: 80px; max-height: 80px; border-radius: 50%; object-fit: cover; border: 2px solid var(--border-color);"
          @error=${c=>{const p=c.target;p.style.display="none"}}
          @load=${c=>{const p=c.target;p.style.display="block"}}
        />
      </div>
    `:h};return l`
    <div class="nostr-profile-form" style="padding: 16px; background: var(--bg-secondary); border-radius: 8px; margin-top: 12px;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
        <div style="font-weight: 600; font-size: 16px;">编辑资料</div>
        <div style="font-size: 12px; color: var(--text-muted);">账户: ${s}</div>
      </div>

      ${t.error?l`<div class="callout danger" style="margin-bottom: 12px;">${t.error}</div>`:h}

      ${t.success?l`<div class="callout success" style="margin-bottom: 12px;">${t.success}</div>`:h}

      ${a()}

      ${r("name","用户名",{placeholder:"satoshi",maxLength:256,help:"短用户名（例如：satoshi）"})}

      ${r("displayName","显示名称",{placeholder:"Satoshi Nakamoto",maxLength:256,help:"您的完整显示名称"})}

      ${r("about","简介",{type:"textarea",placeholder:"向大家介绍一下您自己...",maxLength:2e3,help:"简短的个人履历或描述"})}

      ${r("picture","头像 URL",{type:"url",placeholder:"https://example.com/avatar.jpg",help:"个人头像的 HTTPS 链接"})}

      ${t.showAdvanced?l`
            <div style="border-top: 1px solid var(--border-color); padding-top: 12px; margin-top: 12px;">
              <div style="font-weight: 500; margin-bottom: 12px; color: var(--text-muted);">高级设置</div>

              ${r("banner","横幅 URL",{type:"url",placeholder:"https://example.com/banner.jpg",help:"横幅图片的 HTTPS 链接"})}

              ${r("website","网站",{type:"url",placeholder:"https://example.com",help:"您的个人网站"})}

              ${r("nip05","NIP-05 标识符",{placeholder:"you@example.com",help:"可验证的标识符（例如：you@domain.com）"})}

              ${r("lud16","闪电网络地址",{placeholder:"you@getalby.com",help:"用于接收打赏的闪电网络地址（LUD-16）"})}
            </div>
          `:h}

      <div style="display: flex; gap: 8px; margin-top: 16px; flex-wrap: wrap;">
        <button
          class="btn primary"
          @click=${n.onSave}
          ?disabled=${t.saving||!i}
        >
          ${t.saving?"正在保存...":"保存并发布"}
        </button>

        <button
          class="btn"
          @click=${n.onImport}
          ?disabled=${t.importing||t.saving}
        >
          ${t.importing?"正在导入...":"从中继导入"}
        </button>

        <button
          class="btn"
          @click=${n.onToggleAdvanced}
        >
          ${t.showAdvanced?"隐藏高级设置":"显示高级设置"}
        </button>

        <button
          class="btn"
          @click=${n.onCancel}
          ?disabled=${t.saving}
        >
          取消
        </button>
      </div>

      ${i?l`<div style="font-size: 12px; color: var(--warning-color); margin-top: 8px;">
            您有未保存的更改
          </div>`:h}
    </div>
  `}function lf(e){const t={name:e?.name??"",displayName:e?.displayName??"",about:e?.about??"",picture:e?.picture??"",banner:e?.banner??"",website:e?.website??"",nip05:e?.nip05??"",lud16:e?.lud16??""};return{values:t,original:{...t},saving:!1,importing:!1,error:null,success:null,fieldErrors:{},showAdvanced:!!(e?.banner||e?.website||e?.nip05||e?.lud16)}}function Ur(e){return e?e.length<=20?e:`${e.slice(0,8)}...${e.slice(-8)}`:"无"}function cf(e){const{props:t,nostr:n,nostrAccounts:s,accountCountLabel:i,profileFormState:r,profileFormCallbacks:a,onEditProfile:o}=e,c=s[0],p=n?.configured??c?.configured??!1,d=n?.running??c?.running??!1,u=n?.publicKey??c?.publicKey,v=n?.lastStartAt??c?.lastStartAt??null,g=n?.lastError??c?.lastError??null,y=s.length>1,w=r!=null,A=C=>{const O=C.publicKey,I=C.profile,L=I?.displayName??I?.name??C.name??C.accountId;return l`
      <div class="account-card">
        <div class="account-card-header">
          <div class="account-card-title">${L}</div>
          <div class="account-card-id">${C.accountId}</div>
        </div>
        <div class="status-list account-card-status">
          <div>
            <span class="label">运行中</span>
            <span>${C.running?"是":"否"}</span>
          </div>
          <div>
            <span class="label">已配置</span>
            <span>${C.configured?"是":"否"}</span>
          </div>
          <div>
            <span class="label">公钥</span>
            <span class="monospace" title="${O??""}">${Ur(O)}</span>
          </div>
          <div>
            <span class="label">上次呼入</span>
            <span>${C.lastInboundAt?D(C.lastInboundAt):"无"}</span>
          </div>
          ${C.lastError?l`
                <div class="account-card-error">${C.lastError}</div>
              `:h}
        </div>
      </div>
    `},E=()=>{if(w&&a)return of({state:r,callbacks:a,accountId:s[0]?.accountId??"default"});const C=c?.profile??n?.profile,{name:O,displayName:I,about:L,picture:k,nip05:N}=C??{},te=O||I||L||k||N;return l`
      <div style="margin-top: 16px; padding: 12px; background: var(--bg-secondary); border-radius: 8px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
          <div style="font-weight: 500;">个人资料</div>
          ${p?l`
                <button
                  class="btn btn-sm"
                  @click=${o}
                  style="font-size: 12px; padding: 4px 8px;"
                >
                  编辑资料
                </button>
              `:h}
        </div>
        ${te?l`
              <div class="status-list">
                ${k?l`
                      <div style="margin-bottom: 8px;">
                        <img
                          src=${k}
                          alt="头像"
                          style="width: 48px; height: 48px; border-radius: 50%; object-fit: cover; border: 2px solid var(--border-color);"
                          @error=${ze=>{ze.target.style.display="none"}}
                        />
                      </div>
                    `:h}
                ${O?l`<div><span class="label">用户名</span><span>${O}</span></div>`:h}
                ${I?l`<div><span class="label">显示名称</span><span>${I}</span></div>`:h}
                ${L?l`<div><span class="label">关于</span><span style="max-width: 300px; overflow: hidden; text-overflow: ellipsis;">${L}</span></div>`:h}
                ${N?l`<div><span class="label">NIP-05</span><span>${N}</span></div>`:h}
              </div>
            `:l`
              <div style="color: var(--text-muted); font-size: 13px;">
                尚未设置个人资料。点击“编辑资料”添加您的姓名、简介和头像。
              </div>
            `}
      </div>
    `};return l`
    <div class="card">
      <div class="card-title">Nostr</div>
      <div class="card-sub">基于 Nostr 中继的去中心化私信 (NIP-04)。</div>
      ${i}

      ${y?l`
            <div class="account-card-list">
              ${s.map(C=>A(C))}
            </div>
          `:l`
            <div class="status-list" style="margin-top: 16px;">
              <div>
                <span class="label">已配置</span>
                <span>${p?"是":"否"}</span>
              </div>
              <div>
                <span class="label">运行中</span>
                <span>${d?"是":"否"}</span>
              </div>
              <div>
                <span class="label">公钥</span>
                <span class="monospace" title="${u??""}"
                  >${Ur(u)}</span
                >
              </div>
              <div>
                <span class="label">上次启动</span>
                <span>${v?D(v):"无"}</span>
              </div>
            </div>
          `}

      ${g?l`<div class="callout danger" style="margin-top: 12px;">${g}</div>`:h}

      ${E()}

      ${xe({channelId:"nostr",props:t})}

      <div class="row" style="margin-top: 12px;">
        <button class="btn" @click=${()=>t.onRefresh(!1)}>刷新</button>
      </div>
    </div>
  `}function df(e){const{props:t,signal:n,accountCountLabel:s}=e;return l`
    <div class="card">
      <div class="card-title">Signal</div>
      <div class="card-sub">signal-cli 状态与渠道配置。</div>
      ${s}

      <div class="status-list" style="margin-top: 16px;">
        <div>
          <span class="label">已配置</span>
          <span>${n?.configured?"是":"否"}</span>
        </div>
        <div>
          <span class="label">运行中</span>
          <span>${n?.running?"是":"否"}</span>
        </div>
        <div>
          <span class="label">基础 URL</span>
          <span>${n?.baseUrl??"无"}</span>
        </div>
        <div>
          <span class="label">上次启动</span>
          <span>${n?.lastStartAt?D(n.lastStartAt):"无"}</span>
        </div>
        <div>
          <span class="label">上次探测</span>
          <span>${n?.lastProbeAt?D(n.lastProbeAt):"无"}</span>
        </div>
      </div>

      ${n?.lastError?l`<div class="callout danger" style="margin-top: 12px;">
            ${n.lastError}
          </div>`:h}

      ${n?.probe?l`<div class="callout" style="margin-top: 12px;">
            探测 ${n.probe.ok?"成功":"失败"} ·
            ${n.probe.status??""} ${n.probe.error??""}
          </div>`:h}

      ${xe({channelId:"signal",props:t})}

      <div class="row" style="margin-top: 12px;">
        <button class="btn" @click=${()=>t.onRefresh(!0)}>
          刷新探测
        </button>
      </div>
    </div>
  `}function uf(e){const{props:t,slack:n,accountCountLabel:s}=e;return l`
    <div class="card">
      <div class="card-title">Slack</div>
      <div class="card-sub">Socket 模式状态与渠道配置。</div>
      ${s}

      <div class="status-list" style="margin-top: 16px;">
        <div>
          <span class="label">已配置</span>
          <span>${n?.configured?"是":"否"}</span>
        </div>
        <div>
          <span class="label">运行中</span>
          <span>${n?.running?"是":"否"}</span>
        </div>
        <div>
          <span class="label">上次启动</span>
          <span>${n?.lastStartAt?D(n.lastStartAt):"无"}</span>
        </div>
        <div>
          <span class="label">上次探测</span>
          <span>${n?.lastProbeAt?D(n.lastProbeAt):"无"}</span>
        </div>
      </div>

      ${n?.lastError?l`<div class="callout danger" style="margin-top: 12px;">
            ${n.lastError}
          </div>`:h}

      ${n?.probe?l`<div class="callout" style="margin-top: 12px;">
            探测 ${n.probe.ok?"成功":"失败"} ·
            ${n.probe.status??""} ${n.probe.error??""}
          </div>`:h}

      ${xe({channelId:"slack",props:t})}

      <div class="row" style="margin-top: 12px;">
        <button class="btn" @click=${()=>t.onRefresh(!0)}>
          刷新探测
        </button>
      </div>
    </div>
  `}function pf(e){const{props:t,telegram:n,telegramAccounts:s,accountCountLabel:i}=e,r=s.length>1,a=o=>{const p=o.probe?.bot?.username,d=o.name||o.accountId;return l`
      <div class="account-card">
        <div class="account-card-header">
          <div class="account-card-title">
            ${p?`@${p}`:d}
          </div>
          <div class="account-card-id">${o.accountId}</div>
        </div>
        <div class="status-list account-card-status">
          <div>
            <span class="label">运行中</span>
            <span>${o.running?"是":"否"}</span>
          </div>
          <div>
            <span class="label">已配置</span>
            <span>${o.configured?"是":"否"}</span>
          </div>
          <div>
            <span class="label">上次读入</span>
            <span>${o.lastInboundAt?D(o.lastInboundAt):"无"}</span>
          </div>
          ${o.lastError?l`
                <div class="account-card-error">
                  ${o.lastError}
                </div>
              `:h}
        </div>
      </div>
    `};return l`
    <div class="card">
      <div class="card-title">Telegram</div>
      <div class="card-sub">机器人状态与渠道配置。</div>
      ${i}

      ${r?l`
            <div class="account-card-list">
              ${s.map(o=>a(o))}
            </div>
          `:l`
            <div class="status-list" style="margin-top: 16px;">
              <div>
                <span class="label">已配置</span>
                <span>${n?.configured?"是":"否"}</span>
              </div>
              <div>
                <span class="label">运行中</span>
                <span>${n?.running?"是":"否"}</span>
              </div>
              <div>
                <span class="label">模式</span>
                <span>${n?.mode??"未知"}</span>
              </div>
              <div>
                <span class="label">上次启动</span>
                <span>${n?.lastStartAt?D(n.lastStartAt):"无"}</span>
              </div>
              <div>
                <span class="label">上次探测</span>
                <span>${n?.lastProbeAt?D(n.lastProbeAt):"无"}</span>
              </div>
            </div>
          `}

      ${n?.lastError?l`<div class="callout danger" style="margin-top: 12px;">
            ${n.lastError}
          </div>`:h}

      ${n?.probe?l`<div class="callout" style="margin-top: 12px;">
            探测 ${n.probe.ok?"成功":"失败"} ·
            ${n.probe.status??""} ${n.probe.error??""}
          </div>`:h}

      ${xe({channelId:"telegram",props:t})}

      <div class="row" style="margin-top: 12px;">
        <button class="btn" @click=${()=>t.onRefresh(!0)}>
          刷新探测
        </button>
      </div>
    </div>
  `}function ff(e){const{props:t,whatsapp:n,accountCountLabel:s}=e;return l`
    <div class="card">
      <div class="card-title">WhatsApp</div>
      <div class="card-sub">绑定 WhatsApp Web 并监控连接健康状况。</div>
      ${s}

      <div class="status-list" style="margin-top: 16px;">
        <div>
          <span class="label">已配置</span>
          <span>${n?.configured?"是":"否"}</span>
        </div>
        <div>
          <span class="label">已绑定</span>
          <span>${n?.linked?"是":"否"}</span>
        </div>
        <div>
          <span class="label">运行中</span>
          <span>${n?.running?"是":"否"}</span>
        </div>
        <div>
          <span class="label">在线</span>
          <span>${n?.connected?"是":"否"}</span>
        </div>
        <div>
          <span class="label">上次连接</span>
          <span>
            ${n?.lastConnectedAt?D(n.lastConnectedAt):"无"}
          </span>
        </div>
        <div>
          <span class="label">上次消息</span>
          <span>
            ${n?.lastMessageAt?D(n.lastMessageAt):"无"}
          </span>
        </div>
        <div>
          <span class="label">授权时长</span>
          <span>
            ${n?.authAgeMs!=null?Zp(n.authAgeMs):"无"}
          </span>
        </div>
      </div>

      ${n?.lastError?l`<div class="callout danger" style="margin-top: 12px;">
            ${n.lastError}
          </div>`:h}

      ${t.whatsappMessage?l`<div class="callout" style="margin-top: 12px;">
            ${t.whatsappMessage}
          </div>`:h}

      ${t.whatsappQrDataUrl?l`<div class="qr-wrap">
            <img src=${t.whatsappQrDataUrl} alt="WhatsApp QR" />
          </div>`:h}

      <div class="row" style="margin-top: 14px; flex-wrap: wrap;">
        <button
          class="btn primary"
          ?disabled=${t.whatsappBusy}
          @click=${()=>t.onWhatsAppStart(!1)}
        >
          ${t.whatsappBusy?"请稍候…":"显示二维码"}
        </button>
        <button
          class="btn"
          ?disabled=${t.whatsappBusy}
          @click=${()=>t.onWhatsAppStart(!0)}
        >
          重新绑定
        </button>
        <button
          class="btn"
          ?disabled=${t.whatsappBusy}
          @click=${()=>t.onWhatsAppWait()}
        >
          等待扫描
        </button>
        <button
          class="btn danger"
          ?disabled=${t.whatsappBusy}
          @click=${()=>t.onWhatsAppLogout()}
        >
          直接注销
        </button>
        <button class="btn" @click=${()=>t.onRefresh(!0)}>
          刷新
        </button>
      </div>

      ${xe({channelId:"whatsapp",props:t})}
    </div>
  `}function hf(e){const t=e.snapshot?.channels,n=t?.whatsapp??void 0,s=t?.telegram??void 0,i=t?.discord??null;t?.googlechat;const r=t?.slack??null,a=t?.signal??null,o=t?.imessage??null;t?.feishu,t?.wecom;const c=t?.nostr??null,d=gf(e.snapshot).map((u,v)=>({key:u,enabled:Yp(u,e),order:v})).sort((u,v)=>u.enabled!==v.enabled?u.enabled?-1:1:u.order-v.order);return l`
    <section class="grid grid-cols-2">
      ${d.map(u=>vf(u.key,e,{whatsapp:n,telegram:s,discord:i,slack:r,signal:a,imessage:o,nostr:c,channelAccounts:e.snapshot?.channelAccounts??null}))}
    </section>

    <section class="card" style="margin-top: 18px;">
      <div class="row" style="justify-content: space-between;">
        <div>
          <div class="card-title">渠道运行状况</div>
          <div class="card-sub">来自网关的渠道状态快照。</div>
        </div>
        <div class="muted">${e.lastSuccessAt?D(e.lastSuccessAt):"无"}</div>
      </div>
      ${e.lastError?l`<div class="callout danger" style="margin-top: 12px;">
            ${e.lastError}
          </div>`:h}
      <pre class="code-block" style="margin-top: 12px;">
${e.snapshot?JSON.stringify(e.snapshot,null,2):"暂无快照。"}
      </pre>
    </section>
  `}function gf(e){return e?.channelMeta?.length?e.channelMeta.map(t=>t.id):e?.channelOrder?.length?e.channelOrder:["whatsapp","telegram","discord","googlechat","slack","signal","imessage","feishu","wecom","nostr"]}function vf(e,t,n){const s=ho(e,n.channelAccounts);switch(e){case"whatsapp":return ff({props:t,whatsapp:n.whatsapp,accountCountLabel:s});case"telegram":return pf({props:t,telegram:n.telegram,telegramAccounts:n.channelAccounts?.telegram??[],accountCountLabel:s});case"discord":return nf({props:t,discord:n.discord,accountCountLabel:s});case"googlechat":return sf({props:t,accountCountLabel:s});case"slack":return uf({props:t,slack:n.slack,accountCountLabel:s});case"signal":return df({props:t,signal:n.signal,accountCountLabel:s});case"imessage":return rf({props:t,imessage:n.imessage,accountCountLabel:s});case"nostr":{const i=n.channelAccounts?.nostr??[],r=i[0],a=r?.accountId??"default",o=r?.profile??null,c=t.nostrProfileAccountId===a?t.nostrProfileFormState:null,p=c?{onFieldChange:t.onNostrProfileFieldChange,onSave:t.onNostrProfileSave,onImport:t.onNostrProfileImport,onCancel:t.onNostrProfileCancel,onToggleAdvanced:t.onNostrProfileToggleAdvanced}:null;return cf({props:t,nostr:n.nostr,nostrAccounts:i,accountCountLabel:s,profileFormState:c,profileFormCallbacks:p,onEditProfile:()=>t.onNostrProfileEdit(a,o)})}default:return mf(e,t,n.channelAccounts??{})}}function mf(e,t,n){const s=bf(t.snapshot,e),i=t.snapshot?.channels?.[e],r=typeof i?.configured=="boolean"?i.configured:void 0,a=typeof i?.running=="boolean"?i.running:void 0,o=typeof i?.connected=="boolean"?i.connected:void 0,c=typeof i?.lastError=="string"?i.lastError:void 0,p=n[e]??[],d=ho(e,n);return l`
    <div class="card">
      <div class="card-title">${s}</div>
      <div class="card-sub">渠道状态与配置。</div>
      ${d}

      ${p.length>0?l`
            <div class="account-card-list">
              ${p.map(u=>Af(u))}
            </div>
          `:l`
            <div class="status-list" style="margin-top: 16px;">
              <div>
                <span class="label">已配置</span>
                <span>${r==null?"无":r?"是":"否"}</span>
              </div>
              <div>
                <span class="label">运行中</span>
                <span>${a==null?"无":a?"是":"否"}</span>
              </div>
              <div>
                <span class="label">已连接</span>
                <span>${o==null?"无":o?"是":"否"}</span>
              </div>
            </div>
          `}

      ${c?l`<div class="callout danger" style="margin-top: 12px;">
            ${c}
          </div>`:h}

      ${xe({channelId:e,props:t})}
    </div>
  `}function yf(e){return e?.channelMeta?.length?Object.fromEntries(e.channelMeta.map(t=>[t.id,t])):{}}function bf(e,t){return yf(e)[t]?.label??e?.channelLabels?.[t]??t}const $f=600*1e3;function go(e){return e.lastInboundAt?Date.now()-e.lastInboundAt<$f:!1}function wf(e){return e.running?"是":go(e)?"活跃":"否"}function xf(e){return e.connected===!0?"是":e.connected===!1?"否":go(e)?"活跃":"无"}function Af(e){const t=wf(e),n=xf(e);return l`
    <div class="account-card">
      <div class="account-card-header">
        <div class="account-card-title">${e.name||e.accountId}</div>
        <div class="account-card-id">${e.accountId}</div>
      </div>
      <div class="status-list account-card-status">
        <div>
          <span class="label">运行中 (Running)</span>
          <span>${t}</span>
        </div>
        <div>
          <span class="label">已配置 (Configured)</span>
          <span>${e.configured?"是":"否"}</span>
        </div>
        <div>
          <span class="label">已连接 (Connected)</span>
          <span>${n}</span>
        </div>
        <div>
          <span class="label">上次读入 (Last inbound)</span>
          <span>${e.lastInboundAt?D(e.lastInboundAt):"无"}</span>
        </div>
        ${e.lastError?l`
              <div class="account-card-error">
                ${e.lastError}
              </div>
            `:h}
      </div>
    </div>
  `}function kf(e){const t=e.host??"未知",n=e.ip?`(${e.ip})`:"",s=e.mode??"",i=e.version??"";return`${t} ${n} ${s} ${i}`.trim()}function Sf(e){const t=e.ts??null;return t?D(t):"无"}function vo(e){return e?`${Et(e)} (${D(e)})`:"无"}function _f(e){if(e.totalTokens==null)return"无";const t=e.totalTokens??0,n=e.contextTokens??0;return n?`${t} / ${n}`:String(t)}function Tf(e){if(e==null)return"";try{return JSON.stringify(e,null,2)}catch{return String(e)}}function Ef(e){const t=e.state??{},n=t.nextRunAtMs?Et(t.nextRunAtMs):"无",s=t.lastRunAtMs?Et(t.lastRunAtMs):"无";return`${t.lastStatus??"无"} · 下次 ${n} · 上次 ${s}`}function Cf(e){const t=e.schedule;return t.kind==="at"?`定期 ${Et(t.atMs)}`:t.kind==="every"?`每隔 ${ra(t.everyMs)}`:`定时 ${t.expr}${t.tz?` (${t.tz})`:""}`}function Mf(e){const t=e.payload;return t.kind==="systemEvent"?`系统: ${t.text}`:`智能体: ${t.message}`}function If(e){const t=["last",...e.channels.filter(Boolean)],n=e.form.channel?.trim();n&&!t.includes(n)&&t.push(n);const s=new Set;return t.filter(i=>s.has(i)?!1:(s.add(i),!0))}function Lf(e,t){if(t==="last")return"last";const n=e.channelMeta?.find(s=>s.id===t);return n?.label?n.label:e.channelLabels?.[t]??t}function Rf(e){const t=If(e);return l`
    <section class="grid grid-cols-2">
      <div class="card">
        <div class="card-title">任务调度器 (Scheduler)</div>
        <div class="card-sub">管理网关自带的定时任务调度状态。</div>
        <div class="stat-grid" style="margin-top: 16px;">
          <div class="stat">
            <div class="stat-label">是否启用</div>
            <div class="stat-value">
              ${e.status?e.status.enabled?"是":"否":"无"}
            </div>
          </div>
          <div class="stat">
            <div class="stat-label">任务数</div>
            <div class="stat-value">${e.status?.jobs??"无"}</div>
          </div>
          <div class="stat">
            <div class="stat-label">下次唤醒</div>
            <div class="stat-value">${vo(e.status?.nextWakeAtMs??null)}</div>
          </div>
        </div>
        <div class="row" style="margin-top: 12px;">
          <button class="btn" ?disabled=${e.loading} @click=${e.onRefresh}>
            ${e.loading?"正在刷新…":"刷新"}
          </button>
          ${e.error?l`<span class="muted">${e.error}</span>`:h}
        </div>
      </div>

      <div class="card">
        <div class="card-title">新建任务</div>
        <div class="card-sub">创建一个定时的唤醒或智能体运行任务。</div>
        <div class="form-grid" style="margin-top: 16px;">
          <label class="field">
            <span>任务名称</span>
            <input
              .value=${e.form.name}
              @input=${n=>e.onFormChange({name:n.target.value})}
            />
          </label>
          <label class="field">
            <span>描述</span>
            <input
              .value=${e.form.description}
              @input=${n=>e.onFormChange({description:n.target.value})}
            />
          </label>
          <label class="field">
            <span>智能体 ID</span>
            <input
              .value=${e.form.agentId}
              @input=${n=>e.onFormChange({agentId:n.target.value})}
              placeholder="默认"
            />
          </label>
          <label class="field checkbox">
            <span>是否启用</span>
            <input
              type="checkbox"
              .checked=${e.form.enabled}
              @change=${n=>e.onFormChange({enabled:n.target.checked})}
            />
          </label>
          <label class="field">
            <span>排程方式</span>
            <select
              .value=${e.form.scheduleKind}
              @change=${n=>e.onFormChange({scheduleKind:n.target.value})}
            >
              <option value="every">每隔 (Every)</option>
              <option value="at">于 (At)</option>
              <option value="cron">定时 (Cron)</option>
            </select>
          </label>
        </div>
        ${Pf(e)}
        <div class="form-grid" style="margin-top: 12px;">
          <label class="field">
            <span>会话类型</span>
            <select
              .value=${e.form.sessionTarget}
              @change=${n=>e.onFormChange({sessionTarget:n.target.value})}
            >
              <option value="main">主会话 (Main)</option>
              <option value="isolated">隔离会话 (Isolated)</option>
            </select>
          </label>
          <label class="field">
            <span>唤醒模式</span>
            <select
              .value=${e.form.wakeMode}
              @change=${n=>e.onFormChange({wakeMode:n.target.value})}
            >
              <option value="next-heartbeat">下次心跳</option>
              <option value="now">立即唤醒</option>
            </select>
          </label>
          <label class="field">
            <span>载荷类型</span>
            <select
              .value=${e.form.payloadKind}
              @change=${n=>e.onFormChange({payloadKind:n.target.value})}
            >
              <option value="systemEvent">系统事件</option>
              <option value="agentTurn">智能体轮次</option>
            </select>
          </label>
        </div>
        <label class="field" style="margin-top: 12px;">
          <span>${e.form.payloadKind==="systemEvent"?"系统事件文本":"智能体消息文本"}</span>
          <textarea
            .value=${e.form.payloadText}
            @input=${n=>e.onFormChange({payloadText:n.target.value})}
            rows="4"
          ></textarea>
        </label>
	          ${e.form.payloadKind==="agentTurn"?l`
	              <div class="form-grid" style="margin-top: 12px;">
                <label class="field checkbox">
                  <span>投递</span>
                  <input
                    type="checkbox"
                    .checked=${e.form.deliver}
                    @change=${n=>e.onFormChange({deliver:n.target.checked})}
                  />
	                </label>
	                <label class="field">
	                  <span>渠道</span>
	                  <select
	                    .value=${e.form.channel||"last"}
	                    @change=${n=>e.onFormChange({channel:n.target.value})}
	                  >
	                    ${t.map(n=>l`<option value=${n}>
                            ${Lf(e,n)}
                          </option>`)}
                  </select>
                </label>
                <label class="field">
                  <span>接收者</span>
                  <input
                    .value=${e.form.to}
                    @input=${n=>e.onFormChange({to:n.target.value})}
                    placeholder="+1555… 或聊天 ID"
                  />
                </label>
                <label class="field">
                  <span>超时时间 (秒)</span>
                  <input
                    .value=${e.form.timeoutSeconds}
                    @input=${n=>e.onFormChange({timeoutSeconds:n.target.value})}
                  />
                </label>
                ${e.form.sessionTarget==="isolated"?l`
                      <label class="field">
                        <span>发布到主会话前缀</span>
                        <input
                          .value=${e.form.postToMainPrefix}
                          @input=${n=>e.onFormChange({postToMainPrefix:n.target.value})}
                        />
                      </label>
                    `:h}
              </div>
            `:h}
        <div class="row" style="margin-top: 14px;">
          <button class="btn primary" ?disabled=${e.busy} @click=${e.onAdd}>
            ${e.busy?"正在保存…":"添加任务"}
          </button>
        </div>
      </div>
    </section>

    <section class="card" style="margin-top: 18px;">
      <div class="card-title">任务列表</div>
      <div class="card-sub">存储在网关中的所有定时任务。</div>
      ${e.jobs.length===0?l`<div class="muted" style="margin-top: 12px;">暂无任务。</div>`:l`
            <div class="list" style="margin-top: 12px;">
              ${e.jobs.map(n=>Nf(n,e))}
            </div>
          `}
    </section>

    <section class="card" style="margin-top: 18px;">
      <div class="card-title">运行历史</div>
      <div class="card-sub">最近运行记录: ${e.runsJobId??"(请选择一个任务)"}。</div>
      ${e.runsJobId==null?l`
            <div class="muted" style="margin-top: 12px;">
              选择一个任务以查看运行历史。
            </div>
          `:e.runs.length===0?l`<div class="muted" style="margin-top: 12px;">暂无运行记录。</div>`:l`
              <div class="list" style="margin-top: 12px;">
                ${e.runs.map(n=>Of(n))}
              </div>
            `}
    </section>
  `}function Pf(e){const t=e.form;return t.scheduleKind==="at"?l`
      <label class="field" style="margin-top: 12px;">
        <span>运行于</span>
        <input
          type="datetime-local"
          .value=${t.scheduleAt}
          @input=${n=>e.onFormChange({scheduleAt:n.target.value})}
        />
      </label>
    `:t.scheduleKind==="every"?l`
      <div class="form-grid" style="margin-top: 12px;">
        <label class="field">
          <span>每隔</span>
          <input
            .value=${t.everyAmount}
            @input=${n=>e.onFormChange({everyAmount:n.target.value})}
          />
        </label>
        <label class="field">
          <span>单位</span>
          <select
            .value=${t.everyUnit}
            @change=${n=>e.onFormChange({everyUnit:n.target.value})}
          >
            <option value="minutes">分钟</option>
            <option value="hours">小时</option>
            <option value="days">天</option>
          </select>
        </label>
      </div>
    `:l`
    <div class="form-grid" style="margin-top: 12px;">
      <label class="field">
        <span>Cron 表达式</span>
        <input
          .value=${t.cronExpr}
          @input=${n=>e.onFormChange({cronExpr:n.target.value})}
        />
      </label>
      <label class="field">
        <span>时区 (可选)</span>
        <input
          .value=${t.cronTz}
          @input=${n=>e.onFormChange({cronTz:n.target.value})}
        />
      </label>
    </div>
  `}function Nf(e,t){const s=`list-item list-item-clickable${t.runsJobId===e.id?" list-item-selected":""}`;return l`
    <div class=${s} @click=${()=>t.onLoadRuns(e.id)}>
      <div class="list-main">
        <div class="list-title">${e.name}</div>
        <div class="list-sub">${Cf(e)}</div>
        <div class="muted">${Mf(e)}</div>
        ${e.agentId?l`<div class="muted">智能体ID: ${e.agentId}</div>`:h}
        <div class="chip-row" style="margin-top: 6px;">
          <span class="chip">${e.enabled?"已启用":"已停用"}</span>
          <span class="chip">${e.sessionTarget}</span>
          <span class="chip">${e.wakeMode}</span>
        </div>
      </div>
      <div class="list-meta">
        <div>${Ef(e)}</div>
        <div class="row" style="justify-content: flex-end; margin-top: 8px;">
          <button
            class="btn"
            ?disabled=${t.busy}
            @click=${i=>{i.stopPropagation(),t.onToggle(e,!e.enabled)}}
          >
            ${e.enabled?"停用":"启用"}
          </button>
          <button
            class="btn"
            ?disabled=${t.busy}
            @click=${i=>{i.stopPropagation(),t.onRun(e)}}
          >
            运行
          </button>
          <button
            class="btn"
            ?disabled=${t.busy}
            @click=${i=>{i.stopPropagation(),t.onLoadRuns(e.id)}}
          >
            运行记录
          </button>
          <button
            class="btn danger"
            ?disabled=${t.busy}
            @click=${i=>{i.stopPropagation(),t.onRemove(e)}}
          >
            移除
          </button>
        </div>
      </div>
    </div>
  `}function Of(e){return l`
    <div class="list-item">
      <div class="list-main">
        <div class="list-title">${e.status}</div>
        <div class="list-sub">${e.summary??""}</div>
      </div>
      <div class="list-meta">
        <div>${Et(e.ts)}</div>
        <div class="muted">${e.durationMs??0}ms</div>
        ${e.error?l`<div class="muted">${e.error}</div>`:h}
      </div>
    </div>
  `}function Df(e){return l`
    <section class="grid grid-cols-2">
      <div class="card">
        <div class="row" style="justify-content: space-between;">
          <div>
            <div class="card-title">系统快照</div>
            <div class="card-sub">状态、健康状况和心跳数据。</div>
          </div>
          <button class="btn" ?disabled=${e.loading} @click=${e.onRefresh}>
            ${e.loading?"刷新中...":"刷新"}
          </button>
        </div>
        <div class="stack" style="margin-top: 12px;">
          <div>
            <div class="muted">状态 (Status)</div>
            <pre class="code-block">${JSON.stringify(e.status??{},null,2)}</pre>
          </div>
          <div>
            <div class="muted">健康状况 (Health)</div>
            <pre class="code-block">${JSON.stringify(e.health??{},null,2)}</pre>
          </div>
          <div>
            <div class="muted">最后心跳时间 (Heartbeat)</div>
            <pre class="code-block">${JSON.stringify(e.heartbeat??{},null,2)}</pre>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-title">手动 RPC 调用</div>
        <div class="card-sub">通过 JSON 参数调用原始网关方法。</div>
        <div class="form-grid" style="margin-top: 16px;">
          <label class="field">
            <span>方法名 (Method)</span>
            <input
              .value=${e.callMethod}
              @input=${t=>e.onCallMethodChange(t.target.value)}
              placeholder="system-presence"
            />
          </label>
          <label class="field">
            <span>参数 (JSON)</span>
            <textarea
              .value=${e.callParams}
              @input=${t=>e.onCallParamsChange(t.target.value)}
              rows="6"
            ></textarea>
          </label>
        </div>
        <div class="row" style="margin-top: 12px;">
          <button class="btn primary" @click=${e.onCall}>执行调用</button>
        </div>
        ${e.callError?l`<div class="callout danger" style="margin-top: 12px;">
              ${e.callError}
            </div>`:h}
        ${e.callResult?l`<pre class="code-block" style="margin-top: 12px;">${e.callResult}</pre>`:h}
      </div>
    </section>

    <section class="card" style="margin-top: 18px;">
      <div class="card-title">模型列表 (Models)</div>
      <div class="card-sub">来自 models.list 的完整模型目录。</div>
      <pre class="code-block" style="margin-top: 12px;">${JSON.stringify(e.models??[],null,2)}</pre>
    </section>

    <section class="card" style="margin-top: 18px;">
      <div class="card-title">事件日志 (Event Log)</div>
      <div class="card-sub">最新的网关实时事件流。</div>
      ${e.eventLog.length===0?l`<div class="muted" style="margin-top: 12px;">尚无事件发布。</div>`:l`
            <div class="list" style="margin-top: 12px;">
              ${e.eventLog.map(t=>l`
                  <div class="list-item">
                    <div class="list-main">
                      <div class="list-title">${t.event}</div>
                      <div class="list-sub">${new Date(t.ts).toLocaleTimeString()}</div>
                    </div>
                    <div class="list-meta">
                      <pre class="code-block">${Tf(t.payload)}</pre>
                    </div>
                  </div>
                `)}
            </div>
          `}
    </section>
  `}function Bf(e){return l`
    <section class="card">
      <div class="row" style="justify-content: space-between;">
        <div>
          <div class="card-title">连通实例 (Instances)</div>
          <div class="card-sub">来自网关与客户端的状态信号。</div>
        </div>
        <button class="btn" ?disabled=${e.loading} @click=${e.onRefresh}>
          ${e.loading?"加载中…":"刷新"}
        </button>
      </div>
      ${e.lastError?l`<div class="callout danger" style="margin-top: 12px;">
            ${e.lastError}
          </div>`:h}
      ${e.statusMessage?l`<div class="callout" style="margin-top: 12px;">
            ${e.statusMessage}
          </div>`:h}
      <div class="list" style="margin-top: 16px;">
        ${e.entries.length===0?l`<div class="muted">暂无上报的实例。</div>`:e.entries.map(t=>Ff(t))}
      </div>
    </section>
  `}function Ff(e){const t=e.lastInputSeconds!=null?`${e.lastInputSeconds} 秒前`:"无",n=e.mode??"未知模式",s=Array.isArray(e.roles)?e.roles.filter(Boolean):[],i=Array.isArray(e.scopes)?e.scopes.filter(Boolean):[],r=i.length>0?i.length>3?`${i.length} 个作用域`:`作用域: ${i.join(", ")}`:null;return l`
    <div class="list-item">
      <div class="list-main">
        <div class="list-title">${e.host??"未知主机"}</div>
        <div class="list-sub">${kf(e)}</div>
        <div class="chip-row">
          <span class="chip">${n}</span>
          ${s.map(a=>l`<span class="chip">${a}</span>`)}
          ${r?l`<span class="chip">${r}</span>`:h}
          ${e.platform?l`<span class="chip">${e.platform}</span>`:h}
          ${e.deviceFamily?l`<span class="chip">${e.deviceFamily}</span>`:h}
          ${e.modelIdentifier?l`<span class="chip">${e.modelIdentifier}</span>`:h}
          ${e.version?l`<span class="chip">${e.version}</span>`:h}
        </div>
      </div>
      <div class="list-meta">
        <div>${Sf(e)}</div>
        <div class="muted">最后输入: ${t}</div>
        <div class="muted">原因: ${e.reason??"无"}</div>
      </div>
    </div>
  `}const Kr=["trace","debug","info","warn","error","fatal"];function Uf(e){if(!e)return"";const t=new Date(e);return Number.isNaN(t.getTime())?e:t.toLocaleTimeString()}function Kf(e,t){return t?[e.message,e.subsystem,e.raw].filter(Boolean).join(" ").toLowerCase().includes(t):!0}function Hf(e){const t=e.filterText.trim().toLowerCase(),n=Kr.some(r=>!e.levelFilters[r]),s=e.entries.filter(r=>r.level&&!e.levelFilters[r.level]?!1:Kf(r,t)),i=t||n;return l`
    <section class="card">
      <div class="row" style="justify-content: space-between;">
        <div>
          <div class="card-title">日志</div>
          <div class="card-sub">网关日志文件 (JSONL)。</div>
        </div>
        <div class="row" style="gap: 8px;">
          <button class="btn" ?disabled=${e.loading} @click=${e.onRefresh}>
            ${e.loading?"加载中...":"刷新"}
          </button>
          <button
            class="btn"
            ?disabled=${s.length===0}
            @click=${()=>e.onExport(s.map(r=>r.raw),i?"filtered":"visible")}
          >
            导出 ${i?"过滤后":"全部"}日志
          </button>
        </div>
      </div>

      <div class="filters" style="margin-top: 14px;">
        <label class="field" style="min-width: 220px;">
          <span>搜索</span>
          <input
            .value=${e.filterText}
            @input=${r=>e.onFilterTextChange(r.target.value)}
            placeholder="搜索日志..."
          />
        </label>
        <label class="field checkbox">
          <span>自动滚动</span>
          <input
            type="checkbox"
            .checked=${e.autoFollow}
            @change=${r=>e.onToggleAutoFollow(r.target.checked)}
          />
        </label>
      </div>

      <div class="chip-row" style="margin-top: 12px;">
        ${Kr.map(r=>l`
            <label class="chip log-chip ${r}">
              <input
                type="checkbox"
                .checked=${e.levelFilters[r]}
                @change=${a=>e.onLevelToggle(r,a.target.checked)}
              />
              <span>${r}</span>
            </label>
          `)}
      </div>

      ${e.file?l`<div class="muted" style="margin-top: 10px;">文件: ${e.file}</div>`:h}
      ${e.truncated?l`<div class="callout" style="margin-top: 10px;">
            日志输出已截断；仅显示最新部分。
          </div>`:h}
      ${e.error?l`<div class="callout danger" style="margin-top: 10px;">${e.error}</div>`:h}

      <div class="log-stream" style="margin-top: 12px;" @scroll=${e.onScroll}>
        ${s.length===0?l`<div class="muted" style="padding: 12px;">无日志条目。</div>`:s.map(r=>l`
                <div class="log-row">
                  <div class="log-time mono">${Uf(r.time)}</div>
                  <div class="log-level ${r.level??""}">${r.level??""}</div>
                  <div class="log-subsystem mono">${r.subsystem??""}</div>
                  <div class="log-message mono">${r.message??r.raw}</div>
                </div>
              `)}
      </div>
    </section>
  `}function zf(e){const t=Qf(e),n=th(e);return l`
    ${sh(n)}
    ${nh(t)}
    ${jf(e)}
    <section class="card">
      <div class="row" style="justify-content: space-between;">
        <div>
          <div class="card-title">接入点 (Nodes)</div>
          <div class="card-sub">已连接的远程执行节点。</div>
        </div>
        <button class="btn" ?disabled=${e.loading} @click=${e.onRefresh}>
          ${e.loading?"加载中...":"刷新"}
        </button>
      </div>
      <div class="list" style="margin-top: 16px;">
        ${e.nodes.length===0?l`<div class="muted">未找到接入点。</div>`:e.nodes.map(s=>fh(s))}
      </div>
    </section>
  `}function jf(e){const t=e.devicesList??{pending:[],paired:[]},n=Array.isArray(t.pending)?t.pending:[],s=Array.isArray(t.paired)?t.paired:[];return l`
    <section class="card">
      <div class="row" style="justify-content: space-between;">
        <div>
          <div class="card-title">设备管理 (Devices)</div>
          <div class="card-sub">配对请求及身份令牌。</div>
        </div>
        <button class="btn" ?disabled=${e.devicesLoading} @click=${e.onDevicesRefresh}>
          ${e.devicesLoading?"加载中...":"刷新"}
        </button>
      </div>
      ${e.devicesError?l`<div class="callout danger" style="margin-top: 12px;">${e.devicesError}</div>`:h}
      <div class="list" style="margin-top: 16px;">
        ${n.length>0?l`
              <div class="muted" style="margin-bottom: 8px;">待处理</div>
              ${n.map(i=>qf(i,e))}
            `:h}
        ${s.length>0?l`
              <div class="muted" style="margin-top: 12px; margin-bottom: 8px;">已配对</div>
              ${s.map(i=>Vf(i,e))}
            `:h}
        ${n.length===0&&s.length===0?l`<div class="muted">无已配对设备。</div>`:h}
      </div>
    </section>
  `}function qf(e,t){const n=e.displayName?.trim()||e.deviceId,s=typeof e.ts=="number"?D(e.ts):"无",i=e.role?.trim()?`角色: ${e.role}`:"角色: -",r=e.isRepair?" · 修复":"",a=e.remoteIp?` · ${e.remoteIp}`:"";return l`
    <div class="list-item">
      <div class="list-main">
        <div class="list-title">${n}</div>
        <div class="list-sub">${e.deviceId}${a}</div>
        <div class="muted" style="margin-top: 6px;">
          ${i} · 请求于 ${s}${r}
        </div>
      </div>
      <div class="list-meta">
        <div class="row" style="justify-content: flex-end; gap: 8px; flex-wrap: wrap;">
          <button class="btn btn--sm primary" @click=${()=>t.onDeviceApprove(e.requestId)}>
            通过
          </button>
          <button class="btn btn--sm" @click=${()=>t.onDeviceReject(e.requestId)}>
            拒绝
          </button>
        </div>
      </div>
    </div>
  `}function Vf(e,t){const n=e.displayName?.trim()||e.deviceId,s=e.remoteIp?` · ${e.remoteIp}`:"",i=`角色: ${rs(e.roles)}`,r=`范围: ${rs(e.scopes)}`,a=Array.isArray(e.tokens)?e.tokens:[];return l`
    <div class="list-item">
      <div class="list-main">
        <div class="list-title">${n}</div>
        <div class="list-sub">${e.deviceId}${s}</div>
        <div class="muted" style="margin-top: 6px;">${i} · ${r}</div>
        ${a.length===0?l`<div class="muted" style="margin-top: 6px;">身份令牌: 无</div>`:l`
              <div class="muted" style="margin-top: 10px;">身份令牌</div>
              <div style="display: flex; flex-direction: column; gap: 8px; margin-top: 6px;">
                ${a.map(o=>Wf(e.deviceId,o,t))}
              </div>
            `}
      </div>
    </div>
  `}function Wf(e,t,n){const s=t.revokedAtMs?"已撤销":"活跃",i=`范围: ${rs(t.scopes)}`,r=D(t.rotatedAtMs??t.createdAtMs??t.lastUsedAtMs??null);return l`
    <div class="row" style="justify-content: space-between; gap: 8px;">
      <div class="list-sub">${t.role} · ${s} · ${i} · ${r}</div>
      <div class="row" style="justify-content: flex-end; gap: 6px; flex-wrap: wrap;">
        <button
          class="btn btn--sm"
          @click=${()=>n.onDeviceRotate(e,t.role,t.scopes)}
        >
          轮换
        </button>
        ${t.revokedAtMs?h:l`
              <button
                class="btn btn--sm danger"
                @click=${()=>n.onDeviceRevoke(e,t.role)}
              >
                撤销
              </button>
            `}
      </div>
    </div>
  `}const Se="__defaults__",Hr=[{value:"deny",label:"拒绝"},{value:"allowlist",label:"白名单"},{value:"full",label:"完全开放"}],Gf=[{value:"off",label:"关闭"},{value:"on-miss",label:"未命中匹配时"},{value:"always",label:"总是询问"}];function Qf(e){const t=e.configForm,n=dh(e.nodes),{defaultBinding:s,agents:i}=ph(t),r=!!t,a=e.configSaving||e.configFormMode==="raw";return{ready:r,disabled:a,configDirty:e.configDirty,configLoading:e.configLoading,configSaving:e.configSaving,defaultBinding:s,agents:i,nodes:n,onBindDefault:e.onBindDefault,onBindAgent:e.onBindAgent,onSave:e.onSaveBindings,onLoadConfig:e.onLoadConfig,formMode:e.configFormMode}}function zr(e){return e==="allowlist"||e==="full"||e==="deny"?e:"deny"}function Zf(e){return e==="always"||e==="off"||e==="on-miss"?e:"on-miss"}function Yf(e){const t=e?.defaults??{};return{security:zr(t.security),ask:Zf(t.ask),askFallback:zr(t.askFallback??"deny"),autoAllowSkills:!!(t.autoAllowSkills??!1)}}function Xf(e){const t=e?.agents??{},n=Array.isArray(t.list)?t.list:[],s=[];return n.forEach(i=>{if(!i||typeof i!="object")return;const r=i,a=typeof r.id=="string"?r.id.trim():"";if(!a)return;const o=typeof r.name=="string"?r.name.trim():void 0,c=r.default===!0;s.push({id:a,name:o||void 0,isDefault:c})}),s}function Jf(e,t){const n=Xf(e),s=Object.keys(t?.agents??{}),i=new Map;n.forEach(a=>i.set(a.id,a)),s.forEach(a=>{i.has(a)||i.set(a,{id:a})});const r=Array.from(i.values());return r.length===0&&r.push({id:"main",isDefault:!0}),r.sort((a,o)=>{if(a.isDefault&&!o.isDefault)return-1;if(!a.isDefault&&o.isDefault)return 1;const c=a.name?.trim()?a.name:a.id,p=o.name?.trim()?o.name:o.id;return c.localeCompare(p)}),r}function eh(e,t){return e===Se?Se:e&&t.some(n=>n.id===e)?e:Se}function th(e){const t=e.execApprovalsForm??e.execApprovalsSnapshot?.file??null,n=!!t,s=Yf(t),i=Jf(e.configForm,t),r=uh(e.nodes),a=e.execApprovalsTarget;let o=a==="node"&&e.execApprovalsTargetNodeId?e.execApprovalsTargetNodeId:null;a==="node"&&o&&!r.some(u=>u.id===o)&&(o=null);const c=eh(e.execApprovalsSelectedAgent,i),p=c!==Se?(t?.agents??{})[c]??null:null,d=Array.isArray(p?.allowlist)?p.allowlist??[]:[];return{ready:n,disabled:e.execApprovalsSaving||e.execApprovalsLoading,dirty:e.execApprovalsDirty,loading:e.execApprovalsLoading,saving:e.execApprovalsSaving,form:t,defaults:s,selectedScope:c,selectedAgent:p,agents:i,allowlist:d,target:a,targetNodeId:o,targetNodes:r,onSelectScope:e.onExecApprovalsSelectAgent,onSelectTarget:e.onExecApprovalsTargetChange,onPatch:e.onExecApprovalsPatch,onRemove:e.onExecApprovalsRemove,onLoad:e.onLoadExecApprovals,onSave:e.onSaveExecApprovals}}function nh(e){const t=e.nodes.length>0,n=e.defaultBinding??"";return l`
    <section class="card">
      <div class="row" style="justify-content: space-between; align-items: center;">
        <div>
          <div class="card-title">执行节点绑定 (Exec binding)</div>
          <div class="card-sub">
            在使用 <span class="mono">exec host=node</span> 时，将智能体固定到特定节点执行。
          </div>
        </div>
        <button
          class="btn"
          ?disabled=${e.disabled||!e.configDirty}
          @click=${e.onSave}
        >
          ${e.configSaving?"保存中...":"保存设置"}
        </button>
      </div>

      ${e.formMode==="raw"?l`<div class="callout warn" style="margin-top: 12px;">
            请将配置标签页切换到 <strong>表单 (Form)</strong> 模式以便在此处编辑绑定设置。
          </div>`:h}

      ${e.ready?l`
            <div class="list" style="margin-top: 16px;">
              <div class="list-item">
                <div class="list-main">
                  <div class="list-title">默认绑定节点</div>
                  <div class="list-sub">当智能体未指定节点绑定时使用的默认执行节点。</div>
                </div>
                <div class="list-meta">
                  <label class="field">
                    <span>执行节点</span>
                    <select
                      ?disabled=${e.disabled||!t}
                      @change=${s=>{const r=s.target.value.trim();e.onBindDefault(r||null)}}
                    >
                      <option value="" ?selected=${n===""}>任意节点</option>
                      ${e.nodes.map(s=>l`<option
                            value=${s.id}
                            ?selected=${n===s.id}
                          >
                            ${s.label}
                          </option>`)}
                    </select>
                  </label>
                  ${t?h:l`<div class="muted">没有可用于执行 system.run 的节点。</div>`}
                </div>
              </div>

              ${e.agents.length===0?l`<div class="muted">未找到智能体。</div>`:e.agents.map(s=>ch(s,e))}
            </div>
          `:l`<div class="row" style="margin-top: 12px; gap: 12px;">
            <div class="muted">请先加载配置以编辑绑定设置。</div>
            <button class="btn" ?disabled=${e.configLoading} @click=${e.onLoadConfig}>
              ${e.configLoading?"加载中...":"加载配置"}
            </button>
          </div>`}
    </section>
  `}function sh(e){const t=e.ready,n=e.target!=="node"||!!e.targetNodeId;return l`
    <section class="card">
      <div class="row" style="justify-content: space-between; align-items: center;">
        <div>
          <div class="card-title">执行审批 (Exec approvals)</div>
          <div class="card-sub">
            针对 <span class="mono">exec host=gateway/node</span> 的执行白名单及审批策略。
          </div>
        </div>
        <button
          class="btn"
          ?disabled=${e.disabled||!e.dirty||!n}
          @click=${e.onSave}
        >
          ${e.saving?"保存中...":"保存设置"}
        </button>
      </div>

      ${ih(e)}

      ${t?l`
            ${rh(e)}
            ${ah(e)}
            ${e.selectedScope===Se?h:oh(e)}
          `:l`<div class="row" style="margin-top: 12px; gap: 12px;">
            <div class="muted">请先加载执行审批数据以编辑白名单。</div>
            <button class="btn" ?disabled=${e.loading||!n} @click=${e.onLoad}>
              ${e.loading?"加载中...":"加载审批数据"}
            </button>
          </div>`}
    </section>
  `}function ih(e){const t=e.targetNodes.length>0,n=e.targetNodeId??"";return l`
    <div class="list" style="margin-top: 12px;">
      <div class="list-item">
        <div class="list-main">
          <div class="list-title">管理目标</div>
          <div class="list-sub">
            网关模式编辑本地审批；节点模式编辑选定的执行节点。
          </div>
        </div>
        <div class="list-meta">
          <label class="field">
            <span>控制端</span>
            <select
              ?disabled=${e.disabled}
              @change=${s=>{if(s.target.value==="node"){const a=e.targetNodes[0]?.id??null;e.onSelectTarget("node",n||a)}else e.onSelectTarget("gateway",null)}}
            >
              <option value="gateway" ?selected=${e.target==="gateway"}>网关</option>
              <option value="node" ?selected=${e.target==="node"}>节点</option>
            </select>
          </label>
          ${e.target==="node"?l`
                <label class="field">
                  <span>执行节点</span>
                  <select
                    ?disabled=${e.disabled||!t}
                    @change=${s=>{const r=s.target.value.trim();e.onSelectTarget("node",r||null)}}
                  >
                    <option value="" ?selected=${n===""}>选择节点...</option>
                    ${e.targetNodes.map(s=>l`<option
                          value=${s.id}
                          ?selected=${n===s.id}
                        >
                          ${s.label}
                        </option>`)}
                  </select>
                </label>
              `:h}
        </div>
      </div>
      ${e.target==="node"&&!t?l`<div class="muted">尚未有节点报告可用的执行审批能力。</div>`:h}
    </div>
  `}function rh(e){return l`
    <div class="row" style="margin-top: 12px; gap: 8px; flex-wrap: wrap;">
      <span class="label">适用范围</span>
      <div class="row" style="gap: 8px; flex-wrap: wrap;">
        <button
          class="btn btn--sm ${e.selectedScope===Se?"active":""}"
          @click=${()=>e.onSelectScope(Se)}
        >
          全局默认
        </button>
        ${e.agents.map(t=>{const n=t.name?.trim()?`${t.name} (${t.id})`:t.id;return l`
            <button
              class="btn btn--sm ${e.selectedScope===t.id?"active":""}"
              @click=${()=>e.onSelectScope(t.id)}
            >
              ${n}
            </button>
          `})}
      </div>
    </div>
  `}function ah(e){const t=e.selectedScope===Se,n=e.defaults,s=e.selectedAgent??{},i=t?["defaults"]:["agents",e.selectedScope],r=typeof s.security=="string"?s.security:void 0,a=typeof s.ask=="string"?s.ask:void 0,o=typeof s.askFallback=="string"?s.askFallback:void 0,c=t?n.security:r??"__default__",p=t?n.ask:a??"__default__",d=t?n.askFallback:o??"__default__",u=typeof s.autoAllowSkills=="boolean"?s.autoAllowSkills:void 0,v=u??n.autoAllowSkills,g=u==null;return l`
    <div class="list" style="margin-top: 16px;">
      <div class="list-item">
        <div class="list-main">
          <div class="list-title">安全等级 (Security)</div>
          <div class="list-sub">
            ${t?"默认安全执行模式。":`当前默认值: ${n.security}。`}
          </div>
        </div>
        <div class="list-meta">
          <label class="field">
            <span>模式</span>
            <select
              ?disabled=${e.disabled}
              @change=${y=>{const A=y.target.value;!t&&A==="__default__"?e.onRemove([...i,"security"]):e.onPatch([...i,"security"],A)}}
            >
              ${t?h:l`<option value="__default__" ?selected=${c==="__default__"}>
                    使用默认 (${n.security})
                  </option>`}
              ${Hr.map(y=>l`<option
                    value=${y.value}
                    ?selected=${c===y.value}
                  >
                    ${y.label}
                  </option>`)}
            </select>
          </label>
        </div>
      </div>

      <div class="list-item">
        <div class="list-main">
          <div class="list-title">审批询问 (Ask)</div>
          <div class="list-sub">
            ${t?"默认弹窗询问策略。":`当前默认值: ${n.ask}。`}
          </div>
        </div>
        <div class="list-meta">
          <label class="field">
            <span>策略</span>
            <select
              ?disabled=${e.disabled}
              @change=${y=>{const A=y.target.value;!t&&A==="__default__"?e.onRemove([...i,"ask"]):e.onPatch([...i,"ask"],A)}}
            >
              ${t?h:l`<option value="__default__" ?selected=${p==="__default__"}>
                    使用默认 (${n.ask})
                  </option>`}
              ${Gf.map(y=>l`<option
                    value=${y.value}
                    ?selected=${p===y.value}
                  >
                    ${y.label}
                  </option>`)}
            </select>
          </label>
        </div>
      </div>

      <div class="list-item">
        <div class="list-main">
          <div class="list-title">询问回退 (Ask fallback)</div>
          <div class="list-sub">
            ${t?"当 UI 提示无法显示时的回退选择。":`当前默认值: ${n.askFallback}。`}
          </div>
        </div>
        <div class="list-meta">
          <label class="field">
            <span>回退策略</span>
            <select
              ?disabled=${e.disabled}
              @change=${y=>{const A=y.target.value;!t&&A==="__default__"?e.onRemove([...i,"askFallback"]):e.onPatch([...i,"askFallback"],A)}}
            >
              ${t?h:l`<option value="__default__" ?selected=${d==="__default__"}>
                    使用默认 (${n.askFallback})
                  </option>`}
              ${Hr.map(y=>l`<option
                    value=${y.value}
                    ?selected=${d===y.value}
                  >
                    ${y.label}
                  </option>`)}
            </select>
          </label>
        </div>
      </div>

      <div class="list-item">
        <div class="list-main">
          <div class="list-title">自动允许技能 CLI</div>
          <div class="list-sub">
            ${t?"通过网关直接执行已安装的技能入口程序。":g?`使用默认 (${n.autoAllowSkills?"开启":"关闭"})。`:`已覆盖设定 (${v?"开启":"关闭"})。`}
          </div>
        </div>
        <div class="list-meta">
          <label class="field">
            <span>开启</span>
            <input
              type="checkbox"
              ?disabled=${e.disabled}
              .checked=${v}
              @change=${y=>{const w=y.target;e.onPatch([...i,"autoAllowSkills"],w.checked)}}
            />
          </label>
          ${!t&&!g?l`<button
                class="btn btn--sm"
                ?disabled=${e.disabled}
                @click=${()=>e.onRemove([...i,"autoAllowSkills"])}
              >
                恢复默认
              </button>`:h}
        </div>
      </div>
    </div>
  `}function oh(e){const t=["agents",e.selectedScope,"allowlist"],n=e.allowlist;return l`
    <div class="row" style="margin-top: 18px; justify-content: space-between;">
      <div>
        <div class="card-title">白名单 (Allowlist)</div>
        <div class="card-sub">支持不区分大小写的 Glob 通配符。</div>
      </div>
      <button
        class="btn btn--sm"
        ?disabled=${e.disabled}
        @click=${()=>{const s=[...n,{pattern:""}];e.onPatch(t,s)}}
      >
        添加模式
      </button>
    </div>
    <div class="list" style="margin-top: 12px;">
      ${n.length===0?l`<div class="muted">暂无白名单项。</div>`:n.map((s,i)=>lh(e,s,i))}
    </div>
  `}function lh(e,t,n){const s=t.lastUsedAt?D(t.lastUsedAt):"从未使用",i=t.lastUsedCommand?as(t.lastUsedCommand,120):null,r=t.lastResolvedPath?as(t.lastResolvedPath,120):null;return l`
    <div class="list-item">
      <div class="list-main">
        <div class="list-title">${t.pattern?.trim()?t.pattern:"新规则模式"}</div>
        <div class="list-sub">上次使用: ${s}</div>
        ${i?l`<div class="list-sub mono">${i}</div>`:h}
        ${r?l`<div class="list-sub mono">${r}</div>`:h}
      </div>
      <div class="list-meta">
        <label class="field">
          <span>模式</span>
          <input
            type="text"
            .value=${t.pattern??""}
            ?disabled=${e.disabled}
            @input=${a=>{const o=a.target;e.onPatch(["agents",e.selectedScope,"allowlist",n,"pattern"],o.value)}}
          />
        </label>
        <button
          class="btn btn--sm danger"
          ?disabled=${e.disabled}
          @click=${()=>{if(e.allowlist.length<=1){e.onRemove(["agents",e.selectedScope,"allowlist"]);return}e.onRemove(["agents",e.selectedScope,"allowlist",n])}}
        >
          移除
        </button>
      </div>
    </div>
  `}function ch(e,t){const n=e.binding??"__default__",s=e.name?.trim()?`${e.name} (${e.id})`:e.id,i=t.nodes.length>0;return l`
    <div class="list-item">
      <div class="list-main">
        <div class="list-title">${s}</div>
        <div class="list-sub">
          ${e.isDefault?"默认智能体":"智能体"} ·
          ${n==="__default__"?`使用全局默认 (${t.defaultBinding??"任意节点"})`:`覆盖设定: ${e.binding}`}
        </div>
      </div>
      <div class="list-meta">
        <label class="field">
          <span>绑定节点</span>
          <select
            ?disabled=${t.disabled||!i}
            @change=${r=>{const o=r.target.value.trim();t.onBindAgent(e.index,o==="__default__"?null:o)}}
          >
            <option value="__default__" ?selected=${n==="__default__"}>
              使用全局默认
            </option>
            ${t.nodes.map(r=>l`<option
                  value=${r.id}
                  ?selected=${n===r.id}
                >
                  ${r.label}
                </option>`)}
          </select>
        </label>
      </div>
    </div>
  `}function dh(e){const t=[];for(const n of e){if(!(Array.isArray(n.commands)?n.commands:[]).some(o=>String(o)==="system.run"))continue;const r=typeof n.nodeId=="string"?n.nodeId.trim():"";if(!r)continue;const a=typeof n.displayName=="string"&&n.displayName.trim()?n.displayName.trim():r;t.push({id:r,label:a===r?r:`${a} · ${r}`})}return t.sort((n,s)=>n.label.localeCompare(s.label)),t}function uh(e){const t=[];for(const n of e){if(!(Array.isArray(n.commands)?n.commands:[]).some(o=>String(o)==="system.execApprovals.get"||String(o)==="system.execApprovals.set"))continue;const r=typeof n.nodeId=="string"?n.nodeId.trim():"";if(!r)continue;const a=typeof n.displayName=="string"&&n.displayName.trim()?n.displayName.trim():r;t.push({id:r,label:a===r?r:`${a} · ${r}`})}return t.sort((n,s)=>n.label.localeCompare(s.label)),t}function ph(e){const t={id:"main",name:void 0,index:0,isDefault:!0,binding:null};if(!e||typeof e!="object")return{defaultBinding:null,agents:[t]};const s=(e.tools??{}).exec??{},i=typeof s.node=="string"&&s.node.trim()?s.node.trim():null,r=e.agents??{},a=Array.isArray(r.list)?r.list:[];if(a.length===0)return{defaultBinding:i,agents:[t]};const o=[];return a.forEach((c,p)=>{if(!c||typeof c!="object")return;const d=c,u=typeof d.id=="string"?d.id.trim():"";if(!u)return;const v=typeof d.name=="string"?d.name.trim():void 0,g=d.default===!0,w=(d.tools??{}).exec??{},A=typeof w.node=="string"&&w.node.trim()?w.node.trim():null;o.push({id:u,name:v||void 0,index:p,isDefault:g,binding:A})}),o.length===0&&o.push(t),{defaultBinding:i,agents:o}}function fh(e){const t=!!e.connected,n=!!e.paired,s=typeof e.displayName=="string"&&e.displayName.trim()||(typeof e.nodeId=="string"?e.nodeId:"未知节点"),i=Array.isArray(e.caps)?e.caps:[],r=Array.isArray(e.commands)?e.commands:[];return l`
    <div class="list-item">
      <div class="list-main">
        <div class="list-title">${s}</div>
        <div class="list-sub">
          ${typeof e.nodeId=="string"?e.nodeId:""}
          ${typeof e.remoteIp=="string"?` · ${e.remoteIp}`:""}
          ${typeof e.version=="string"?` · ${e.version}`:""}
        </div>
        <div class="chip-row" style="margin-top: 6px;">
          <span class="chip">${n?"已配对":"未配对"}</span>
          <span class="chip ${t?"chip-ok":"chip-warn"}">
            ${t?"在线":"离线"}
          </span>
          ${i.slice(0,12).map(a=>l`<span class="chip">${String(a)}</span>`)}
          ${r.slice(0,8).map(a=>l`<span class="chip">${String(a)}</span>`)}
        </div>
      </div>
    </div>
  `}function hh(e){const t=e.hello?.snapshot,n=t?.uptimeMs?ra(t.uptimeMs):"无",s=t?.policy?.tickIntervalMs?`${t.policy.tickIntervalMs}ms`:"无",i=(()=>{if(e.connected||!e.lastError)return null;const a=e.lastError.toLowerCase();if(!(a.includes("unauthorized")||a.includes("connect failed")))return null;const c=!!e.settings.token.trim(),p=!!e.password.trim();return!c&&!p?l`
        <div class="muted" style="margin-top: 8px;">
          此网关需要身份验证。请添加令牌或密码，然后点击“连接”。
          <div style="margin-top: 6px;">
            <span class="mono">clawdbot dashboard --no-open</span> → 获取带令牌的 URL<br />
            <span class="mono">clawdbot doctor --generate-gateway-token</span> → 设置令牌
          </div>
          <div style="margin-top: 6px;">
            <a
              class="session-link"
              href="https://docs.clawd.bot/web/dashboard"
              target="_blank"
              rel="noreferrer"
              title="控制面板身份验证文档（在新标签页中打开）"
              >文档：控制面板身份验证</a
            >
          </div>
        </div>
      `:l`
      <div class="muted" style="margin-top: 8px;">
        身份验证失败。请通过
        <span class="mono">clawdbot dashboard --no-open</span> 重新复制带令牌的 URL，或者更新令牌，然后点击“连接”。
        <div style="margin-top: 6px;">
          <a
            class="session-link"
            href="https://docs.clawd.bot/web/dashboard"
            target="_blank"
            rel="noreferrer"
            title="控制面板身份验证文档（在新标签页中打开）"
            >文档：控制面板身份验证</a
          >
        </div>
      </div>
    `})(),r=(()=>{if(e.connected||!e.lastError||(typeof window<"u"?window.isSecureContext:!0)!==!1)return null;const o=e.lastError.toLowerCase();return!o.includes("secure context")&&!o.includes("device identity required")?null:l`
      <div class="muted" style="margin-top: 8px;">
        此页面处于 HTTP 环境，浏览器会拦截设备身份。请使用 HTTPS (Tailscale Serve) 或在网关主机上打开
        <span class="mono">http://127.0.0.1:18789</span>。
        <div style="margin-top: 6px;">
          如果必须使用 HTTP，请设置
          <span class="mono">gateway.controlUi.allowInsecureAuth: true</span> (仅令牌验证)。
        </div>
        <div style="margin-top: 6px;">
          <a
            class="session-link"
            href="https://docs.clawd.bot/gateway/tailscale"
            target="_blank"
            rel="noreferrer"
            title="Tailscale Serve 文档（在新标签页中打开）"
            >文档：Tailscale Serve</a
          >
          <span class="muted"> · </span>
          <a
            class="session-link"
            href="https://docs.clawd.bot/web/control-ui#insecure-http"
            target="_blank"
            rel="noreferrer"
            title="不安全 HTTP 文档（在新标签页中打开）"
            >文档：不安全 HTTP</a
          >
        </div>
      </div>
    `})();return l`
    <section class="grid grid-cols-2">
      <div class="card">
        <div class="card-title">网关访问</div>
        <div class="card-sub">控制面板如何连接网关及其身份验证方式。</div>
        <div class="form-grid" style="margin-top: 16px;">
          <label class="field">
            <span>WebSocket 地址</span>
            <input
              .value=${e.settings.gatewayUrl}
              @input=${a=>{const o=a.target.value;e.onSettingsChange({...e.settings,gatewayUrl:o})}}
              placeholder="ws://127.0.0.1:18789"
            />
          </label>
          <label class="field">
            <span>网关令牌 (Token)</span>
            <input
              .value=${e.settings.token}
              @input=${a=>{const o=a.target.value;e.onSettingsChange({...e.settings,token:o})}}
              placeholder="网关访问令牌"
            />
          </label>
          <label class="field">
            <span>密码 (不存储)</span>
            <input
              type="password"
              .value=${e.password}
              @input=${a=>{const o=a.target.value;e.onPasswordChange(o)}}
              placeholder="系统或共享密码"
            />
          </label>
          <label class="field">
            <span>默认会话键 (Session Key)</span>
            <input
              .value=${e.settings.sessionKey}
              @input=${a=>{const o=a.target.value;e.onSessionKeyChange(o)}}
            />
          </label>
        </div>
        <div class="row" style="margin-top: 14px;">
          <button class="btn" @click=${()=>e.onConnect()}>连接</button>
          <button class="btn" @click=${()=>e.onRefresh()}>刷新</button>
          <span class="muted">点击“连接”以应用连接设置。</span>
        </div>
      </div>

      <div class="card">
        <div class="card-title">快照</div>
        <div class="card-sub">最新的网关握手信息。</div>
        <div class="stat-grid" style="margin-top: 16px;">
          <div class="stat">
            <div class="stat-label">状态</div>
            <div class="stat-value ${e.connected?"ok":"warn"}">
              ${e.connected?"已连接":"未连接"}
            </div>
          </div>
          <div class="stat">
            <div class="stat-label">运行时间</div>
            <div class="stat-value">${n}</div>
          </div>
          <div class="stat">
            <div class="stat-label">心跳间隔 (Tick)</div>
            <div class="stat-value">${s}</div>
          </div>
          <div class="stat">
            <div class="stat-label">渠道上次刷新</div>
            <div class="stat-value">
              ${e.lastChannelsRefresh?D(e.lastChannelsRefresh):"无"}
            </div>
          </div>
        </div>
        ${e.lastError?l`<div class="callout danger" style="margin-top: 14px;">
              <div>${e.lastError}</div>
              ${i??""}
              ${r??""}
            </div>`:l`<div class="callout" style="margin-top: 14px;">
              使用“渠道”页面链接 WhatsApp, Telegram, Discord, Signal 或 iMessage。
            </div>`}
      </div>
    </section>

    <section class="grid grid-cols-3" style="margin-top: 18px;">
      <div class="card stat-card">
        <div class="stat-label">实例</div>
        <div class="stat-value">${e.presenceCount}</div>
        <div class="muted">过去 5 分钟内的在线心跳数量。</div>
      </div>
      <div class="card stat-card">
        <div class="stat-label">会话</div>
        <div class="stat-value">${e.sessionsCount??"无"}</div>
        <div class="muted">网关追踪的近期会话键数量。</div>
      </div>
      <div class="card stat-card">
        <div class="stat-label">定时任务</div>
        <div class="stat-value">
          ${e.cronEnabled==null?"无":e.cronEnabled?"已启用":"已禁用"}
        </div>
        <div class="muted">下次唤醒：${vo(e.cronNext)}</div>
      </div>
    </section>

    <section class="card" style="margin-top: 18px;">
      <div class="card-title">备忘录</div>
      <div class="card-sub">远程控制设置的快速提醒。</div>
      <div class="note-grid" style="margin-top: 14px;">
        <div>
          <div class="note-title">Tailscale serve</div>
          <div class="muted">
            推荐使用 serve 模式，将网关保持在 loopback 并使用 tailnet 身份验证。
          </div>
        </div>
        <div>
          <div class="note-title">会话清理</div>
          <div class="muted">使用 /new 或 sessions.patch 重置上下文。</div>
        </div>
        <div>
          <div class="note-title">Cron 提醒</div>
          <div class="muted">对循环运行的任务使用独立的会话。</div>
        </div>
      </div>
    </section>
  `}const gh=["","off","minimal","low","medium","high"],vh=["","off","on"],mh=[{value:"",label:"继承"},{value:"off",label:"关闭 (显式)"},{value:"on",label:"开启"}],yh=[{value:"",label:"继承"},{value:"off",label:"关闭"},{value:"on",label:"开启"},{value:"stream",label:"流式推理"}],bh={"":"继承",off:"关闭",on:"开启",minimal:"极简",low:"低",medium:"中",high:"高"};function $h(e){if(!e)return"";const t=e.trim().toLowerCase();return t==="z.ai"||t==="z-ai"?"zai":t}function mo(e){return $h(e)==="zai"}function wh(e){return mo(e)?vh:gh}function xh(e,t){return!t||!e||e==="off"?e:"on"}function Ah(e,t){return e?t&&e==="on"?"low":e:null}function kh(e){const t=e.result?.sessions??[];return l`
    <section class="card">
      <div class="row" style="justify-content: space-between;">
        <div>
          <div class="card-title">会话</div>
          <div class="card-sub">活跃会话密钥及各会话覆盖设置。</div>
        </div>
        <button class="btn" ?disabled=${e.loading} @click=${e.onRefresh}>
          ${e.loading?"加载中...":"刷新"}
        </button>
      </div>

      <div class="filters" style="margin-top: 14px;">
        <label class="field">
          <span>活跃于（分钟内）</span>
          <input
            .value=${e.activeMinutes}
            @input=${n=>e.onFiltersChange({activeMinutes:n.target.value,limit:e.limit,includeGlobal:e.includeGlobal,includeUnknown:e.includeUnknown})}
          />
        </label>
        <label class="field">
          <span>限制数量</span>
          <input
            .value=${e.limit}
            @input=${n=>e.onFiltersChange({activeMinutes:e.activeMinutes,limit:n.target.value,includeGlobal:e.includeGlobal,includeUnknown:e.includeUnknown})}
          />
        </label>
        <label class="field checkbox">
          <span>包含全局</span>
          <input
            type="checkbox"
            .checked=${e.includeGlobal}
            @change=${n=>e.onFiltersChange({activeMinutes:e.activeMinutes,limit:e.limit,includeGlobal:n.target.checked,includeUnknown:e.includeUnknown})}
          />
        </label>
        <label class="field checkbox">
          <span>包含未知</span>
          <input
            type="checkbox"
            .checked=${e.includeUnknown}
            @change=${n=>e.onFiltersChange({activeMinutes:e.activeMinutes,limit:e.limit,includeGlobal:e.includeGlobal,includeUnknown:n.target.checked})}
          />
        </label>
      </div>

      ${e.error?l`<div class="callout danger" style="margin-top: 12px;">${e.error}</div>`:h}

      <div class="muted" style="margin-top: 12px;">
        ${e.result?`存储：${e.result.path}`:""}
      </div>

      <div class="table" style="margin-top: 16px;">
        <div class="table-head">
          <div>密钥</div>
          <div>标签</div>
          <div>种类</div>
          <div>更新时间</div>
          <div>Token数</div>
          <div>思考深度</div>
          <div>详细日志</div>
          <div>推理模式</div>
          <div>操作</div>
        </div>
        ${t.length===0?l`<div class="muted">未找到会话。</div>`:t.map(n=>Sh(n,e.basePath,e.onPatch,e.onDelete,e.loading))}
      </div>
    </section>
  `}function Sh(e,t,n,s,i){const r=e.updatedAt?D(e.updatedAt):"无",a=e.thinkingLevel??"",o=mo(e.modelProvider),c=xh(a,o),p=wh(e.modelProvider),d=e.verboseLevel??"",u=e.reasoningLevel??"",v=e.displayName??e.key,g=e.kind!=="global",y=g?`${Ps("chat",t)}?session=${encodeURIComponent(e.key)}`:null;return l`
    <div class="table-row">
      <div class="mono">${g?l`<a href=${y} class="session-link">${v}</a>`:v}</div>
      <div>
        <input
          .value=${e.label??""}
          ?disabled=${i}
          placeholder="(可选)"
          @change=${w=>{const A=w.target.value.trim();n(e.key,{label:A||null})}}
        />
      </div>
      <div>${e.kind}</div>
      <div>${r}</div>
      <div>${_f(e)}</div>
      <div>
        <select
          .value=${c}
          ?disabled=${i}
          @change=${w=>{const A=w.target.value;n(e.key,{thinkingLevel:Ah(A,o)})}}
        >
          ${p.map(w=>l`<option value=${w}>${bh[w]||w}</option>`)}
        </select>
      </div>
      <div>
        <select
          .value=${d}
          ?disabled=${i}
          @change=${w=>{const A=w.target.value;n(e.key,{verboseLevel:A||null})}}
        >
          ${mh.map(w=>l`<option value=${w.value}>${w.label}</option>`)}
        </select>
      </div>
      <div>
        <select
          .value=${u}
          ?disabled=${i}
          @change=${w=>{const A=w.target.value;n(e.key,{reasoningLevel:A||null})}}
        >
          ${yh.map(w=>l`<option value=${w.value}>${w.label}</option>`)}
        </select>
      </div>
      <div>
        <button class="btn danger" ?disabled=${i} @click=${()=>s(e.key)}>
          删除
        </button>
      </div>
    </div>
  `}function _h(e){const t=Math.max(0,e),n=Math.floor(t/1e3);if(n<60)return`${n} 秒`;const s=Math.floor(n/60);return s<60?`${s} 分钟`:`${Math.floor(s/60)} 小时`}function Re(e,t){return t?l`<div class="exec-approval-meta-row"><span>${e}</span><span>${t}</span></div>`:h}function Th(e){const t=e.execApprovalQueue[0];if(!t)return h;const n=t.request,s=t.expiresAtMs-Date.now(),i=s>0?`剩余时间: ${_h(s)}`:"已过期",r=e.execApprovalQueue.length;return l`
    <div class="exec-approval-overlay" role="dialog" aria-live="polite">
      <div class="exec-approval-card">
        <div class="exec-approval-header">
          <div>
            <div class="exec-approval-title">需要审批执行请求</div>
            <div class="exec-approval-sub">${i}</div>
          </div>
          ${r>1?l`<div class="exec-approval-queue">${r} 项待处理</div>`:h}
        </div>
        <div class="exec-approval-command mono">${n.command}</div>
        <div class="exec-approval-meta">
          ${Re("主机",n.host)}
          ${Re("智能体",n.agentId)}
          ${Re("会话",n.sessionKey)}
          ${Re("工作目录",n.cwd)}
          ${Re("解析路径",n.resolvedPath)}
          ${Re("安全等级",n.security)}
          ${Re("询问模式",n.ask)}
        </div>
        ${e.execApprovalError?l`<div class="exec-approval-error">${e.execApprovalError}</div>`:h}
        <div class="exec-approval-actions">
          <button
            class="btn primary"
            ?disabled=${e.execApprovalBusy}
            @click=${()=>e.handleExecApprovalDecision("allow-once")}
          >
            允许本次
          </button>
          <button
            class="btn"
            ?disabled=${e.execApprovalBusy}
            @click=${()=>e.handleExecApprovalDecision("allow-always")}
          >
            总是允许
          </button>
          <button
            class="btn danger"
            ?disabled=${e.execApprovalBusy}
            @click=${()=>e.handleExecApprovalDecision("deny")}
          >
            拒绝
          </button>
        </div>
      </div>
    </div>
  `}function Eh(e){const t=e.report?.skills??[],n=e.filter.trim().toLowerCase(),s=n?t.filter(i=>[i.name,i.description,i.source].join(" ").toLowerCase().includes(n)):t;return l`
    <section class="card">
      <div class="row" style="justify-content: space-between;">
        <div>
          <div class="card-title">技能 (Skills)</div>
          <div class="card-sub">包含内置、托管及工作区技能。</div>
        </div>
        <button class="btn" ?disabled=${e.loading} @click=${e.onRefresh}>
          ${e.loading?"加载中…":"刷新"}
        </button>
      </div>

      <div class="filters" style="margin-top: 14px;">
        <label class="field" style="flex: 1;">
          <span>筛选</span>
          <input
            .value=${e.filter}
            @input=${i=>e.onFilterChange(i.target.value)}
            placeholder="搜索技能名称或描述"
          />
        </label>
        <div class="muted">${s.length} 个已显示</div>
      </div>

      ${e.error?l`<div class="callout danger" style="margin-top: 12px;">${e.error}</div>`:h}

      ${s.length===0?l`<div class="muted" style="margin-top: 16px;">未找到相关技能。</div>`:l`
            <div class="list" style="margin-top: 16px;">
              ${s.map(i=>Ch(i,e))}
            </div>
          `}
    </section>
  `}function Ch(e,t){const n=t.busyKey===e.skillKey,s=t.edits[e.skillKey]??"",i=t.messages[e.skillKey]??null,r=e.install.length>0&&e.missing.bins.length>0,a=[...e.missing.bins.map(c=>`程序:${c}`),...e.missing.env.map(c=>`变量:${c}`),...e.missing.config.map(c=>`配置:${c}`),...e.missing.os.map(c=>`系统:${c}`)],o=[];return e.disabled&&o.push("已停用"),e.blockedByAllowlist&&o.push("被白名单拦截"),l`
    <div class="list-item">
      <div class="list-main">
        <div class="list-title">
          ${e.emoji?`${e.emoji} `:""}${e.name}
        </div>
        <div class="list-sub">${as(e.description,140)}</div>
        <div class="chip-row" style="margin-top: 6px;">
          <span class="chip">${e.source}</span>
          <span class="chip ${e.eligible?"chip-ok":"chip-warn"}">
            ${e.eligible?"符合运行条件":"运行受限制"}
          </span>
          ${e.disabled?l`<span class="chip chip-warn">已停用</span>`:h}
        </div>
        ${a.length>0?l`
              <div class="muted" style="margin-top: 6px;">
                缺失项: ${a.join(", ")}
              </div>
            `:h}
        ${o.length>0?l`
              <div class="muted" style="margin-top: 6px;">
                原因: ${o.join(", ")}
              </div>
            `:h}
      </div>
      <div class="list-meta">
        <div class="row" style="justify-content: flex-end; flex-wrap: wrap;">
          <button
            class="btn"
            ?disabled=${n}
            @click=${()=>t.onToggle(e.skillKey,e.disabled)}
          >
            ${e.disabled?"启用":"停用"}
          </button>
          ${r?l`<button
                class="btn"
                ?disabled=${n}
                @click=${()=>t.onInstall(e.skillKey,e.name,e.install[0].id)}
              >
                ${n?"正在安装…":e.install[0].label}
              </button>`:h}
        </div>
        ${i?l`<div
              class="muted"
              style="margin-top: 8px; color: ${i.kind==="error"?"var(--danger-color, #d14343)":"var(--success-color, #0a7f5a)"};"
            >
              ${i.message}
            </div>`:h}
        ${e.primaryEnv?l`
              <div class="field" style="margin-top: 10px;">
                <span>API 密钥</span>
                <input
                  type="password"
                  .value=${s}
                  @input=${c=>t.onEdit(e.skillKey,c.target.value)}
                />
              </div>
              <button
                class="btn primary"
                style="margin-top: 8px;"
                ?disabled=${n}
                @click=${()=>t.onSaveKey(e.skillKey)}
              >
                保存密钥
              </button>
            `:h}
      </div>
    </div>
  `}function Mh(e,t){const n=Ps(t,e.basePath);return l`
    <a
      href=${n}
      class="nav-item ${e.tab===t?"active":""}"
      @click=${s=>{s.defaultPrevented||s.button!==0||s.metaKey||s.ctrlKey||s.shiftKey||s.altKey||(s.preventDefault(),e.setTab(t))}}
      title=${is(t)}
    >
      <span class="nav-item__icon" aria-hidden="true">${G[vl(t)]}</span>
      <span class="nav-item__text">${is(t)}</span>
    </a>
  `}function Ih(e){const t=Lh(e.sessionKey,e.sessionsResult),n=e.onboarding,s=e.onboarding,i=e.onboarding?!1:e.settings.chatShowThinking,r=e.onboarding?!0:e.settings.chatFocusMode,a=l`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8"></path><path d="M21 3v5h-5"></path></svg>`,o=l`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7V4h3"></path><path d="M20 7V4h-3"></path><path d="M4 17v3h3"></path><path d="M20 17v3h-3"></path><circle cx="12" cy="12" r="3"></circle></svg>`;return l`
    <div class="chat-controls">
      <label class="field chat-controls__session">
        <select
          .value=${e.sessionKey}
          ?disabled=${!e.connected}
          @change=${c=>{const p=c.target.value;e.sessionKey=p,e.chatMessage="",e.chatStream=null,e.chatStreamStartedAt=null,e.chatRunId=null,e.resetToolStream(),e.resetChatScroll(),e.applySettings({...e.settings,sessionKey:p,lastActiveSessionKey:p}),e.loadAssistantIdentity(),vd(e,p),tt(e)}}
        >
          ${Ha(t,c=>c.key,c=>l`<option value=${c.key}>
                ${c.displayName??c.key}
              </option>`)}
        </select>
      </label>
      <button
        class="btn btn--sm btn--icon"
        ?disabled=${e.chatLoading||!e.connected}
        @click=${()=>{e.resetToolStream(),tt(e)}}
        title="刷新对话历史"
      >
        ${a}
      </button>
      <span class="chat-controls__separator">|</span>
      <button
        class="btn btn--sm btn--icon ${i?"active":""}"
        ?disabled=${n}
        @click=${()=>{n||e.applySettings({...e.settings,chatShowThinking:!e.settings.chatShowThinking})}}
        aria-pressed=${i}
        title=${n?"设置向导期间禁用":"切换智能体思考/工作输出"}
      >
        ${G.brain}
      </button>
      <button
        class="btn btn--sm btn--icon ${r?"active":""}"
        ?disabled=${s}
        @click=${()=>{s||e.applySettings({...e.settings,chatFocusMode:!e.settings.chatFocusMode})}}
        aria-pressed=${r}
        title=${s?"设置向导期间持用":"切换专注模式 (隐藏侧边栏和页眉)"}
      >
        ${o}
      </button>
    </div>
  `}function Lh(e,t){const n=new Set,s=[],i=t?.sessions?.find(r=>r.key===e);if(n.add(e),s.push({key:e,displayName:i?.displayName}),t?.sessions)for(const r of t.sessions)n.has(r.key)||(n.add(r.key),s.push({key:r.key,displayName:r.displayName}));return s}const Rh=["system","light","dark"];function Ph(e){const t=Math.max(0,Rh.indexOf(e.theme)),n=s=>i=>{const a={element:i.currentTarget};(i.clientX||i.clientY)&&(a.pointerClientX=i.clientX,a.pointerClientY=i.clientY),e.setTheme(s,a)};return l`
    <div class="theme-toggle" style="--theme-index: ${t};">
      <div class="theme-toggle__track" role="group" aria-label="主题切换">
        <span class="theme-toggle__indicator"></span>
        <button
          class="theme-toggle__button ${e.theme==="system"?"active":""}"
          @click=${n("system")}
          aria-pressed=${e.theme==="system"}
          aria-label="系统主题"
          title="自动"
        >
          ${Dh()}
        </button>
        <button
          class="theme-toggle__button ${e.theme==="light"?"active":""}"
          @click=${n("light")}
          aria-pressed=${e.theme==="light"}
          aria-label="浅色主题"
          title="浅色"
        >
          ${Nh()}
        </button>
        <button
          class="theme-toggle__button ${e.theme==="dark"?"active":""}"
          @click=${n("dark")}
          aria-pressed=${e.theme==="dark"}
          aria-label="深色主题"
          title="深色"
        >
          ${Oh()}
        </button>
      </div>
    </div>
  `}function Nh(){return l`
    <svg class="theme-icon" viewBox="0 0 24 24" aria-hidden="true">
      <circle cx="12" cy="12" r="4"></circle>
      <path d="M12 2v2"></path>
      <path d="M12 20v2"></path>
      <path d="m4.93 4.93 1.41 1.41"></path>
      <path d="m17.66 17.66 1.41 1.41"></path>
      <path d="M2 12h2"></path>
      <path d="M20 12h2"></path>
      <path d="m6.34 17.66-1.41 1.41"></path>
      <path d="m19.07 4.93-1.41 1.41"></path>
    </svg>
  `}function Oh(){return l`
    <svg class="theme-icon" viewBox="0 0 24 24" aria-hidden="true">
      <path
        d="M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401"
      ></path>
    </svg>
  `}function Dh(){return l`
    <svg class="theme-icon" viewBox="0 0 24 24" aria-hidden="true">
      <rect width="20" height="14" x="2" y="3" rx="2"></rect>
      <line x1="8" x2="16" y1="21" y2="21"></line>
      <line x1="12" x2="12" y1="17" y2="21"></line>
    </svg>
  `}const Bh=/^data:/i,Fh=/^https?:\/\//i;function Uh(e){const t=e.agentsList?.agents??[],s=ta(e.sessionKey)?.agentId??e.agentsList?.defaultId??"main",r=t.find(o=>o.id===s)?.identity,a=r?.avatarUrl??r?.avatar;if(a)return Bh.test(a)||Fh.test(a)?a:r?.avatarUrl}function Kh(e){const t=e.presenceEntries.length,n=e.sessionsResult?.count??null,s=e.cronStatus?.nextWakeAtMs??null,i=e.connected?null:"已断开与网关的连接。",r=e.tab==="chat",a=r&&(e.settings.chatFocusMode||e.onboarding),o=e.onboarding?!1:e.settings.chatShowThinking,c=Uh(e),p=e.chatAvatarUrl??c??null;return l`
    <div class="shell ${r?"shell--chat":""} ${a?"shell--chat-focus":""} ${e.settings.navCollapsed?"shell--nav-collapsed":""} ${e.onboarding?"shell--onboarding":""}">
      <header class="topbar">
        <div class="topbar-left">
          <button
            class="nav-collapse-toggle"
            @click=${()=>e.applySettings({...e.settings,navCollapsed:!e.settings.navCollapsed})}
            title="${e.settings.navCollapsed?"展开侧边栏":"折叠侧边栏"}"
            aria-label="${e.settings.navCollapsed?"展开侧边栏":"折叠侧边栏"}"
          >
            <span class="nav-collapse-toggle__icon">${G.menu}</span>
          </button>
          <div class="brand">
            <div class="brand-logo">
              <img src="https://mintcdn.com/clawdhub/4rYvG-uuZrMK_URE/assets/pixel-lobster.svg?fit=max&auto=format&n=4rYvG-uuZrMK_URE&q=85&s=da2032e9eac3b5d9bfe7eb96ca6a8a26" alt="Clawdbot" />
            </div>
            <div class="brand-text">
              <div class="brand-title">CLAWDBOT</div>
              <div class="brand-sub">网关控制面板</div>
            </div>
          </div>
        </div>
        <div class="topbar-status">
          <div class="pill">
            <span class="statusDot ${e.connected?"ok":""}"></span>
            <span>运行状态</span>
            <span class="mono">${e.connected?"良好":"离线"}</span>
          </div>
          ${Ph(e)}
        </div>
      </header>
      <aside class="nav ${e.settings.navCollapsed?"nav--collapsed":""}">
        ${hl.map(d=>{const u=e.settings.navGroupsCollapsed[d.label]??!1,v=d.tabs.some(g=>g===e.tab);return l`
            <div class="nav-group ${u&&!v?"nav-group--collapsed":""}">
              <button
                class="nav-label"
                @click=${()=>{const g={...e.settings.navGroupsCollapsed};g[d.label]=!u,e.applySettings({...e.settings,navGroupsCollapsed:g})}}
                aria-expanded=${!u}
              >
                <span class="nav-label__text">${d.label}</span>
                <span class="nav-label__chevron">${u?"+":"−"}</span>
              </button>
              <div class="nav-group__items">
                ${d.tabs.map(g=>Mh(e,g))}
              </div>
            </div>
          `})}
        <div class="nav-group nav-group--links">
          <div class="nav-label nav-label--static">
            <span class="nav-label__text">相关资源</span>
          </div>
          <div class="nav-group__items">
            <a
              class="nav-item nav-item--external"
              href="https://docs.clawd.bot"
              target="_blank"
              rel="noreferrer"
              title="查看文档（在新标签页中打开）"
            >
              <span class="nav-item__icon" aria-hidden="true">${G.book}</span>
              <span class="nav-item__text">官方文档</span>
            </a>
          </div>
        </div>
      </aside>
      <main class="content ${r?"content--chat":""}">
        <section class="content-header">
          <div>
            <div class="page-title">${is(e.tab)}</div>
            <div class="page-sub">${ml(e.tab)}</div>
          </div>
          <div class="page-meta">
            ${e.lastError?l`<div class="pill danger">${e.lastError}</div>`:h}
            ${r?Ih(e):h}
          </div>
        </section>

        ${e.tab==="overview"?hh({connected:e.connected,hello:e.hello,settings:e.settings,password:e.password,lastError:e.lastError,presenceCount:t,sessionsCount:n,cronEnabled:e.cronStatus?.enabled??null,cronNext:s,lastChannelsRefresh:e.channelsLastSuccess,onSettingsChange:d=>e.applySettings(d),onPasswordChange:d=>e.password=d,onSessionKeyChange:d=>{e.sessionKey=d,e.chatMessage="",e.resetToolStream(),e.applySettings({...e.settings,sessionKey:d,lastActiveSessionKey:d}),e.loadAssistantIdentity()},onConnect:()=>e.connect(),onRefresh:()=>e.loadOverview()}):h}

        ${e.tab==="channels"?hf({connected:e.connected,loading:e.channelsLoading,snapshot:e.channelsSnapshot,lastError:e.channelsError,lastSuccessAt:e.channelsLastSuccess,whatsappMessage:e.whatsappLoginMessage,whatsappQrDataUrl:e.whatsappLoginQrDataUrl,whatsappConnected:e.whatsappLoginConnected,whatsappBusy:e.whatsappBusy,configSchema:e.configSchema,configSchemaLoading:e.configSchemaLoading,configForm:e.configForm,configUiHints:e.configUiHints,configSaving:e.configSaving,configFormDirty:e.configFormDirty,nostrProfileFormState:e.nostrProfileFormState,nostrProfileAccountId:e.nostrProfileAccountId,onRefresh:d=>le(e,d),onWhatsAppStart:d=>e.handleWhatsAppStart(d),onWhatsAppWait:()=>e.handleWhatsAppWait(),onWhatsAppLogout:()=>e.handleWhatsAppLogout(),onConfigPatch:(d,u)=>bt(e,d,u),onConfigSave:()=>e.handleChannelConfigSave(),onConfigReload:()=>e.handleChannelConfigReload(),onNostrProfileEdit:(d,u)=>e.handleNostrProfileEdit(d,u),onNostrProfileCancel:()=>e.handleNostrProfileCancel(),onNostrProfileFieldChange:(d,u)=>e.handleNostrProfileFieldChange(d,u),onNostrProfileSave:()=>e.handleNostrProfileSave(),onNostrProfileImport:()=>e.handleNostrProfileImport(),onNostrProfileToggleAdvanced:()=>e.handleNostrProfileToggleAdvanced()}):h}

        ${e.tab==="instances"?Bf({loading:e.presenceLoading,entries:e.presenceEntries,lastError:e.presenceError,statusMessage:e.presenceStatus,onRefresh:()=>qs(e)}):h}

        ${e.tab==="sessions"?kh({loading:e.sessionsLoading,result:e.sessionsResult,error:e.sessionsError,activeMinutes:e.sessionsFilterActive,limit:e.sessionsFilterLimit,includeGlobal:e.sessionsIncludeGlobal,includeUnknown:e.sessionsIncludeUnknown,basePath:e.basePath,onFiltersChange:d=>{e.sessionsFilterActive=d.activeMinutes,e.sessionsFilterLimit=d.limit,e.sessionsIncludeGlobal=d.includeGlobal,e.sessionsIncludeUnknown=d.includeUnknown},onRefresh:()=>at(e),onPatch:(d,u)=>Ll(e,d,u),onDelete:d=>Rl(e,d)}):h}

        ${e.tab==="cron"?Rf({loading:e.cronLoading,status:e.cronStatus,jobs:e.cronJobs,error:e.cronError,busy:e.cronBusy,form:e.cronForm,channels:e.channelsSnapshot?.channelMeta?.length?e.channelsSnapshot.channelMeta.map(d=>d.id):e.channelsSnapshot?.channelOrder??[],channelLabels:e.channelsSnapshot?.channelLabels??{},channelMeta:e.channelsSnapshot?.channelMeta??[],runsJobId:e.cronRunsJobId,runs:e.cronRuns,onFormChange:d=>e.cronForm={...e.cronForm,...d},onRefresh:()=>e.loadCron(),onAdd:()=>nc(e),onToggle:(d,u)=>sc(e,d,u),onRun:d=>ic(e,d),onRemove:d=>rc(e,d),onLoadRuns:d=>pa(e,d)}):h}

        ${e.tab==="skills"?Eh({loading:e.skillsLoading,report:e.skillsReport,error:e.skillsError,filter:e.skillsFilter,edits:e.skillEdits,messages:e.skillMessages,busyKey:e.skillsBusyKey,onFilterChange:d=>e.skillsFilter=d,onRefresh:()=>It(e,{clearMessages:!0}),onToggle:(d,u)=>Jc(e,d,u),onEdit:(d,u)=>Xc(e,d,u),onSaveKey:d=>ed(e,d),onInstall:(d,u,v)=>td(e,d,u,v)}):h}

        ${e.tab==="nodes"?zf({loading:e.nodesLoading,nodes:e.nodes,devicesLoading:e.devicesLoading,devicesError:e.devicesError,devicesList:e.devicesList,configForm:e.configForm??e.configSnapshot?.config,configLoading:e.configLoading,configSaving:e.configSaving,configDirty:e.configFormDirty,configFormMode:e.configFormMode,execApprovalsLoading:e.execApprovalsLoading,execApprovalsSaving:e.execApprovalsSaving,execApprovalsDirty:e.execApprovalsDirty,execApprovalsSnapshot:e.execApprovalsSnapshot,execApprovalsForm:e.execApprovalsForm,execApprovalsSelectedAgent:e.execApprovalsSelectedAgent,execApprovalsTarget:e.execApprovalsTarget,execApprovalsTargetNodeId:e.execApprovalsTargetNodeId,onRefresh:()=>vn(e),onDevicesRefresh:()=>Ee(e),onDeviceApprove:d=>Hc(e,d),onDeviceReject:d=>zc(e,d),onDeviceRotate:(d,u,v)=>jc(e,{deviceId:d,role:u,scopes:v}),onDeviceRevoke:(d,u)=>qc(e,{deviceId:d,role:u}),onLoadConfig:()=>be(e),onLoadExecApprovals:()=>{const d=e.execApprovalsTarget==="node"&&e.execApprovalsTargetNodeId?{kind:"node",nodeId:e.execApprovalsTargetNodeId}:{kind:"gateway"};return js(e,d)},onBindDefault:d=>{d?bt(e,["tools","exec","node"],d):Xi(e,["tools","exec","node"])},onBindAgent:(d,u)=>{const v=["agents","list",d,"tools","exec","node"];u?bt(e,v,u):Xi(e,v)},onSaveBindings:()=>cs(e),onExecApprovalsTargetChange:(d,u)=>{e.execApprovalsTarget=d,e.execApprovalsTargetNodeId=u,e.execApprovalsSnapshot=null,e.execApprovalsForm=null,e.execApprovalsDirty=!1,e.execApprovalsSelectedAgent=null},onExecApprovalsSelectAgent:d=>{e.execApprovalsSelectedAgent=d},onExecApprovalsPatch:(d,u)=>Zc(e,d,u),onExecApprovalsRemove:d=>Yc(e,d),onSaveExecApprovals:()=>{const d=e.execApprovalsTarget==="node"&&e.execApprovalsTargetNodeId?{kind:"node",nodeId:e.execApprovalsTargetNodeId}:{kind:"gateway"};return Qc(e,d)}}):h}

        ${e.tab==="chat"?Mp({sessionKey:e.sessionKey,onSessionKeyChange:d=>{e.sessionKey=d,e.chatMessage="",e.chatAttachments=[],e.chatStream=null,e.chatStreamStartedAt=null,e.chatRunId=null,e.chatQueue=[],e.resetToolStream(),e.resetChatScroll(),e.applySettings({...e.settings,sessionKey:d,lastActiveSessionKey:d}),e.loadAssistantIdentity(),tt(e),hs(e)},thinkingLevel:e.chatThinkingLevel,showThinking:o,loading:e.chatLoading,sending:e.chatSending,compactionStatus:e.compactionStatus,assistantAvatarUrl:p,messages:e.chatMessages,toolMessages:e.chatToolMessages,stream:e.chatStream,streamStartedAt:e.chatStreamStartedAt,draft:e.chatMessage,queue:e.chatQueue,connected:e.connected,canSend:e.connected,disabledReason:i,error:e.lastError,sessions:e.sessionsResult,focusMode:a,onRefresh:()=>(e.resetToolStream(),Promise.all([tt(e),hs(e)])),onToggleFocusMode:()=>{e.onboarding||e.applySettings({...e.settings,chatFocusMode:!e.settings.chatFocusMode})},onChatScroll:d=>e.handleChatScroll(d),onDraftChange:d=>e.chatMessage=d,attachments:e.chatAttachments,onAttachmentsChange:d=>e.chatAttachments=d,onSend:()=>e.handleSendChat(),canAbort:!!e.chatRunId,onAbort:()=>{e.handleAbortChat()},onQueueRemove:d=>e.removeQueuedMessage(d),onNewSession:()=>e.handleSendChat("/new",{restoreDraft:!0}),sidebarOpen:e.sidebarOpen,sidebarContent:e.sidebarContent,sidebarError:e.sidebarError,splitRatio:e.splitRatio,onOpenSidebar:d=>e.handleOpenSidebar(d),onCloseSidebar:()=>e.handleCloseSidebar(),onSplitRatioChange:d=>e.handleSplitRatioChange(d),assistantName:e.assistantName,assistantAvatar:e.assistantAvatar}):h}

        ${e.tab==="config"?Qp({raw:e.configRaw,originalRaw:e.configRawOriginal,valid:e.configValid,issues:e.configIssues,loading:e.configLoading,saving:e.configSaving,applying:e.configApplying,updating:e.updateRunning,connected:e.connected,schema:e.configSchema,schemaLoading:e.configSchemaLoading,uiHints:e.configUiHints,formMode:e.configFormMode,formValue:e.configForm,originalValue:e.configFormOriginal,searchQuery:e.configSearchQuery,activeSection:e.configActiveSection,activeSubsection:e.configActiveSubsection,onRawChange:d=>{e.configRaw=d},onFormModeChange:d=>e.configFormMode=d,onFormPatch:(d,u)=>bt(e,d,u),onSearchChange:d=>e.configSearchQuery=d,onSectionChange:d=>{e.configActiveSection=d,e.configActiveSubsection=null},onSubsectionChange:d=>e.configActiveSubsection=d,onReload:()=>be(e),onSave:()=>cs(e),onApply:()=>Yl(e),onUpdate:()=>Xl(e),onDiscoverModels:d=>e.handleDiscoverModels(d)}):h}

        ${e.tab==="debug"?Df({loading:e.debugLoading,status:e.debugStatus,health:e.debugHealth,models:e.debugModels,heartbeat:e.debugHeartbeat,eventLog:e.eventLog,callMethod:e.debugCallMethod,callParams:e.debugCallParams,callResult:e.debugCallResult,callError:e.debugCallError,onCallMethodChange:d=>e.debugCallMethod=d,onCallParamsChange:d=>e.debugCallParams=d,onRefresh:()=>hn(e),onCall:()=>cc(e)}):h}

        ${e.tab==="logs"?Hf({loading:e.logsLoading,error:e.logsError,file:e.logsFile,entries:e.logsEntries,filterText:e.logsFilterText,levelFilters:e.logsLevelFilters,autoFollow:e.logsAutoFollow,truncated:e.logsTruncated,onFilterTextChange:d=>e.logsFilterText=d,onLevelToggle:(d,u)=>{e.logsLevelFilters={...e.logsLevelFilters,[d]:u}},onToggleAutoFollow:d=>e.logsAutoFollow=d,onRefresh:()=>Ds(e,{reset:!0}),onExport:(d,u)=>e.exportLogs(d,u),onScroll:d=>e.handleLogsScroll(d)}):h}
      </main>
      ${Th(e)}
    </div>
  `}const Hh={trace:!0,debug:!0,info:!0,warn:!0,error:!0,fatal:!0},zh={name:"",description:"",agentId:"",enabled:!0,scheduleKind:"every",scheduleAt:"",everyAmount:"30",everyUnit:"minutes",cronExpr:"0 7 * * *",cronTz:"",sessionTarget:"main",wakeMode:"next-heartbeat",payloadKind:"systemEvent",payloadText:"",deliver:!1,channel:"last",to:"",timeoutSeconds:"",postToMainPrefix:""};async function jh(e){if(!(!e.client||!e.connected)&&!e.agentsLoading){e.agentsLoading=!0,e.agentsError=null;try{const t=await e.client.request("agents.list",{});t&&(e.agentsList=t)}catch(t){e.agentsError=String(t)}finally{e.agentsLoading=!1}}}const yo={WEBCHAT_UI:"webchat-ui",CONTROL_UI:"clawdbot-control-ui",WEBCHAT:"webchat",CLI:"cli",GATEWAY_CLIENT:"gateway-client",MACOS_APP:"clawdbot-macos",IOS_APP:"clawdbot-ios",ANDROID_APP:"clawdbot-android",NODE_HOST:"node-host",TEST:"test",FINGERPRINT:"fingerprint",PROBE:"clawdbot-probe"},jr=yo,_s={WEBCHAT:"webchat",CLI:"cli",UI:"ui",BACKEND:"backend",NODE:"node",PROBE:"probe",TEST:"test"};new Set(Object.values(yo));new Set(Object.values(_s));function qh(e){const t=e.version??(e.nonce?"v2":"v1"),n=e.scopes.join(","),s=e.token??"",i=[t,e.deviceId,e.clientId,e.clientMode,e.role,n,String(e.signedAtMs),s];return t==="v2"&&i.push(e.nonce??""),i.join("|")}const Vh=4008;class Wh{constructor(t){this.opts=t,this.ws=null,this.pending=new Map,this.closed=!1,this.lastSeq=null,this.connectNonce=null,this.connectSent=!1,this.connectTimer=null,this.backoffMs=800}start(){this.closed=!1,this.connect()}stop(){this.closed=!0,this.ws?.close(),this.ws=null,this.flushPending(new Error("gateway client stopped"))}get connected(){return this.ws?.readyState===WebSocket.OPEN}connect(){this.closed||(this.ws=new WebSocket(this.opts.url),this.ws.onopen=()=>this.queueConnect(),this.ws.onmessage=t=>this.handleMessage(String(t.data??"")),this.ws.onclose=t=>{const n=String(t.reason??"");this.ws=null,this.flushPending(new Error(`gateway closed (${t.code}): ${n}`)),this.opts.onClose?.({code:t.code,reason:n}),this.scheduleReconnect()},this.ws.onerror=()=>{})}scheduleReconnect(){if(this.closed)return;const t=this.backoffMs;this.backoffMs=Math.min(this.backoffMs*1.7,15e3),window.setTimeout(()=>this.connect(),t)}flushPending(t){for(const[,n]of this.pending)n.reject(t);this.pending.clear()}async sendConnect(){if(this.connectSent)return;this.connectSent=!0,this.connectTimer!==null&&(window.clearTimeout(this.connectTimer),this.connectTimer=null);const t=typeof crypto<"u"&&!!crypto.subtle,n=["operator.admin","operator.approvals","operator.pairing"],s="operator";let i=null,r=!1,a=this.opts.token;if(t){i=await Ks();const d=Kc({deviceId:i.deviceId,role:s})?.token;a=d??this.opts.token,r=!!(d&&this.opts.token)}const o=a||this.opts.password?{token:a,password:this.opts.password}:void 0;let c;if(t&&i){const d=Date.now(),u=this.connectNonce??void 0,v=qh({deviceId:i.deviceId,clientId:this.opts.clientName??jr.CONTROL_UI,clientMode:this.opts.mode??_s.WEBCHAT,role:s,scopes:n,signedAtMs:d,token:a??null,nonce:u}),g=await Fc(i.privateKey,v);c={id:i.deviceId,publicKey:i.publicKey,signature:g,signedAt:d,nonce:u}}const p={minProtocol:3,maxProtocol:3,client:{id:this.opts.clientName??jr.CONTROL_UI,version:this.opts.clientVersion??"dev",platform:this.opts.platform??navigator.platform??"web",mode:this.opts.mode??_s.WEBCHAT,instanceId:this.opts.instanceId},role:s,scopes:n,device:c,caps:[],auth:o,userAgent:navigator.userAgent,locale:navigator.language};this.request("connect",p).then(d=>{d?.auth?.deviceToken&&i&&Ca({deviceId:i.deviceId,role:d.auth.role??s,token:d.auth.deviceToken,scopes:d.auth.scopes??[]}),this.backoffMs=800,this.opts.onHello?.(d)}).catch(()=>{r&&i&&Ma({deviceId:i.deviceId,role:s}),this.ws?.close(Vh,"connect failed")})}handleMessage(t){let n;try{n=JSON.parse(t)}catch{return}const s=n;if(s.type==="event"){const i=n;if(i.event==="connect.challenge"){const a=i.payload,o=a&&typeof a.nonce=="string"?a.nonce:null;o&&(this.connectNonce=o,this.sendConnect());return}const r=typeof i.seq=="number"?i.seq:null;r!==null&&(this.lastSeq!==null&&r>this.lastSeq+1&&this.opts.onGap?.({expected:this.lastSeq+1,received:r}),this.lastSeq=r);try{this.opts.onEvent?.(i)}catch(a){console.error("[gateway] event handler error:",a)}return}if(s.type==="res"){const i=n,r=this.pending.get(i.id);if(!r)return;this.pending.delete(i.id),i.ok?r.resolve(i.payload):r.reject(new Error(i.error?.message??"request failed"));return}}request(t,n){if(!this.ws||this.ws.readyState!==WebSocket.OPEN)return Promise.reject(new Error("gateway not connected"));const s=Ns(),i={type:"req",id:s,method:t,params:n},r=new Promise((a,o)=>{this.pending.set(s,{resolve:c=>a(c),reject:o})});return this.ws.send(JSON.stringify(i)),r}queueConnect(){this.connectNonce=null,this.connectSent=!1,this.connectTimer!==null&&window.clearTimeout(this.connectTimer),this.connectTimer=window.setTimeout(()=>{this.sendConnect()},750)}}function Ts(e){return typeof e=="object"&&e!==null}function Gh(e){if(!Ts(e))return null;const t=typeof e.id=="string"?e.id.trim():"",n=e.request;if(!t||!Ts(n))return null;const s=typeof n.command=="string"?n.command.trim():"";if(!s)return null;const i=typeof e.createdAtMs=="number"?e.createdAtMs:0,r=typeof e.expiresAtMs=="number"?e.expiresAtMs:0;return!i||!r?null:{id:t,request:{command:s,cwd:typeof n.cwd=="string"?n.cwd:null,host:typeof n.host=="string"?n.host:null,security:typeof n.security=="string"?n.security:null,ask:typeof n.ask=="string"?n.ask:null,agentId:typeof n.agentId=="string"?n.agentId:null,resolvedPath:typeof n.resolvedPath=="string"?n.resolvedPath:null,sessionKey:typeof n.sessionKey=="string"?n.sessionKey:null},createdAtMs:i,expiresAtMs:r}}function Qh(e){if(!Ts(e))return null;const t=typeof e.id=="string"?e.id.trim():"";return t?{id:t,decision:typeof e.decision=="string"?e.decision:null,resolvedBy:typeof e.resolvedBy=="string"?e.resolvedBy:null,ts:typeof e.ts=="number"?e.ts:null}:null}function bo(e){const t=Date.now();return e.filter(n=>n.expiresAtMs>t)}function Zh(e,t){const n=bo(e).filter(s=>s.id!==t.id);return n.push(t),n}function qr(e,t){return bo(e).filter(n=>n.id!==t)}async function $o(e,t){if(!e.client||!e.connected)return;const n=e.sessionKey.trim(),s=n?{sessionKey:n}:{};try{const i=await e.client.request("agent.identity.get",s);if(!i)return;const r=ss(i);e.assistantName=r.name,e.assistantAvatar=r.avatar,e.assistantAgentId=r.agentId??null}catch{}}function es(e,t){const n=(e??"").trim(),s=t.mainSessionKey?.trim();if(!s)return n;if(!n)return s;const i=t.mainKey?.trim()||"main",r=t.defaultAgentId?.trim();return n==="main"||n===i||r&&(n===`agent:${r}:main`||n===`agent:${r}:${i}`)?s:n}function Yh(e,t){if(!t?.mainSessionKey)return;const n=es(e.sessionKey,t),s=es(e.settings.sessionKey,t),i=es(e.settings.lastActiveSessionKey,t),r=n||s||e.sessionKey,a={...e.settings,sessionKey:s||r,lastActiveSessionKey:i||r},o=a.sessionKey!==e.settings.sessionKey||a.lastActiveSessionKey!==e.settings.lastActiveSessionKey;r!==e.sessionKey&&(e.sessionKey=r),o&&ke(e,a)}function wo(e){e.lastError=null,e.hello=null,e.connected=!1,e.execApprovalQueue=[],e.execApprovalError=null,e.client?.stop(),e.client=new Wh({url:e.settings.gatewayUrl,token:e.settings.token.trim()?e.settings.token:void 0,password:e.password.trim()?e.password:void 0,clientName:"clawdbot-control-ui",mode:"webchat",onHello:t=>{e.connected=!0,e.lastError=null,e.hello=t,eg(e,t),$o(e),jh(e),vn(e,{quiet:!0}),Ee(e,{quiet:!0}),Ys(e)},onClose:({code:t,reason:n})=>{e.connected=!1,t!==1012&&(e.lastError=`disconnected (${t}): ${n||"no reason"}`)},onEvent:t=>Xh(e,t),onGap:({expected:t,received:n})=>{e.lastError=`event gap detected (expected seq ${t}, got ${n}); refresh recommended`}}),e.client.start()}function Xh(e,t){try{Jh(e,t)}catch(n){console.error("[gateway] handleGatewayEvent error:",t.event,n)}}function Jh(e,t){if(e.eventLogBuffer=[{ts:Date.now(),event:t.event,payload:t.payload},...e.eventLogBuffer].slice(0,250),e.tab==="debug"&&(e.eventLog=e.eventLogBuffer),t.event==="agent"){if(e.onboarding)return;zl(e,t.payload);return}if(t.event==="chat"){const n=t.payload;n?.sessionKey&&Ia(e,n.sessionKey);const s=Il(e,n);(s==="final"||s==="error"||s==="aborted")&&(Os(e),Ad(e)),s==="final"&&tt(e);return}if(t.event==="presence"){const n=t.payload;n?.presence&&Array.isArray(n.presence)&&(e.presenceEntries=n.presence,e.presenceError=null,e.presenceStatus=null);return}if(t.event==="cron"&&e.tab==="cron"&&Xs(e),(t.event==="device.pair.requested"||t.event==="device.pair.resolved")&&Ee(e,{quiet:!0}),t.event==="exec.approval.requested"){const n=Gh(t.payload);if(n){e.execApprovalQueue=Zh(e.execApprovalQueue,n),e.execApprovalError=null;const s=Math.max(0,n.expiresAtMs-Date.now()+500);window.setTimeout(()=>{e.execApprovalQueue=qr(e.execApprovalQueue,n.id)},s)}return}if(t.event==="exec.approval.resolved"){const n=Qh(t.payload);n&&(e.execApprovalQueue=qr(e.execApprovalQueue,n.id))}}function eg(e,t){const n=t.snapshot;n?.presence&&Array.isArray(n.presence)&&(e.presenceEntries=n.presence),n?.health&&(e.debugHealth=n.health),n?.sessionDefaults&&Yh(e,n.sessionDefaults)}function tg(e){e.basePath=dd(),hd(e,!0),ud(e),pd(e),window.addEventListener("popstate",e.popStateHandler),od(e),wo(e),rd(e),e.tab==="logs"&&Ws(e),e.tab==="debug"&&Qs(e)}function ng(e){Gl(e)}function sg(e){window.removeEventListener("popstate",e.popStateHandler),ad(e),Gs(e),Zs(e),fd(e),e.topbarObserver?.disconnect(),e.topbarObserver=null}function ig(e,t){if(e.tab==="chat"&&(t.has("chatMessages")||t.has("chatToolMessages")||t.has("chatStream")||t.has("chatLoading")||t.has("tab"))){const n=t.has("tab"),s=t.has("chatLoading")&&t.get("chatLoading")===!0&&e.chatLoading===!1;pn(e,n||s||!e.chatHasAutoScrolled)}e.tab==="logs"&&(t.has("logsEntries")||t.has("logsAutoFollow")||t.has("tab"))&&e.logsAutoFollow&&e.logsAtBottom&&la(e,t.has("tab")||t.has("logsAutoFollow"))}async function rg(e,t){await ac(e,t),await le(e,!0)}async function ag(e){await oc(e),await le(e,!0)}async function og(e){await lc(e),await le(e,!0)}async function lg(e){await cs(e),await be(e),await le(e,!0)}async function cg(e){await be(e),await le(e,!0)}function dg(e){if(!Array.isArray(e))return{};const t={};for(const n of e){if(typeof n!="string")continue;const[s,...i]=n.split(":");if(!s||i.length===0)continue;const r=s.trim(),a=i.join(":").trim();r&&a&&(t[r]=a)}return t}function xo(e){return(e.channelsSnapshot?.channelAccounts?.nostr??[])[0]?.accountId??e.nostrProfileAccountId??"default"}function Ao(e,t=""){return`/api/channels/nostr/${encodeURIComponent(e)}/profile${t}`}function ug(e,t,n){e.nostrProfileAccountId=t,e.nostrProfileFormState=lf(n??void 0)}function pg(e){e.nostrProfileFormState=null,e.nostrProfileAccountId=null}function fg(e,t,n){const s=e.nostrProfileFormState;s&&(e.nostrProfileFormState={...s,values:{...s.values,[t]:n},fieldErrors:{...s.fieldErrors,[t]:""}})}function hg(e){const t=e.nostrProfileFormState;t&&(e.nostrProfileFormState={...t,showAdvanced:!t.showAdvanced})}async function gg(e){const t=e.nostrProfileFormState;if(!t||t.saving)return;const n=xo(e);e.nostrProfileFormState={...t,saving:!0,error:null,success:null,fieldErrors:{}};try{const s=await fetch(Ao(n),{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(t.values)}),i=await s.json().catch(()=>null);if(!s.ok||i?.ok===!1||!i){const r=i?.error??`Profile update failed (${s.status})`;e.nostrProfileFormState={...t,saving:!1,error:r,success:null,fieldErrors:dg(i?.details)};return}if(!i.persisted){e.nostrProfileFormState={...t,saving:!1,error:"Profile publish failed on all relays.",success:null};return}e.nostrProfileFormState={...t,saving:!1,error:null,success:"Profile published to relays.",fieldErrors:{},original:{...t.values}},await le(e,!0)}catch(s){e.nostrProfileFormState={...t,saving:!1,error:`Profile update failed: ${String(s)}`,success:null}}}async function vg(e){const t=e.nostrProfileFormState;if(!t||t.importing)return;const n=xo(e);e.nostrProfileFormState={...t,importing:!0,error:null,success:null};try{const s=await fetch(Ao(n,"/import"),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({autoMerge:!0})}),i=await s.json().catch(()=>null);if(!s.ok||i?.ok===!1||!i){const c=i?.error??`Profile import failed (${s.status})`;e.nostrProfileFormState={...t,importing:!1,error:c,success:null};return}const r=i.merged??i.imported??null,a=r?{...t.values,...r}:t.values,o=!!(a.banner||a.website||a.nip05||a.lud16);e.nostrProfileFormState={...t,importing:!1,values:a,error:null,success:i.saved?"Profile imported from relays. Review and publish.":"Profile imported. Review and publish.",showAdvanced:o},i.saved&&await le(e,!0)}catch(s){e.nostrProfileFormState={...t,importing:!1,error:`Profile import failed: ${String(s)}`,success:null}}}var mg=Object.defineProperty,yg=Object.getOwnPropertyDescriptor,b=(e,t,n,s)=>{for(var i=s>1?void 0:s?yg(t,n):t,r=e.length-1,a;r>=0;r--)(a=e[r])&&(i=(s?a(t,n,i):a(i))||i);return s&&i&&mg(t,n,i),i};const ts=ul();function bg(){if(!window.location.search)return!1;const t=new URLSearchParams(window.location.search).get("onboarding");if(!t)return!1;const n=t.trim().toLowerCase();return n==="1"||n==="true"||n==="yes"||n==="on"}let m=class extends Je{constructor(){super(...arguments),this.settings=pl(),this.password="",this.tab="chat",this.onboarding=bg(),this.connected=!1,this.theme=this.settings.theme??"system",this.themeResolved="dark",this.hello=null,this.lastError=null,this.eventLog=[],this.eventLogBuffer=[],this.toolStreamSyncTimer=null,this.sidebarCloseTimer=null,this.assistantName=ts.name,this.assistantAvatar=ts.avatar,this.assistantAgentId=ts.agentId??null,this.sessionKey=this.settings.sessionKey,this.chatLoading=!1,this.chatSending=!1,this.chatMessage="",this.chatMessages=[],this.chatToolMessages=[],this.chatStream=null,this.chatStreamStartedAt=null,this.chatRunId=null,this.compactionStatus=null,this.chatAvatarUrl=null,this.chatThinkingLevel=null,this.chatQueue=[],this.chatAttachments=[],this.sidebarOpen=!1,this.sidebarContent=null,this.sidebarError=null,this.splitRatio=this.settings.splitRatio,this.nodesLoading=!1,this.nodes=[],this.devicesLoading=!1,this.devicesError=null,this.devicesList=null,this.execApprovalsLoading=!1,this.execApprovalsSaving=!1,this.execApprovalsDirty=!1,this.execApprovalsSnapshot=null,this.execApprovalsForm=null,this.execApprovalsSelectedAgent=null,this.execApprovalsTarget="gateway",this.execApprovalsTargetNodeId=null,this.execApprovalQueue=[],this.execApprovalBusy=!1,this.execApprovalError=null,this.configLoading=!1,this.configRaw=`{
}
`,this.configRawOriginal="",this.configValid=null,this.configIssues=[],this.configSaving=!1,this.configApplying=!1,this.updateRunning=!1,this.applySessionKey=this.settings.lastActiveSessionKey,this.configSnapshot=null,this.configSchema=null,this.configSchemaVersion=null,this.configSchemaLoading=!1,this.configUiHints={},this.configForm=null,this.configFormOriginal=null,this.configFormDirty=!1,this.configFormMode="form",this.configSearchQuery="",this.configActiveSection=null,this.configActiveSubsection=null,this.channelsLoading=!1,this.channelsSnapshot=null,this.channelsError=null,this.channelsLastSuccess=null,this.whatsappLoginMessage=null,this.whatsappLoginQrDataUrl=null,this.whatsappLoginConnected=null,this.whatsappBusy=!1,this.nostrProfileFormState=null,this.nostrProfileAccountId=null,this.presenceLoading=!1,this.presenceEntries=[],this.presenceError=null,this.presenceStatus=null,this.agentsLoading=!1,this.agentsList=null,this.agentsError=null,this.sessionsLoading=!1,this.sessionsResult=null,this.sessionsError=null,this.sessionsFilterActive="",this.sessionsFilterLimit="120",this.sessionsIncludeGlobal=!0,this.sessionsIncludeUnknown=!1,this.cronLoading=!1,this.cronJobs=[],this.cronStatus=null,this.cronError=null,this.cronForm={...zh},this.cronRunsJobId=null,this.cronRuns=[],this.cronBusy=!1,this.skillsLoading=!1,this.skillsReport=null,this.skillsError=null,this.skillsFilter="",this.skillEdits={},this.skillsBusyKey=null,this.skillMessages={},this.debugLoading=!1,this.debugStatus=null,this.debugHealth=null,this.debugModels=[],this.debugHeartbeat=null,this.debugCallMethod="",this.debugCallParams="{}",this.debugCallResult=null,this.debugCallError=null,this.logsLoading=!1,this.logsError=null,this.logsFile=null,this.logsEntries=[],this.logsFilterText="",this.logsLevelFilters={...Hh},this.logsAutoFollow=!0,this.logsTruncated=!1,this.logsCursor=null,this.logsLastFetchAt=null,this.logsLimit=500,this.logsMaxBytes=25e4,this.logsAtBottom=!0,this.client=null,this.chatScrollFrame=null,this.chatScrollTimeout=null,this.chatHasAutoScrolled=!1,this.chatUserNearBottom=!0,this.nodesPollInterval=null,this.logsPollInterval=null,this.debugPollInterval=null,this.logsScrollFrame=null,this.toolStreamById=new Map,this.toolStreamOrder=[],this.basePath="",this.popStateHandler=()=>gd(this),this.themeMedia=null,this.themeMediaHandler=null,this.topbarObserver=null}createRenderRoot(){return this}connectedCallback(){super.connectedCallback(),tg(this)}firstUpdated(){ng(this)}disconnectedCallback(){sg(this),super.disconnectedCallback()}updated(e){ig(this,e)}connect(){wo(this)}handleChatScroll(e){jl(this,e)}handleLogsScroll(e){ql(this,e)}exportLogs(e,t){Wl(e,t)}resetToolStream(){Os(this)}resetChatScroll(){Vl(this)}async loadAssistantIdentity(){await $o(this)}applySettings(e){ke(this,e)}setTab(e){ld(this,e)}setTheme(e,t){cd(this,e,t)}async loadOverview(){await Pa(this)}async loadCron(){await Xs(this)}async handleAbortChat(){await Oa(this)}removeQueuedMessage(e){$d(this,e)}async handleSendChat(e,t){await wd(this,e,t)}async handleWhatsAppStart(e){await rg(this,e)}async handleWhatsAppWait(){await ag(this)}async handleWhatsAppLogout(){await og(this)}async handleChannelConfigSave(){await lg(this)}async handleChannelConfigReload(){await cg(this)}handleNostrProfileEdit(e,t){ug(this,e,t)}handleNostrProfileCancel(){pg(this)}handleNostrProfileFieldChange(e,t){fg(this,e,t)}async handleNostrProfileSave(){await gg(this)}async handleNostrProfileImport(){await vg(this)}handleNostrProfileToggleAdvanced(){hg(this)}async handleExecApprovalDecision(e){const t=this.execApprovalQueue[0];if(!(!t||!this.client||this.execApprovalBusy)){this.execApprovalBusy=!0,this.execApprovalError=null;try{await this.client.request("exec.approval.resolve",{id:t.id,decision:e}),this.execApprovalQueue=this.execApprovalQueue.filter(n=>n.id!==t.id)}catch(n){this.execApprovalError=`Exec approval failed: ${String(n)}`}finally{this.execApprovalBusy=!1}}}async handleDiscoverModels(e){if(!this.client)return;(await Jl(this,e))?.success}handleOpenSidebar(e){this.sidebarCloseTimer!=null&&(window.clearTimeout(this.sidebarCloseTimer),this.sidebarCloseTimer=null),this.sidebarContent=e,this.sidebarError=null,this.sidebarOpen=!0}handleCloseSidebar(){this.sidebarOpen=!1,this.sidebarCloseTimer!=null&&window.clearTimeout(this.sidebarCloseTimer),this.sidebarCloseTimer=window.setTimeout(()=>{this.sidebarOpen||(this.sidebarContent=null,this.sidebarError=null,this.sidebarCloseTimer=null)},200)}handleSplitRatioChange(e){const t=Math.max(.4,Math.min(.7,e));this.splitRatio=t,this.applySettings({...this.settings,splitRatio:t})}render(){return Kh(this)}};b([$()],m.prototype,"settings",2);b([$()],m.prototype,"password",2);b([$()],m.prototype,"tab",2);b([$()],m.prototype,"onboarding",2);b([$()],m.prototype,"connected",2);b([$()],m.prototype,"theme",2);b([$()],m.prototype,"themeResolved",2);b([$()],m.prototype,"hello",2);b([$()],m.prototype,"lastError",2);b([$()],m.prototype,"eventLog",2);b([$()],m.prototype,"assistantName",2);b([$()],m.prototype,"assistantAvatar",2);b([$()],m.prototype,"assistantAgentId",2);b([$()],m.prototype,"sessionKey",2);b([$()],m.prototype,"chatLoading",2);b([$()],m.prototype,"chatSending",2);b([$()],m.prototype,"chatMessage",2);b([$()],m.prototype,"chatMessages",2);b([$()],m.prototype,"chatToolMessages",2);b([$()],m.prototype,"chatStream",2);b([$()],m.prototype,"chatStreamStartedAt",2);b([$()],m.prototype,"chatRunId",2);b([$()],m.prototype,"compactionStatus",2);b([$()],m.prototype,"chatAvatarUrl",2);b([$()],m.prototype,"chatThinkingLevel",2);b([$()],m.prototype,"chatQueue",2);b([$()],m.prototype,"chatAttachments",2);b([$()],m.prototype,"sidebarOpen",2);b([$()],m.prototype,"sidebarContent",2);b([$()],m.prototype,"sidebarError",2);b([$()],m.prototype,"splitRatio",2);b([$()],m.prototype,"nodesLoading",2);b([$()],m.prototype,"nodes",2);b([$()],m.prototype,"devicesLoading",2);b([$()],m.prototype,"devicesError",2);b([$()],m.prototype,"devicesList",2);b([$()],m.prototype,"execApprovalsLoading",2);b([$()],m.prototype,"execApprovalsSaving",2);b([$()],m.prototype,"execApprovalsDirty",2);b([$()],m.prototype,"execApprovalsSnapshot",2);b([$()],m.prototype,"execApprovalsForm",2);b([$()],m.prototype,"execApprovalsSelectedAgent",2);b([$()],m.prototype,"execApprovalsTarget",2);b([$()],m.prototype,"execApprovalsTargetNodeId",2);b([$()],m.prototype,"execApprovalQueue",2);b([$()],m.prototype,"execApprovalBusy",2);b([$()],m.prototype,"execApprovalError",2);b([$()],m.prototype,"configLoading",2);b([$()],m.prototype,"configRaw",2);b([$()],m.prototype,"configRawOriginal",2);b([$()],m.prototype,"configValid",2);b([$()],m.prototype,"configIssues",2);b([$()],m.prototype,"configSaving",2);b([$()],m.prototype,"configApplying",2);b([$()],m.prototype,"updateRunning",2);b([$()],m.prototype,"applySessionKey",2);b([$()],m.prototype,"configSnapshot",2);b([$()],m.prototype,"configSchema",2);b([$()],m.prototype,"configSchemaVersion",2);b([$()],m.prototype,"configSchemaLoading",2);b([$()],m.prototype,"configUiHints",2);b([$()],m.prototype,"configForm",2);b([$()],m.prototype,"configFormOriginal",2);b([$()],m.prototype,"configFormDirty",2);b([$()],m.prototype,"configFormMode",2);b([$()],m.prototype,"configSearchQuery",2);b([$()],m.prototype,"configActiveSection",2);b([$()],m.prototype,"configActiveSubsection",2);b([$()],m.prototype,"channelsLoading",2);b([$()],m.prototype,"channelsSnapshot",2);b([$()],m.prototype,"channelsError",2);b([$()],m.prototype,"channelsLastSuccess",2);b([$()],m.prototype,"whatsappLoginMessage",2);b([$()],m.prototype,"whatsappLoginQrDataUrl",2);b([$()],m.prototype,"whatsappLoginConnected",2);b([$()],m.prototype,"whatsappBusy",2);b([$()],m.prototype,"nostrProfileFormState",2);b([$()],m.prototype,"nostrProfileAccountId",2);b([$()],m.prototype,"presenceLoading",2);b([$()],m.prototype,"presenceEntries",2);b([$()],m.prototype,"presenceError",2);b([$()],m.prototype,"presenceStatus",2);b([$()],m.prototype,"agentsLoading",2);b([$()],m.prototype,"agentsList",2);b([$()],m.prototype,"agentsError",2);b([$()],m.prototype,"sessionsLoading",2);b([$()],m.prototype,"sessionsResult",2);b([$()],m.prototype,"sessionsError",2);b([$()],m.prototype,"sessionsFilterActive",2);b([$()],m.prototype,"sessionsFilterLimit",2);b([$()],m.prototype,"sessionsIncludeGlobal",2);b([$()],m.prototype,"sessionsIncludeUnknown",2);b([$()],m.prototype,"cronLoading",2);b([$()],m.prototype,"cronJobs",2);b([$()],m.prototype,"cronStatus",2);b([$()],m.prototype,"cronError",2);b([$()],m.prototype,"cronForm",2);b([$()],m.prototype,"cronRunsJobId",2);b([$()],m.prototype,"cronRuns",2);b([$()],m.prototype,"cronBusy",2);b([$()],m.prototype,"skillsLoading",2);b([$()],m.prototype,"skillsReport",2);b([$()],m.prototype,"skillsError",2);b([$()],m.prototype,"skillsFilter",2);b([$()],m.prototype,"skillEdits",2);b([$()],m.prototype,"skillsBusyKey",2);b([$()],m.prototype,"skillMessages",2);b([$()],m.prototype,"debugLoading",2);b([$()],m.prototype,"debugStatus",2);b([$()],m.prototype,"debugHealth",2);b([$()],m.prototype,"debugModels",2);b([$()],m.prototype,"debugHeartbeat",2);b([$()],m.prototype,"debugCallMethod",2);b([$()],m.prototype,"debugCallParams",2);b([$()],m.prototype,"debugCallResult",2);b([$()],m.prototype,"debugCallError",2);b([$()],m.prototype,"logsLoading",2);b([$()],m.prototype,"logsError",2);b([$()],m.prototype,"logsFile",2);b([$()],m.prototype,"logsEntries",2);b([$()],m.prototype,"logsFilterText",2);b([$()],m.prototype,"logsLevelFilters",2);b([$()],m.prototype,"logsAutoFollow",2);b([$()],m.prototype,"logsTruncated",2);b([$()],m.prototype,"logsCursor",2);b([$()],m.prototype,"logsLastFetchAt",2);b([$()],m.prototype,"logsLimit",2);b([$()],m.prototype,"logsMaxBytes",2);b([$()],m.prototype,"logsAtBottom",2);m=b([Jr("clawdbot-app")],m);
//# sourceMappingURL=index--0oiTRSn.js.map
